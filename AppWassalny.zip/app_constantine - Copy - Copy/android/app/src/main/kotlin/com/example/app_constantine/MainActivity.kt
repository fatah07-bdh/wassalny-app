package com.example.app_constantine

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
