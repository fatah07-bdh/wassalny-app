# cooperation_ride/models.py
from django.db import models
from django.contrib.postgres.fields import ArrayField
from django.contrib.auth.models import User

class CooperativeRide(models.Model):
    STATUS_CHOICES = [
        ('searching', 'En recherche'),
        ('matched', 'Matché'),
        ('active', 'En cours'),
        ('completed', 'Complété'),
        ('cancelled', 'Annulé'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    passenger_name = models.CharField(max_length=100)
    passenger_phone = models.CharField(max_length=20)
    
    # Locations - VERSION SIMPLE (_coords)
    pickup_lat = models.FloatField()
    pickup_lng = models.FloatField()
    destination_lat = models.FloatField()
    destination_lng = models.FloatField()
    
    # Paramètres
    max_passengers = models.IntegerField(default=4)
    max_deviation_km = models.FloatField(default=2.0)
    time_window_minutes = models.IntegerField(default=15)
    women_only = models.BooleanField(default=False)
    
    # Prix
    total_price = models.DecimalField(max_digits=10, decimal_places=2)
    price_per_passenger = models.DecimalField(max_digits=10, decimal_places=2)
    
    # Status
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='searching')
    matched_passenger_ids = ArrayField(models.CharField(max_length=100), blank=True, default=list, size=None)
    driver = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='driver_rides')
    ride_id = models.CharField(max_length=100, blank=True, null=True)
    
    # Route
    route_polyline = ArrayField(models.CharField(max_length=1000), blank=True, default=list, size=None)
    stop_points = ArrayField(models.CharField(max_length=200), blank=True, default=list, size=None)
    
    # Timestamps
    requested_time = models.DateTimeField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        db_table = 'cooperative_rides'

    def __str__(self):
        return f"Covoiturage {self.passenger_name} - {self.status}"