# cooperation_ride/serializers.py
from rest_framework import serializers
from .models import CooperativeRide

class CooperativeRideSerializer(serializers.ModelSerializer):
    pickup_location = serializers.SerializerMethodField()
    destination_location = serializers.SerializerMethodField()

    class Meta:
        model = CooperativeRide
        fields = '__all__'

    def get_pickup_location(self, obj):
        return {
            'lat': obj.pickup_lat,
            'lng': obj.pickup_lng,
        }

    def get_destination_location(self, obj):
        return {
            'lat': obj.destination_lat,
            'lng': obj.destination_lng,
        }