# cooperation_ride/services.py
import math
from typing import List, Optional
from django.db import transaction
from datetime import timedelta
from .models import CooperativeRide

class MatchingAlgorithm:
    
    @staticmethod
    def haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """Calcul distance en km"""
        R = 6371  # Rayon Terre
        
        lat1_rad = math.radians(lat1)
        lat2_rad = math.radians(lat2)
        dlat = math.radians(lat2 - lat1)
        dlon = math.radians(lon2 - lon1)
        
        a = (math.sin(dlat/2)**2 + 
             math.cos(lat1_rad) * math.cos(lat2_rad) * math.sin(dlon/2)**2)
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
        
        return R * c

    @staticmethod
    def find_compatible_rides(current_ride: CooperativeRide) -> List[CooperativeRide]:
        """Trouver les rides compatibles"""
        
        time_window_start = current_ride.requested_time - timedelta(
            minutes=current_ride.time_window_minutes
        )
        time_window_end = current_ride.requested_time + timedelta(
            minutes=current_ride.time_window_minutes
        )

        # Recherche
        compatible_rides = CooperativeRide.objects.filter(
            status='searching',
            requested_time__gte=time_window_start,
            requested_time__lte=time_window_end,
            women_only=current_ride.women_only,
        ).exclude(id=current_ride.id)

        # Filtrage Python
        result = []
        for ride in compatible_rides:
            if MatchingAlgorithm.is_compatible(current_ride, ride):
                result.append(ride)
        
        return result

    @staticmethod
    def is_compatible(ride1: CooperativeRide, ride2: CooperativeRide) -> bool:
        """Vérifier compatibilité"""
        
        # women_only
        if ride1.women_only != ride2.women_only:
            return False

        # Passagers
        total_passengers = (1 + len(ride1.matched_passenger_ids) + 
                          1 + len(ride2.matched_passenger_ids))
        if total_passengers > ride1.max_passengers:
            return False

        # Distance pickup
        pickup_distance = MatchingAlgorithm.haversine_distance(
            ride1.pickup_lat, ride1.pickup_lng,
            ride2.pickup_lat, ride2.pickup_lng,
        )
        
        if pickup_distance > ride1.max_deviation_km:
            return False

        # Distance destination
        dest_distance = MatchingAlgorithm.haversine_distance(
            ride1.destination_lat, ride1.destination_lng,
            ride2.destination_lat, ride2.destination_lng,
        )
        
        if dest_distance > ride1.max_deviation_km:
            return False

        return True

    @staticmethod
    @transaction.atomic
    def perform_matching(current_ride_id: str) -> Optional[dict]:
        """Exécuter le matching"""
        
        try:
            current_ride = CooperativeRide.objects.select_for_update().get(id=current_ride_id)
            
            if current_ride.status != 'searching':
                return None
            
            compatible_rides = MatchingAlgorithm.find_compatible_rides(current_ride)
            
            if not compatible_rides:
                return None

            # Meilleur match (plus proche)
            compatible_rides.sort(key=lambda r: MatchingAlgorithm.haversine_distance(
                current_ride.pickup_lat, current_ride.pickup_lng,
                r.pickup_lat, r.pickup_lng,
            ))

            best_match = compatible_rides[0]

            # Mettre à jour
            current_ride.status = 'matched'
            current_ride.matched_passenger_ids.append(str(best_match.user.id))
            current_ride.save()

            best_match.status = 'matched'
            best_match.matched_passenger_ids.append(str(current_ride.user.id))
            best_match.save()

            return {
                'ride1_id': str(current_ride.id),
                'ride2_id': str(best_match.id),
                'pickup_distance': MatchingAlgorithm.haversine_distance(
                    current_ride.pickup_lat, current_ride.pickup_lng,
                    best_match.pickup_lat, best_match.pickup_lng,
                )
            }
        except Exception as e:
            print(f"Erreur matching: {e}")
            return None