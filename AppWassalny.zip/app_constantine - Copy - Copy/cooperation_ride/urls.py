# cooperation_ride/urls.py
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import CooperativeRideViewSet

router = DefaultRouter()
router.register(r'cooperative-rides', CooperativeRideViewSet)

urlpatterns = router.urls