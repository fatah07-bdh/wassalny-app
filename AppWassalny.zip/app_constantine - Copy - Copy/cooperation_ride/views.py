# cooperation_ride/views.py
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import CooperativeRide
from .serializers import CooperativeRideSerializer
from .services import MatchingAlgorithm

class CooperativeRideViewSet(viewsets.ModelViewSet):
    serializer_class = CooperativeRideSerializer
    queryset = CooperativeRide.objects.all()  # ← AJOUTER ÇA

    @action(detail=False, methods=['get'])
    def searching(self, request):
        rides = CooperativeRide.objects.filter(status='searching')
        serializer = self.get_serializer(rides, many=True)
        return Response(serializer.data)