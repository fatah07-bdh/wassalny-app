class ApiConfig {
  // For Android emulator:
  // For physical device:
  static const String baseUrl = 'http://10.0.2.2:8000/api';

  static String cooperativeRides = '$baseUrl/cooperative-rides/';
  static String searching = '$baseUrl/cooperative-rides/searching/';
}
