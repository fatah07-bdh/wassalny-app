import 'package:google_maps_flutter/google_maps_flutter.dart';

class CooperativePassenger {
  final String name;
  final String phone;
  final LatLng pickupLocation;
  final LatLng destinationLocation;
  final DateTime requestedTime;
  final double maxDeviation;
  final bool womenOnly;

  CooperativePassenger({
    required this.name,
    required this.phone,
    required this.pickupLocation,
    required this.destinationLocation,
    required this.requestedTime,
    this.maxDeviation = 1.0,
    this.womenOnly = false,
  });
}
