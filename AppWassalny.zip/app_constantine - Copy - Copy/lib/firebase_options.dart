import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        return macos;
      case TargetPlatform.windows:
        return windows;
      case TargetPlatform.linux:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for linux - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyDflsJRLlPZnvjCdQxx4l1ZT-0-rlSdMoI',
    appId: '1:694337151047:web:6210c1465043df42211162',
    messagingSenderId: '694337151047',
    projectId: 'app-constantine2125',
    authDomain: 'app-constantine2125.firebaseapp.com',
    storageBucket: 'app-constantine2125.firebasestorage.app',
    measurementId: 'G-SVMK2HHYMQ',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyBPjGx3Uv6EJzifzAD5nsiy-4Y849L3ikM',
    appId: '1:694337151047:android:47ceac24a28c18cc211162',
    messagingSenderId: '694337151047',
    projectId: 'app-constantine2125',
    storageBucket: 'app-constantine2125.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyAmuf8z6AMny1rx16GDUPi1EVeCjHKrNOs',
    appId: '1:694337151047:ios:7fe03ece6ba38a56211162',
    messagingSenderId: '694337151047',
    projectId: 'app-constantine2125',
    storageBucket: 'app-constantine2125.firebasestorage.app',
    iosBundleId: 'com.example.appConstantine',
  );

  static const FirebaseOptions macos = FirebaseOptions(
    apiKey: 'AIzaSyAmuf8z6AMny1rx16GDUPi1EVeCjHKrNOs',
    appId: '1:694337151047:ios:7fe03ece6ba38a56211162',
    messagingSenderId: '694337151047',
    projectId: 'app-constantine2125',
    storageBucket: 'app-constantine2125.firebasestorage.app',
    iosBundleId: 'com.example.appConstantine',
  );

  static const FirebaseOptions windows = FirebaseOptions(
    apiKey: 'AIzaSyDflsJRLlPZnvjCdQxx4l1ZT-0-rlSdMoI',
    appId: '1:694337151047:web:0d07d39fd98ef410211162',
    messagingSenderId: '694337151047',
    projectId: 'app-constantine2125',
    authDomain: 'app-constantine2125.firebaseapp.com',
    storageBucket: 'app-constantine2125.firebasestorage.app',
    measurementId: 'G-DYRVXVNS5Z',
  );
}
