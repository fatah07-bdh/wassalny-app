import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:app_constantine/theme_wassalny.dart';
import 'package:app_constantine/screens/home_screen.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:app_constantine/firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.dark,
  ));

  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  final DateTime expiryDate = DateTime(2026, 7, 31);

  if (DateTime.now().isAfter(expiryDate)) {
    runApp(
      MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
          backgroundColor: Colors.white,
          body: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.error_outline_rounded,
                      color: Colors.redAccent, size: 60),
                  const SizedBox(height: 16),
                  const Text(
                    "Erreur d'initialisation",
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "La période d'évaluation de cette version a expiré.\nVeuillez contacter le développeur pour obtenir une mise à jour.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontSize: 14, color: Colors.grey[600], height: 1.4),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
    return;
  }

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Wassalny',
      theme: WassalnyTheme.lightTheme,
      darkTheme: WassalnyTheme.darkTheme,
      home: const WelcomeScreen(),
      builder: (context, child) {
        final screenWidth = MediaQuery.of(context).size.width;
        final screenHeight = MediaQuery.of(context).size.height;

        if (screenWidth > 500) {
          return Scaffold(
            backgroundColor: Colors.grey[200],
            body: Center(
              child: Container(
                width: 414,
                height: screenHeight > 850 ? 850 : screenHeight - 40,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(30),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.2),
                      blurRadius: 40,
                      offset: const Offset(0, 20),
                    ),
                  ],
                ),
                clipBehavior: Clip.antiAlias,
                child: child,
              ),
            ),
          );
        }

        return child ?? const WelcomeScreen();
      },
    );
  }
}

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WassalnyTheme.bgLight,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 28.0, vertical: 24.0),
            child: Column(
              children: [
                const SizedBox(height: 60),
                Container(
                  width: 240,
                  height: 240,
                  decoration: BoxDecoration(
                    color: WassalnyTheme.surfaceLight,
                    shape: BoxShape.rectangle,
                    border: Border.all(color: WassalnyTheme.accent, width: 3),
                    boxShadow: [
                      BoxShadow(
                        color: WassalnyTheme.accent.withOpacity(0.15),
                        blurRadius: 20,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(14.0),
                    child: Image.asset('assets/images/Wassalny.png',
                        fit: BoxFit.contain),
                  ),
                ),
                const SizedBox(height: 24),
                const Text('Welcome',
                    style: TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.w900,
                      color: WassalnyTheme.primary,
                      letterSpacing: -0.8,
                    )),
                const SizedBox(height: 8),
                const Text('Your trusted ride companion.',
                    textAlign: TextAlign.center, style: WassalnyTheme.bodyText),
                const SizedBox(height: 32),
                Container(
                  width: double.infinity,
                  height: 52,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: WassalnyTheme.accentShadow,
                  ),
                  child: ElevatedButton(
                    onPressed: () => Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(builder: (_) => const HomeScreen()),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: WassalnyTheme.accent,
                      foregroundColor: WassalnyTheme.primary,
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16)),
                    ),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text('Get Started',
                            style: TextStyle(
                                fontSize: 16, fontWeight: FontWeight.w800)),
                        SizedBox(width: 8),
                        Icon(Icons.arrow_forward_rounded, size: 18),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                const Text('Wassalny',
                    style: TextStyle(
                        fontSize: 12,
                        color: WassalnyTheme.textSecondary,
                        fontWeight: FontWeight.w600)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
