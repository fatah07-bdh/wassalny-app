import 'package:cloud_firestore/cloud_firestore.dart';

class CooperativeRideRequest {
  final String id;
  final String userId;
  final String passengerName;
  final String passengerPhone;
  final double pickupLatitude;
  final double pickupLongitude;
  final double destinationLatitude;
  final double destinationLongitude;
  final DateTime requestedTime;
  final DateTime createdAt;

  final int maxPassengers;
  final double maxDeviationKm;
  final int timeWindowMinutes;
  final bool womenOnly;

  final double totalPrice;
  final double pricePerPassenger;

  final String status;
  final List<String> matchedPassengerIds;
  final String? driverId;
  final String? rideId;
  final List<CooperativePassenger> passengers;
  final List<String> routePolyline;

  final bool autoMatch;
  final double totalDistance;
  final double totalDuration;
  final List<int> stopOrder;

  CooperativeRideRequest({
    required this.id,
    required this.userId,
    required this.passengerName,
    required this.passengerPhone,
    required this.pickupLatitude,
    required this.pickupLongitude,
    required this.destinationLatitude,
    required this.destinationLongitude,
    required this.requestedTime,
    required this.createdAt,
    this.maxPassengers = 4,
    this.maxDeviationKm = 2.0,
    this.timeWindowMinutes = 15,
    this.womenOnly = false,
    required this.totalPrice,
    required this.pricePerPassenger,
    this.status = 'searching',
    this.matchedPassengerIds = const [],
    this.driverId,
    this.rideId,
    this.passengers = const [],
    this.routePolyline = const [],
    this.autoMatch = true,
    this.totalDistance = 0.0,
    this.totalDuration = 0.0,
    this.stopOrder = const [],
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'userId': userId,
      'passengerName': passengerName,
      'passengerPhone': passengerPhone,
      'pickupLatitude': pickupLatitude,
      'pickupLongitude': pickupLongitude,
      'destinationLatitude': destinationLatitude,
      'destinationLongitude': destinationLongitude,
      'requestedTime': Timestamp.fromDate(requestedTime),
      'createdAt': Timestamp.fromDate(createdAt),
      'maxPassengers': maxPassengers,
      'maxDeviationKm': maxDeviationKm,
      'timeWindowMinutes': timeWindowMinutes,
      'womenOnly': womenOnly,
      'totalPrice': totalPrice,
      'pricePerPassenger': pricePerPassenger,
      'status': status,
      'matchedPassengerIds': matchedPassengerIds,
      'driverId': driverId,
      'rideId': rideId,
      'passengers': passengers.map((p) => p.toMap()).toList(),
      'routePolyline': routePolyline,
      'autoMatch': autoMatch,
      'totalDistance': totalDistance,
      'totalDuration': totalDuration,
      'stopOrder': stopOrder,
    };
  }

  factory CooperativeRideRequest.fromMap(Map<String, dynamic> map) {
    List<CooperativePassenger> passengers = [];
    if (map['passengers'] != null) {
      passengers = (map['passengers'] as List)
          .map((p) => CooperativePassenger.fromMap(p as Map<String, dynamic>))
          .toList();
    }

    return CooperativeRideRequest(
      id: map['id'] ?? '',
      userId: map['userId'] ?? '',
      passengerName: map['passengerName'] ?? '',
      passengerPhone: map['passengerPhone'] ?? '',
      pickupLatitude: map['pickupLatitude'] ?? 0.0,
      pickupLongitude: map['pickupLongitude'] ?? 0.0,
      destinationLatitude: map['destinationLatitude'] ?? 0.0,
      destinationLongitude: map['destinationLongitude'] ?? 0.0,
      requestedTime: (map['requestedTime'] as Timestamp).toDate(),
      createdAt: (map['createdAt'] as Timestamp).toDate(),
      maxPassengers: map['maxPassengers'] ?? 4,
      maxDeviationKm: map['maxDeviationKm'] ?? 2.0,
      timeWindowMinutes: map['timeWindowMinutes'] ?? 15,
      womenOnly: map['womenOnly'] ?? false,
      totalPrice: (map['totalPrice'] ?? 0.0).toDouble(),
      pricePerPassenger: (map['pricePerPassenger'] ?? 0.0).toDouble(),
      status: map['status'] ?? 'searching',
      matchedPassengerIds: List<String>.from(map['matchedPassengerIds'] ?? []),
      driverId: map['driverId'],
      rideId: map['rideId'],
      passengers: passengers,
      routePolyline: List<String>.from(map['routePolyline'] ?? []),
      autoMatch: map['autoMatch'] ?? true,
      totalDistance: (map['totalDistance'] ?? 0.0).toDouble(),
      totalDuration: (map['totalDuration'] ?? 0.0).toDouble(),
      stopOrder: (map['stopOrder'] as List<dynamic>?)?.cast<int>() ?? [],
    );
  }

  CooperativeRideRequest copyWith({
    String? id,
    String? status,
    List<String>? matchedPassengerIds,
    String? driverId,
    String? rideId,
    List<CooperativePassenger>? passengers,
    List<String>? routePolyline,
    bool? autoMatch,
    double? totalDistance,
    double? totalDuration,
    List<int>? stopOrder,
  }) {
    return CooperativeRideRequest(
      id: id ?? this.id,
      userId: userId,
      passengerName: passengerName,
      passengerPhone: passengerPhone,
      pickupLatitude: pickupLatitude,
      pickupLongitude: pickupLongitude,
      destinationLatitude: destinationLatitude,
      destinationLongitude: destinationLongitude,
      requestedTime: requestedTime,
      createdAt: createdAt,
      maxPassengers: maxPassengers,
      maxDeviationKm: maxDeviationKm,
      timeWindowMinutes: timeWindowMinutes,
      womenOnly: womenOnly,
      totalPrice: totalPrice,
      pricePerPassenger: pricePerPassenger,
      status: status ?? this.status,
      matchedPassengerIds: matchedPassengerIds ?? this.matchedPassengerIds,
      driverId: driverId ?? this.driverId,
      rideId: rideId ?? this.rideId,
      passengers: passengers ?? this.passengers,
      routePolyline: routePolyline ?? this.routePolyline,
      autoMatch: autoMatch ?? this.autoMatch,
      totalDistance: totalDistance ?? this.totalDistance,
      totalDuration: totalDuration ?? this.totalDuration,
      stopOrder: stopOrder ?? this.stopOrder,
    );
  }
}

class CooperativePassenger {
  final String id;
  final String name;
  final String phone;
  final double pickupLatitude;
  final double pickupLongitude;
  final String status;
  final double price;
  final DateTime joinedAt;

  CooperativePassenger({
    required this.id,
    required this.name,
    required this.phone,
    required this.pickupLatitude,
    required this.pickupLongitude,
    this.status = 'pending',
    required this.price,
    required this.joinedAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'phone': phone,
      'pickupLatitude': pickupLatitude,
      'pickupLongitude': pickupLongitude,
      'status': status,
      'price': price,
      'joinedAt': Timestamp.fromDate(joinedAt),
    };
  }

  factory CooperativePassenger.fromMap(Map<String, dynamic> map) {
    return CooperativePassenger(
      id: map['id'] ?? '',
      name: map['name'] ?? '',
      phone: map['phone'] ?? '',
      pickupLatitude: map['pickupLatitude'] ?? 0.0,
      pickupLongitude: map['pickupLongitude'] ?? 0.0,
      status: map['status'] ?? 'pending',
      price: (map['price'] ?? 0.0).toDouble(),
      joinedAt: (map['joinedAt'] as Timestamp).toDate(),
    );
  }
}
