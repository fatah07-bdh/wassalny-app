class RideModel {
  final String? id;
  final String userId;
  final String clientName;
  final String clientPhone;
  final String pickupAddress;
  final String destinationAddress;
  final double pickupLat;
  final double pickupLng;
  final double destinationLat;
  final double destinationLng;
  final String status;
  final double price;
  final DateTime createdAt;
  final String driverName;
  final String driverPlate;
  final String driverTaxiNumber;

  RideModel({
    this.id,
    required this.userId,
    required this.clientName,
    required this.clientPhone,
    required this.pickupAddress,
    required this.destinationAddress,
    required this.pickupLat,
    required this.pickupLng,
    required this.destinationLat,
    required this.destinationLng,
    required this.status,
    required this.price,
    required this.createdAt,
    required this.driverName,
    this.driverPlate = '',
    this.driverTaxiNumber = '',
  });

  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'clientName': clientName,
      'clientPhone': clientPhone,
      'pickupAddress': pickupAddress,
      'destinationAddress': destinationAddress,
      'pickupLat': pickupLat,
      'pickupLng': pickupLng,
      'destinationLat': destinationLat,
      'destinationLng': destinationLng,
      'status': status,
      'price': price,
      'createdAt': createdAt.toIso8601String(),
      'driverName': driverName,
      'driverPlate': driverPlate,
      'driverTaxiNumber': driverTaxiNumber,
    };
  }

  factory RideModel.fromMap(Map<String, dynamic> map, String id) {
    return RideModel(
      id: id,
      userId: map['userId'] ?? '',
      clientName: map['clientName'] ?? '',
      clientPhone: map['clientPhone'] ?? '',
      pickupAddress: map['pickupAddress'] ?? '',
      destinationAddress: map['destinationAddress'] ?? '',
      pickupLat: (map['pickupLat'] ?? 0).toDouble(),
      pickupLng: (map['pickupLng'] ?? 0).toDouble(),
      destinationLat: (map['destinationLat'] ?? 0).toDouble(),
      destinationLng: (map['destinationLng'] ?? 0).toDouble(),
      status: map['status'] ?? 'pending',
      price: (map['price'] ?? 0).toDouble(),
      createdAt: map['createdAt'] != null
          ? DateTime.parse(map['createdAt'])
          : DateTime.now(),
      driverName: map['driverName'] ?? 'En attente',
      driverPlate: map['driverPlate'] ?? '',
      driverTaxiNumber: map['driverTaxiNumber'] ?? '',
    );
  }
}
