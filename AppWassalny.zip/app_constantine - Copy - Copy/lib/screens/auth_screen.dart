import 'package:flutter/material.dart';
import 'package:app_constantine/theme_wassalny.dart';
import 'package:app_constantine/screens/client_login_screen.dart';
import 'package:app_constantine/screens/driver_login_screen.dart';

class AuthScreen extends StatelessWidget {
  const AuthScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WassalnyTheme.bgLight,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 40),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Spacer(flex: 2),
              Center(
                child: Column(children: [
                  Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      color: WassalnyTheme.surfaceLight,
                      shape: BoxShape.circle,
                      border: Border.all(color: WassalnyTheme.accent, width: 3),
                      boxShadow: WassalnyTheme.accentShadow,
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Image.asset('assets/images/Wassalny.png',
                          fit: BoxFit.contain),
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Text('Wassalny',
                      style: TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.w900,
                          color: WassalnyTheme.primary,
                          letterSpacing: -0.5)),
                  const SizedBox(height: 4),
                  Text('وصلني · Your ride companion',
                      style: WassalnyTheme.bodyText),
                ]),
              ),
              const Spacer(flex: 2),
              SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton.icon(
                  onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => const ClientLoginScreen())),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: WassalnyTheme.accentBlue,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16)),
                  ),
                  icon: const Icon(Icons.person_rounded, size: 22),
                  label: const Text('Passenger Sign In',
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                ),
              ),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton.icon(
                  onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => const DriverLoginScreen())),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: WassalnyTheme.accent,
                    foregroundColor: WassalnyTheme.primary,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16)),
                  ),
                  icon: const Icon(Icons.local_taxi_rounded, size: 22),
                  label: const Text('Driver Sign In',
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                ),
              ),
              const Spacer(flex: 1),
              Center(
                child: Text('Wassalny · وصلني',
                    style: TextStyle(
                        fontSize: 12, color: WassalnyTheme.textSecondary)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
