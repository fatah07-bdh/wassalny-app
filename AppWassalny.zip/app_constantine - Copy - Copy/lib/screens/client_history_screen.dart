import 'package:flutter/material.dart';
import 'package:app_constantine/theme_wassalny.dart';
import 'package:app_constantine/widgets/app_widgets.dart';

class ClientHistoryScreen extends StatelessWidget {
  const ClientHistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WassalnyTheme.bgLight,
      appBar: WassalnyTheme.buildAppBar('Ride History'),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: const [
          RideHistoryCard(
            date: 'Apr 23, 2025 · 14:25',
            departure: 'Train Station Square',
            destination: 'University of Constantine',
            price: '400 DA',
            status: 'Completed',
          ),
          RideHistoryCard(
            date: 'Apr 23, 2025 · 16:40',
            departure: 'City Center',
            destination: 'Airport',
            price: '600 DA',
            status: 'Completed',
          ),
        ],
      ),
    );
  }
}
