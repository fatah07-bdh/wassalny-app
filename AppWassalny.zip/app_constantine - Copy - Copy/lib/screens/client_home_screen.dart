import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:app_constantine/theme_wassalny.dart';
import 'package:app_constantine/screens/client_profile_screen.dart';
import 'package:app_constantine/screens/client_history_screen.dart';
import 'package:app_constantine/screens/home_screen.dart';
import 'package:app_constantine/screens/driver_recommendation_screen.dart';
import 'package:app_constantine/screens/customer_ride_request_screen.dart';
import 'package:app_constantine/services/auth_service.dart';

class ClientHomeScreen extends StatefulWidget {
  const ClientHomeScreen({super.key});

  @override
  State<ClientHomeScreen> createState() => _ClientHomeScreenState();
}

class _ClientHomeScreenState extends State<ClientHomeScreen> {
  GoogleMapController? _mapController;
  LatLng _currentPosition = const LatLng(36.3650, 6.6147);
  Set<Marker> _markers = {};
  bool _isLoading = true;

  Future<void> _getCurrentLocation() async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        setState(() => _isLoading = false);
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          setState(() => _isLoading = false);
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        setState(() => _isLoading = false);
        return;
      }

      Position position = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high,
          timeLimit: const Duration(seconds: 5));

      setState(() {
        _currentPosition = LatLng(position.latitude, position.longitude);
        _markers.add(Marker(
          markerId: const MarkerId('client'),
          position: _currentPosition,
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
        ));
        _isLoading = false;
      });

      _mapController?.animateCamera(CameraUpdate.newCameraPosition(
          CameraPosition(target: _currentPosition, zoom: 15)));
    } catch (e) {
      print('Erreur de localisation: $e');
      setState(() => _isLoading = false);
    }
  }

  Future<void> _logout() async {
    await AuthService().signOut();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const HomeScreen()),
      (r) => false,
    );
  }

  @override
  void initState() {
    super.initState();
    _getCurrentLocation();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WassalnyTheme.bgLight,
      appBar: AppBar(
        backgroundColor: WassalnyTheme.bgLight,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        leading: Builder(
          builder: (ctx) => IconButton(
            icon: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: WassalnyTheme.surfaceLight,
                borderRadius: BorderRadius.circular(10),
                boxShadow: WassalnyTheme.cardShadow,
              ),
              child: const Icon(Icons.menu_rounded,
                  color: WassalnyTheme.primary, size: 20),
            ),
            onPressed: () => Scaffold.of(ctx).openDrawer(),
          ),
        ),
        title: const Text('Passenger',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w800,
              color: WassalnyTheme.primary,
            )),
        centerTitle: true,
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 16),
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: WassalnyTheme.accentBlue.withOpacity(0.10),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.notifications_outlined,
                color: WassalnyTheme.accentBlue, size: 20),
          ),
        ],
      ),
      drawer: _buildDrawer(context),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: SizedBox(
              height: 220,
              child: Stack(
                children: [
                  _isLoading
                      ? const Center(
                          child: CircularProgressIndicator(
                              color: WassalnyTheme.accent))
                      : GoogleMap(
                          initialCameraPosition: CameraPosition(
                            target: _currentPosition,
                            zoom: 15,
                          ),
                          onMapCreated: (c) => _mapController = c,
                          myLocationEnabled: true,
                          myLocationButtonEnabled: false,
                          zoomControlsEnabled: false,
                          markers: _markers,
                        ),
                  Positioned(
                    bottom: 12,
                    right: 12,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: WassalnyTheme.primary,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(children: [
                        Icon(Icons.location_on,
                            color: WassalnyTheme.accent, size: 14),
                        const SizedBox(width: 4),
                        const Text('My Location',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                                fontWeight: FontWeight.w600)),
                      ]),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),
          Row(children: [
            Expanded(
              child: _ActionCard(
                label: 'Book a Ride',
                icon: Icons.hail_rounded,
                color: WassalnyTheme.accentBlue,
                onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const CustomerRideRequestScreen())),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _ActionCard(
                label: 'Top Drivers',
                icon: Icons.star_rounded,
                color: WassalnyTheme.success,
                onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const DriverRecommendationScreen())),
              ),
            ),
          ]),
          const SizedBox(height: 28),
          Row(
            children: [
              const Text('Nearby Drivers',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    color: WassalnyTheme.primary,
                  )),
              const Spacer(),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: WassalnyTheme.success.withOpacity(0.10),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Text('2 available',
                    style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: WassalnyTheme.success)),
              ),
            ],
          ),
          const SizedBox(height: 14),
          _DriverCard(name: 'Ali', distance: '2.5 km', rating: '5.0'),
          const SizedBox(height: 10),
          _DriverCard(name: 'Ahmed', distance: '3.2 km', rating: '4.8'),
        ],
      ),
    );
  }

  Widget _buildDrawer(BuildContext context) {
    return Drawer(
      backgroundColor: WassalnyTheme.surfaceLight,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.horizontal(right: Radius.circular(24)),
      ),
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(24, 56, 24, 28),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [WassalnyTheme.accentBlue, Color(0xFF1565C0)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.vertical(bottom: Radius.circular(24)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white, width: 3),
                  ),
                  child: const Icon(Icons.person,
                      size: 32, color: WassalnyTheme.accentBlue),
                ),
                const SizedBox(height: 12),
                const Text('Passenger',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w800)),
                const SizedBox(height: 2),
                Text('passenger@wassalny.dz',
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.75), fontSize: 13)),
              ],
            ),
          ),
          const SizedBox(height: 8),
          _DrawerItem(
            icon: Icons.person_outline,
            label: 'My Profile',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const ClientProfileScreen(
                  clientName: 'Karim',
                  clientPhone: '+213 7XX XXX XXX',
                  clientEmail: 'karim@gmail.com',
                  clientGender: 'Male',
                ),
              ),
            ),
          ),
          _DrawerItem(
            icon: Icons.history_rounded,
            label: 'Ride History',
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const ClientHistoryScreen())),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Divider(),
          ),
          _DrawerItem(
            icon: Icons.logout_rounded,
            label: 'Sign Out',
            color: WassalnyTheme.danger,
            onTap: _logout,
          ),
        ],
      ),
    );
  }
}

class _ActionCard extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const _ActionCard({
    required this.label,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
        decoration: BoxDecoration(
          color: color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.15)),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 26),
            const SizedBox(height: 8),
            Text(label,
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: color,
                    height: 1.2)),
          ],
        ),
      ),
    );
  }
}

class _DriverCard extends StatelessWidget {
  final String name;
  final String distance;
  final String rating;

  const _DriverCard({
    required this.name,
    required this.distance,
    required this.rating,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: WassalnyTheme.cardDecoration,
      child: Row(
        children: [
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: WassalnyTheme.accentBlue.withOpacity(0.10),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.person,
                color: WassalnyTheme.accentBlue, size: 24),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name, style: WassalnyTheme.cardTitle),
                const SizedBox(height: 2),
                Row(children: [
                  const Icon(Icons.location_on_outlined,
                      size: 12, color: WassalnyTheme.textSecondary),
                  const SizedBox(width: 2),
                  Text(distance, style: WassalnyTheme.cardSubtitle),
                ]),
              ],
            ),
          ),
          Column(
            children: [
              Row(children: [
                const Icon(Icons.star_rounded,
                    color: WassalnyTheme.accent, size: 14),
                const SizedBox(width: 3),
                Text(rating,
                    style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: WassalnyTheme.primary)),
              ]),
              const SizedBox(height: 6),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: WassalnyTheme.accentBlue,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Text('Book',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 11,
                        fontWeight: FontWeight.w700)),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _DrawerItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final Color? color;

  const _DrawerItem({
    required this.icon,
    required this.label,
    required this.onTap,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final c = color ?? WassalnyTheme.primary;
    return ListTile(
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: c.withOpacity(0.08),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, color: c, size: 18),
      ),
      title: Text(label,
          style:
              TextStyle(color: c, fontWeight: FontWeight.w600, fontSize: 15)),
      trailing: Icon(Icons.chevron_right_rounded,
          color: c.withOpacity(0.4), size: 18),
      onTap: onTap,
    );
  }
}
