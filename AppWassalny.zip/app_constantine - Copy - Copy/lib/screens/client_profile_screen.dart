import 'package:flutter/material.dart';
import 'package:app_constantine/theme_wassalny.dart';
import 'package:app_constantine/screens/client_home_screen.dart';

class ClientProfileScreen extends StatelessWidget {
  final String clientName;
  final String clientPhone;
  final String clientEmail;
  final String clientGender;

  const ClientProfileScreen({
    super.key,
    required this.clientName,
    required this.clientPhone,
    required this.clientEmail,
    required this.clientGender,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WassalnyTheme.bgLight,
      appBar: WassalnyTheme.buildAppBar('My Profile'),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
        child: Column(
          children: [
            Center(
              child: Stack(
                children: [
                  Container(
                    width: 96,
                    height: 96,
                    decoration: BoxDecoration(
                      color: WassalnyTheme.accentBlue.withOpacity(0.10),
                      shape: BoxShape.circle,
                      border: Border.all(
                          color: WassalnyTheme.accentBlue.withOpacity(0.3),
                          width: 2),
                    ),
                    child: const Icon(Icons.person_rounded,
                        size: 48, color: WassalnyTheme.accentBlue),
                  ),
                  Positioned(
                    right: 0,
                    bottom: 0,
                    child: Container(
                      width: 28,
                      height: 28,
                      decoration: const BoxDecoration(
                        color: WassalnyTheme.accentBlue,
                        shape: BoxShape.circle,
                      ),
                      child:
                          const Icon(Icons.edit, color: Colors.white, size: 14),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Text(
              clientName.isEmpty ? 'Passenger' : clientName,
              style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                  color: WassalnyTheme.primary),
            ),
            const SizedBox(height: 2),
            Text('Passenger account', style: WassalnyTheme.cardSubtitle),
            const SizedBox(height: 28),
            Container(
              padding: const EdgeInsets.all(8),
              decoration: WassalnyTheme.cardDecoration,
              child: Column(
                children: [
                  _InfoTile(
                      icon: Icons.person_outline,
                      label: 'Full Name',
                      value: clientName.isEmpty ? '—' : clientName),
                  const Divider(height: 1, indent: 16, endIndent: 16),
                  _InfoTile(
                      icon: Icons.phone_outlined,
                      label: 'Phone',
                      value: clientPhone.isEmpty ? '—' : clientPhone),
                  const Divider(height: 1, indent: 16, endIndent: 16),
                  _InfoTile(
                      icon: Icons.email_outlined,
                      label: 'Email',
                      value: clientEmail.isEmpty ? '—' : clientEmail),
                  const Divider(height: 1, indent: 16, endIndent: 16),
                  _InfoTile(
                      icon: Icons.wc_outlined,
                      label: 'Gender',
                      value: clientGender.isEmpty ? '—' : clientGender),
                ],
              ),
            ),
            const SizedBox(height: 28),
            SizedBox(
              width: double.infinity,
              height: 54,
              child: ElevatedButton.icon(
                onPressed: () => Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const ClientHomeScreen()),
                  (r) => false,
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: WassalnyTheme.accentBlue,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                ),
                icon: const Icon(Icons.home_rounded, size: 20),
                label: const Text('Go to Home',
                    style:
                        TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _InfoTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _InfoTile(
      {required this.icon, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: WassalnyTheme.accentBlue.withOpacity(0.08),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, color: WassalnyTheme.accentBlue, size: 18),
      ),
      title: Text(label,
          style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: WassalnyTheme.textSecondary,
              letterSpacing: 0.3)),
      subtitle: Text(value,
          style: const TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w600,
              color: WassalnyTheme.primary)),
    );
  }
}
