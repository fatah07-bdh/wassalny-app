import 'package:flutter/material.dart';
import 'package:app_constantine/theme_wassalny.dart';
import 'package:app_constantine/screens/client_profile_screen.dart';
import 'package:app_constantine/screens/client_home_screen.dart';

class ClientSignupScreen extends StatefulWidget {
  const ClientSignupScreen({super.key});

  @override
  State<ClientSignupScreen> createState() => _ClientSignupScreenState();
}

class _ClientSignupScreenState extends State<ClientSignupScreen> {
  final _nameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  String? _gender;
  bool _obscure = true;

  @override
  void dispose() {
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    _emailCtrl.dispose();
    _passwordCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WassalnyTheme.bgLight,
      appBar: WassalnyTheme.buildAppBar('Create Account'),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Passenger Registration',
                style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w900,
                    color: WassalnyTheme.primary)),
            const SizedBox(height: 6),
            Text('Fill in your details to get started.',
                style: WassalnyTheme.bodyText),
            const SizedBox(height: 28),
            TextField(
                style: TextStyle(color: Colors.black, fontSize: 14),
                controller: _nameCtrl,
                decoration: WassalnyTheme.textFieldDecoration('Full name',
                    icon: Icons.person_outline)),
            const SizedBox(height: 14),
            TextField(
                style: TextStyle(color: Colors.black, fontSize: 14),
                controller: _phoneCtrl,
                keyboardType: TextInputType.phone,
                decoration: WassalnyTheme.textFieldDecoration('Phone number',
                    icon: Icons.phone_outlined)),
            const SizedBox(height: 14),
            DropdownButtonFormField<String>(
              value: _gender,
              decoration: WassalnyTheme.textFieldDecoration('Gender',
                  icon: Icons.wc_outlined),
              items: const [
                DropdownMenuItem(value: 'Male', child: Text('Male')),
                DropdownMenuItem(value: 'Female', child: Text('Female')),
              ],
              onChanged: (v) => setState(() => _gender = v),
            ),
            const SizedBox(height: 14),
            TextField(
                style: TextStyle(color: Colors.black, fontSize: 14),
                controller: _emailCtrl,
                keyboardType: TextInputType.emailAddress,
                decoration: WassalnyTheme.textFieldDecoration('Email address',
                    icon: Icons.email_outlined)),
            const SizedBox(height: 14),
            TextField(
              style: TextStyle(color: Colors.black, fontSize: 14),
              controller: _passwordCtrl,
              obscureText: _obscure,
              decoration: WassalnyTheme.textFieldDecoration('Password',
                      icon: Icons.lock_outline)
                  .copyWith(
                suffixIcon: IconButton(
                  icon: Icon(
                      _obscure
                          ? Icons.visibility_outlined
                          : Icons.visibility_off_outlined,
                      color: WassalnyTheme.textSecondary,
                      size: 20),
                  onPressed: () => setState(() => _obscure = !_obscure),
                ),
              ),
            ),
            const SizedBox(height: 28),
            SizedBox(
              width: double.infinity,
              height: 54,
              child: ElevatedButton(
                onPressed: () => Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ClientProfileScreen(
                      clientName: _nameCtrl.text.trim(),
                      clientPhone: _phoneCtrl.text.trim(),
                      clientEmail: _emailCtrl.text.trim(),
                      clientGender: _gender ?? '',
                    ),
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: WassalnyTheme.accentBlue,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                ),
                child: const Text('Continue',
                    style:
                        TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              ),
            ),
            const SizedBox(height: 16),
            Center(
              child: TextButton(
                onPressed: () => Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const ClientHomeScreen())),
                child: const Text('Already have an account? Sign In',
                    style: TextStyle(
                        color: WassalnyTheme.accentBlue,
                        fontWeight: FontWeight.w600)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
