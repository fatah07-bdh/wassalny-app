import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:app_constantine/theme_wassalny.dart';
import 'package:app_constantine/cooperative_passenger.dart';
import 'package:app_constantine/screens/driver_home_screen.dart';

class CooperativeRideAcceptScreen extends StatefulWidget {
  final String userId;
  final List<CooperativePassenger> passengers;
  final LatLng pickupLocation;
  final LatLng destinationLocation;
  final double totalPrice;
  final double pricePerPassenger;
  final String pickupPlace;
  final String destinationPlace;
  final String date;
  final String time;

  const CooperativeRideAcceptScreen({
    Key? key,
    required this.userId,
    required this.passengers,
    required this.pickupLocation,
    required this.destinationLocation,
    required this.totalPrice,
    required this.pricePerPassenger,
    required this.pickupPlace,
    required this.destinationPlace,
    required this.date,
    required this.time,
  }) : super(key: key);

  @override
  State<CooperativeRideAcceptScreen> createState() =>
      _CooperativeRideAcceptScreenState();
}

class _CooperativeRideAcceptScreenState
    extends State<CooperativeRideAcceptScreen> {
  bool _isAccepting = false;
  Map<String, dynamic>? _driverInfo;

  Future<void> _acceptSharedRide() async {
    setState(() => _isAccepting = true);
    try {
      final rideUpdate = {
        'status': 'matched',
        'matchedPassengers': widget.passengers
            .map((p) => {
                  'name': p.name,
                  'phone': p.phone,
                  'pickupLatitude': p.pickupLocation.latitude,
                  'pickupLongitude': p.pickupLocation.longitude,
                })
            .toList(),
        'matchedAt': FieldValue.serverTimestamp(),
      };

      final query = await FirebaseFirestore.instance
          .collection('ride_requests')
          .where('userId', isEqualTo: widget.userId)
          .where('status', isEqualTo: 'pending')
          .orderBy('createdAt', descending: true)
          .limit(1)
          .get();

      if (query.docs.isNotEmpty) {
        await FirebaseFirestore.instance
            .collection('ride_requests')
            .doc(query.docs.first.id)
            .update(rideUpdate);
      }

      await Future.delayed(const Duration(seconds: 2));
      setState(() {
        _driverInfo = {'name': 'Ali Mohamed', 'taxiNumber': '12345/31/01'};
        _isAccepting = false;
      });
      _showReceiptDialog();
    } catch (e) {
      setState(() => _isAccepting = false);
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Error: $e')));
    }
  }

  void _showReceiptDialog() {
    final discount = widget.totalPrice * 0.3;
    final finalPrice = widget.totalPrice - discount;

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Shared Ride Confirmed',
            style: TextStyle(
                fontWeight: FontWeight.w800,
                color: WassalnyTheme.primary,
                fontSize: 17)),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _DialogRow(Icons.location_on_outlined, WassalnyTheme.accentBlue,
                  widget.pickupPlace),
              _DialogRow(Icons.location_on, WassalnyTheme.danger,
                  widget.destinationPlace),
              _DialogRow(Icons.access_time_outlined, WassalnyTheme.success,
                  '${widget.time} · ${widget.date}'),
              _DialogRow(Icons.people_outlined, WassalnyTheme.accentBlue,
                  '${widget.passengers.length + 1} passengers'),
              const Divider(height: 20),
              _PriceRow('Original price',
                  '${widget.totalPrice.toStringAsFixed(0)} DA',
                  isSubtle: true),
              _PriceRow('Sharing discount (-30%)',
                  '-${discount.toStringAsFixed(0)} DA',
                  color: WassalnyTheme.success),
              const SizedBox(height: 4),
              _PriceRow('Final price', '${finalPrice.toStringAsFixed(0)} DA',
                  isBold: true),
              if (_driverInfo != null) ...[
                const Divider(height: 20),
                Row(children: [
                  const Icon(Icons.local_taxi_rounded,
                      color: WassalnyTheme.accent, size: 16),
                  const SizedBox(width: 8),
                  const Text('Driver',
                      style: TextStyle(
                          fontWeight: FontWeight.w700,
                          color: WassalnyTheme.primary,
                          fontSize: 13)),
                ]),
                const SizedBox(height: 8),
                _PriceRow('Name', _driverInfo!['name'], isSubtle: true),
                _PriceRow('Taxi No.', _driverInfo!['taxiNumber'],
                    isSubtle: true),
              ],
            ],
          ),
        ),
        actions: [
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pushReplacement(context,
                  MaterialPageRoute(builder: (_) => const DriverHomeScreen()));
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: WassalnyTheme.accent,
              foregroundColor: WassalnyTheme.primary,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
            ),
            child: const Text('Confirm',
                style: TextStyle(fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WassalnyTheme.bgLight,
      appBar: WassalnyTheme.buildAppBar('Confirm Shared Ride'),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: SizedBox(
              height: 200,
              child: GoogleMap(
                initialCameraPosition:
                    CameraPosition(target: widget.pickupLocation, zoom: 13),
                markers: {
                  Marker(
                    markerId: const MarkerId('pickup'),
                    position: widget.pickupLocation,
                    icon: BitmapDescriptor.defaultMarkerWithHue(
                        BitmapDescriptor.hueAzure),
                  ),
                  Marker(
                    markerId: const MarkerId('destination'),
                    position: widget.destinationLocation,
                  ),
                },
                zoomControlsEnabled: false,
                myLocationButtonEnabled: false,
              ),
            ),
          ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: WassalnyTheme.cardDecoration,
            child: Column(
              children: [
                Container(
                  width: 56,
                  height: 56,
                  decoration: BoxDecoration(
                    color: WassalnyTheme.success.withOpacity(0.10),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.people_alt_rounded,
                      color: WassalnyTheme.success, size: 28),
                ),
                const SizedBox(height: 14),
                Text(
                  '${widget.passengers.length} passenger(s) will join',
                  style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: WassalnyTheme.primary),
                ),
                const SizedBox(height: 8),
                Text(
                  '${widget.pricePerPassenger.toStringAsFixed(0)} DA per passenger',
                  style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                      color: WassalnyTheme.accent),
                ),
                const SizedBox(height: 4),
                Text('30% discount applied for sharing',
                    style: TextStyle(
                        color: WassalnyTheme.success,
                        fontSize: 12,
                        fontWeight: FontWeight.w600)),
              ],
            ),
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            height: 54,
            child: ElevatedButton(
              onPressed: _isAccepting ? null : _acceptSharedRide,
              style: ElevatedButton.styleFrom(
                backgroundColor: WassalnyTheme.success,
                foregroundColor: Colors.white,
                elevation: 0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
              ),
              child: _isAccepting
                  ? const SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(
                          color: Colors.white, strokeWidth: 2.5))
                  : const Text('Accept Shared Ride',
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
            ),
          ),
        ],
      ),
    );
  }
}

class _DialogRow extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String text;
  const _DialogRow(this.icon, this.color, this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(children: [
        Icon(icon, color: color, size: 16),
        const SizedBox(width: 8),
        Expanded(
            child: Text(text,
                style: const TextStyle(
                    fontSize: 13,
                    color: WassalnyTheme.primary,
                    fontWeight: FontWeight.w500))),
      ]),
    );
  }
}

class _PriceRow extends StatelessWidget {
  final String label;
  final String value;
  final bool isSubtle;
  final bool isBold;
  final Color? color;

  const _PriceRow(this.label, this.value,
      {this.isSubtle = false, this.isBold = false, this.color});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label,
              style: TextStyle(
                  fontSize: 13,
                  color: isSubtle
                      ? WassalnyTheme.textSecondary
                      : WassalnyTheme.primary,
                  fontWeight: isBold ? FontWeight.w800 : FontWeight.w500)),
          Text(value,
              style: TextStyle(
                  fontSize: isBold ? 16 : 13,
                  fontWeight: isBold ? FontWeight.w900 : FontWeight.w600,
                  color: color ??
                      (isBold
                          ? WassalnyTheme.primary
                          : WassalnyTheme.textSecondary))),
        ],
      ),
    );
  }
}
