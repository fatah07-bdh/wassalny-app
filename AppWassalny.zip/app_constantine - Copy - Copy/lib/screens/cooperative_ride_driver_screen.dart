import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:app_constantine/theme_wassalny.dart';
import 'package:app_constantine/screens/ride_confirmation_screen.dart';
import 'package:app_constantine/cooperative_passenger.dart';

class CooperativeRideDriverScreen extends StatefulWidget {
  final List<CooperativePassenger> passengers;
  final LatLng clientPickupLocation;
  final LatLng clientDestinationLocation;
  final double totalPrice;
  final double pricePerPassenger;
  final String pickupAddress;
  final String destinationAddress;
  final List<LatLng>? optimizedRoute;
  final double? totalDistanceKm;
  final double? totalTimeMinutes;
  final int? extraWaitSeconds;

  const CooperativeRideDriverScreen({
    super.key,
    required this.passengers,
    required this.clientPickupLocation,
    required this.clientDestinationLocation,
    required this.totalPrice,
    required this.pricePerPassenger,
    required this.pickupAddress,
    required this.destinationAddress,
    this.optimizedRoute,
    this.totalDistanceKm,
    this.totalTimeMinutes,
    this.extraWaitSeconds,
  });

  @override
  State<CooperativeRideDriverScreen> createState() =>
      _CooperativeRideDriverScreenState();
}

class _CooperativeRideDriverScreenState
    extends State<CooperativeRideDriverScreen> {
  int _currentPassengerIndex = 0;

  List<LatLng> get _route => widget.optimizedRoute ?? [];
  double get _distance => widget.totalDistanceKm ?? (widget.totalPrice / 150);
  double get _time => widget.totalTimeMinutes ?? ((_distance / 30) * 60);
  int get _wait => widget.extraWaitSeconds ?? 0;

  void _acceptRide() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => RideConfirmationScreen(
          clientName: widget.passengers.first.name,
          clientPhone: widget.passengers.first.phone,
          driverName: 'Ali',
          driverPlate: '58-123-T',
          driverTaxiNumber: 'TAXI-12345',
          pickupAddress: widget.pickupAddress,
          destinationAddress: widget.destinationAddress,
          distanceKm: _distance,
          price: widget.totalPrice,
          isShared: true,
          discountPercentage: 20,
          numberOfPassengers: widget.passengers.length,
          isDriver: true,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WassalnyTheme.bgLight,
      appBar: WassalnyTheme.buildAppBar('Shared Ride'),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: WassalnyTheme.success.withOpacity(0.08),
                borderRadius: BorderRadius.circular(16),
                border:
                    Border.all(color: WassalnyTheme.success.withOpacity(0.3)),
              ),
              child: Row(
                children: [
                  Icon(Icons.people_alt,
                      color: WassalnyTheme.success, size: 24),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Optimized Shared Ride - 20% Discount',
                            style: TextStyle(
                                fontWeight: FontWeight.w800,
                                fontSize: 15,
                                color: WassalnyTheme.primary)),
                        const SizedBox(height: 4),
                        Text('${widget.passengers.length} passengers',
                            style: TextStyle(
                                fontSize: 12,
                                color: WassalnyTheme.textSecondary)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            if (_route.isNotEmpty) ...[
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: WassalnyTheme.accentBlue.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                      color: WassalnyTheme.accentBlue.withOpacity(0.3)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.route,
                            color: WassalnyTheme.accentBlue, size: 20),
                        const SizedBox(width: 8),
                        const Text('Optimized Route',
                            style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w800,
                                color: WassalnyTheme.primary)),
                      ],
                    ),
                    const SizedBox(height: 12),
                    for (int i = 0; i < _route.length; i++) ...[
                      Row(
                        children: [
                          if (i == 0)
                            Icon(Icons.location_on,
                                size: 16, color: WassalnyTheme.accentBlue)
                          else if (i == _route.length - 1)
                            Icon(Icons.flag,
                                size: 16, color: WassalnyTheme.danger)
                          else
                            Icon(Icons.circle,
                                size: 12, color: WassalnyTheme.textSecondary),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              i == 0
                                  ? 'Pickup (${widget.pickupAddress})'
                                  : i == _route.length - 1
                                      ? 'Destination (${widget.destinationAddress})'
                                      : 'Stop ${i}',
                              style: const TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                  color: WassalnyTheme.primary),
                            ),
                          ),
                        ],
                      ),
                      if (i < _route.length - 1) ...[
                        const SizedBox(height: 4),
                        Padding(
                          padding: const EdgeInsets.only(left: 24),
                          child: Row(
                            children: [
                              Container(
                                width: 2,
                                height: 12,
                                decoration: BoxDecoration(
                                  color: WassalnyTheme.textSecondary
                                      .withOpacity(0.3),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Text(
                                '${_distanceBetween(_route[i], _route[i + 1]).toStringAsFixed(0)}m',
                                style: WassalnyTheme.cardSubtitle,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 8),
                      ],
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 20),
            ],
            const Text('Passengers',
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    color: WassalnyTheme.primary)),
            const SizedBox(height: 14),
            for (int i = 0; i < widget.passengers.length; i++) ...[
              Container(
                padding: const EdgeInsets.all(16),
                decoration: WassalnyTheme.cardDecoration,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: WassalnyTheme.accent.withOpacity(0.12),
                            shape: BoxShape.circle,
                          ),
                          child: Center(
                            child: Text('${i + 1}',
                                style: const TextStyle(
                                    fontWeight: FontWeight.w800,
                                    color: WassalnyTheme.accent)),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(widget.passengers[i].name,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.w700,
                                      fontSize: 15,
                                      color: WassalnyTheme.primary)),
                              const SizedBox(height: 4),
                              Row(
                                children: [
                                  Icon(Icons.phone,
                                      size: 14,
                                      color: WassalnyTheme.textSecondary),
                                  const SizedBox(width: 4),
                                  Text(widget.passengers[i].phone,
                                      style: const TextStyle(
                                          fontSize: 13,
                                          color: WassalnyTheme.textSecondary)),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              if (i < widget.passengers.length - 1) const SizedBox(height: 12),
            ],
            const SizedBox(height: 24),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: WassalnyTheme.accent.withOpacity(0.10),
                borderRadius: BorderRadius.circular(16),
                border:
                    Border.all(color: WassalnyTheme.accent.withOpacity(0.3)),
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Total Distance (Optimized)',
                          style: TextStyle(
                              fontSize: 12,
                              color: WassalnyTheme.textSecondary,
                              fontWeight: FontWeight.w600)),
                      Text('${_distance.toStringAsFixed(1)} km',
                          style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w900,
                              color: WassalnyTheme.primary)),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Total Time',
                          style: TextStyle(
                              fontSize: 12,
                              color: WassalnyTheme.textSecondary,
                              fontWeight: FontWeight.w600)),
                      Text('${_time.toStringAsFixed(0)} min',
                          style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w900,
                              color: WassalnyTheme.primary)),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Extra Wait Time',
                          style: TextStyle(
                              fontSize: 12,
                              color: WassalnyTheme.textSecondary,
                              fontWeight: FontWeight.w600)),
                      Text('${(_wait / 60).toStringAsFixed(0)} min',
                          style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w900,
                              color: WassalnyTheme.primary)),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('TOTAL PRICE',
                          style: TextStyle(
                              fontSize: 14,
                              color: WassalnyTheme.primary,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 0.5)),
                      Text('${widget.totalPrice.toStringAsFixed(0)} DA',
                          style: const TextStyle(
                              fontSize: 28,
                              fontWeight: FontWeight.w900,
                              color: WassalnyTheme.primary)),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Center(
                    child: Text('(20% discount included)',
                        style: TextStyle(
                            fontSize: 11, color: WassalnyTheme.success)),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              height: 54,
              child: ElevatedButton(
                onPressed: _acceptRide,
                style: ElevatedButton.styleFrom(
                  backgroundColor: WassalnyTheme.accent,
                  foregroundColor: WassalnyTheme.primary,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                ),
                child: const Text('Accept Shared Ride',
                    style:
                        TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  double _distanceBetween(LatLng a, LatLng b) {
    double latDiff = (a.latitude - b.latitude).abs();
    double lngDiff = (a.longitude - b.longitude).abs();
    return (latDiff * 111 + lngDiff * 85) * 1000;
  }
}
