import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'dart:async';
import 'package:app_constantine/theme_wassalny.dart';
import 'package:app_constantine/cooperative_passenger.dart';
import 'package:app_constantine/screens/cooperative_ride_driver_screen.dart';

class CooperativeRideMatchScreen extends StatefulWidget {
  final String userId;
  final LatLng pickupLocation;
  final LatLng destinationLocation;
  final DateTime requestedTime;
  final int maxPassengers;
  final double maxDeviation;
  final bool womenOnly;
  final double totalPrice;
  final double pricePerPassenger;
  final String pickupAddress;
  final String destinationAddress;

  const CooperativeRideMatchScreen({
    super.key,
    required this.userId,
    required this.pickupLocation,
    required this.destinationLocation,
    required this.requestedTime,
    required this.maxPassengers,
    required this.maxDeviation,
    required this.womenOnly,
    required this.totalPrice,
    required this.pricePerPassenger,
    required this.pickupAddress,
    required this.destinationAddress,
  });

  @override
  State<CooperativeRideMatchScreen> createState() =>
      _CooperativeRideMatchScreenState();
}

class _CooperativeRideMatchScreenState
    extends State<CooperativeRideMatchScreen> {
  bool _isSearching = true;
  List<CooperativePassenger> _matchedPassengers = [];
  List<LatLng> _optimizedRoute = [];
  double _totalDistance = 0;
  double _totalTimeMinutes = 0;
  int _extraWaitSeconds = 0;
  Timer? _timer;
  List<CooperativePassenger> _simulatedPassengers = [];

  @override
  void initState() {
    super.initState();
    _initSimulatedPassengers();
    _startSearch();
  }

  void _initSimulatedPassengers() {
    _simulatedPassengers = [
      CooperativePassenger(
        name: 'Sarah',
        phone: '+213 6XX 123 456',
        pickupLocation: LatLng(
          widget.pickupLocation.latitude + 0.005,
          widget.pickupLocation.longitude + 0.002,
        ),
        destinationLocation: widget.destinationLocation,
        requestedTime: widget.requestedTime,
        maxDeviation: 1.0,
        womenOnly: false,
      ),
      CooperativePassenger(
        name: 'Amel',
        phone: '+213 6XX 123 423',
        pickupLocation: LatLng(
          widget.pickupLocation.latitude + 0.005,
          widget.pickupLocation.longitude + 0.002,
        ),
        destinationLocation: widget.destinationLocation,
        requestedTime: widget.requestedTime,
        maxDeviation: 1.0,
        womenOnly: false,
      ),
      CooperativePassenger(
        name: 'Mohamed',
        phone: '+213 7XX 234 567',
        pickupLocation: LatLng(
          widget.pickupLocation.latitude + 0.003,
          widget.pickupLocation.longitude - 0.001,
        ),
        destinationLocation: widget.destinationLocation,
        requestedTime: widget.requestedTime,
        maxDeviation: 1.5,
        womenOnly: false,
      ),
      CooperativePassenger(
        name: 'Amina',
        phone: '+213 5XX 345 678',
        pickupLocation: widget.pickupLocation,
        destinationLocation: LatLng(
          widget.destinationLocation.latitude + 0.008,
          widget.destinationLocation.longitude + 0.003,
        ),
        requestedTime: widget.requestedTime,
        maxDeviation: 1.0,
        womenOnly: true,
      ),
    ];
  }

  void _startSearch() {
    _timer = Timer.periodic(const Duration(seconds: 2), (t) {
      if (_matchedPassengers.length < widget.maxPassengers - 1) {
        List<CooperativePassenger> newMatches = _findMatchingPassengers(
          _matchedPassengers.length,
        );

        if (newMatches.isNotEmpty) {
          setState(() {
            _matchedPassengers.addAll(newMatches);
          });
        }
      } else {
        t.cancel();

        setState(() {
          _isSearching = false;
          _optimizedRoute = _optimizeRoute(_matchedPassengers);
          _totalDistance = _calculateTotalDistance(_optimizedRoute);
          _totalTimeMinutes = _calculateTotalTime(_optimizedRoute);
          _extraWaitSeconds = _calculateExtraWaitTime(_matchedPassengers);
        });
      }
    });
  }

  List<CooperativePassenger> _findMatchingPassengers(int currentCount) {
    if (currentCount >= _simulatedPassengers.length) return [];

    CooperativePassenger passenger = _simulatedPassengers[currentCount];

    double pickupDeviation = _calculateDeviation(
      widget.pickupLocation,
      passenger.pickupLocation,
      widget.destinationLocation,
    );

    double destDeviation = _calculateDeviation(
      widget.pickupLocation,
      passenger.destinationLocation,
      widget.destinationLocation,
    );

    if (pickupDeviation > passenger.maxDeviation ||
        destDeviation > passenger.maxDeviation) {
      return [];
    }

    if (widget.womenOnly && !passenger.womenOnly) {
      return [];
    }

    return [passenger];
  }

  double _calculateDeviation(
    LatLng start,
    LatLng point,
    LatLng end,
  ) {
    double directDistance = _distanceBetween(start, end);
    double withPointDistance =
        _distanceBetween(start, point) + _distanceBetween(point, end);
    return (withPointDistance - directDistance) / directDistance;
  }

  List<LatLng> _optimizeRoute(List<CooperativePassenger> passengers) {
    if (passengers.isEmpty) {
      return [widget.pickupLocation, widget.destinationLocation];
    }

    List<LatLng> pickupPoints = [widget.pickupLocation];
    for (var p in passengers) {
      if (p.pickupLocation != widget.pickupLocation) {
        pickupPoints.add(p.pickupLocation);
      }
    }

    pickupPoints.sort((a, b) {
      double distA = _distanceBetween(widget.pickupLocation, a);
      double distB = _distanceBetween(widget.pickupLocation, b);
      return distA.compareTo(distB);
    });

    List<LatLng> destPoints = [];
    for (var p in passengers) {
      if (p.destinationLocation != widget.destinationLocation) {
        destPoints.add(p.destinationLocation);
      }
    }
    destPoints.add(widget.destinationLocation);

    destPoints.sort((a, b) {
      double distA = _distanceBetween(pickupPoints.last, a);
      double distB = _distanceBetween(pickupPoints.last, b);
      return distA.compareTo(distB);
    });

    return [...pickupPoints, ...destPoints];
  }

  double _calculateTotalDistance(List<LatLng> route) {
    double total = 0;
    for (int i = 0; i < route.length - 1; i++) {
      total += _distanceBetween(route[i], route[i + 1]);
    }
    return total;
  }

  double _calculateTotalTime(List<LatLng> route) {
    double distance = _calculateTotalDistance(route);
    return (distance / 30) * 60;
  }

  int _calculateExtraWaitTime(List<CooperativePassenger> passengers) {
    if (passengers.isEmpty) return 0;

    int totalWait = 0;
    for (var p in passengers) {
      double deviation = _calculateDeviation(
        widget.pickupLocation,
        p.pickupLocation,
        widget.destinationLocation,
      );
      double deviationDistance = deviation *
          _distanceBetween(
            widget.pickupLocation,
            widget.destinationLocation,
          );
      totalWait += (deviationDistance / (30 / 3.6)).toInt();
    }
    return totalWait;
  }

  double _distanceBetween(LatLng a, LatLng b) {
    double latDiff = (a.latitude - b.latitude).abs();
    double lngDiff = (a.longitude - b.longitude).abs();
    return (latDiff * 111 + lngDiff * 85);
  }

  double _calculatePricePerPassenger(CooperativePassenger passenger) {
    double basePrice = widget.totalPrice;
    double discountedPrice = basePrice * 0.8;
    double deviation = _calculateDeviation(
      widget.pickupLocation,
      passenger.pickupLocation,
      widget.destinationLocation,
    );
    if (deviation > 0.5) {
      discountedPrice *= (1 - deviation * 0.1);
    }
    return discountedPrice / widget.maxPassengers;
  }

  void _confirmRide() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => CooperativeRideDriverScreen(
          passengers: _matchedPassengers,
          clientPickupLocation: widget.pickupLocation,
          clientDestinationLocation: widget.destinationLocation,
          totalPrice: widget.totalPrice,
          pricePerPassenger:
              _calculatePricePerPassenger(_matchedPassengers.first),
          pickupAddress: widget.pickupAddress,
          destinationAddress: widget.destinationAddress,
          optimizedRoute: _optimizedRoute,
          totalDistanceKm: _totalDistance,
          totalTimeMinutes: _totalTimeMinutes,
          extraWaitSeconds: _extraWaitSeconds,
        ),
      ),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WassalnyTheme.bgLight,
      appBar: WassalnyTheme.buildAppBar('Shared Ride'),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: WassalnyTheme.cardDecoration,
            child: Column(
              children: [
                if (_isSearching) ...[
                  const SizedBox(
                    width: 48,
                    height: 48,
                    child: CircularProgressIndicator(
                        color: WassalnyTheme.accent, strokeWidth: 3),
                  ),
                  const SizedBox(height: 16),
                  const Text('Searching for passengers...',
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: WassalnyTheme.primary)),
                  const SizedBox(height: 8),
                  Text(
                    '${_matchedPassengers.length + 1} / ${widget.maxPassengers} found',
                    style: WassalnyTheme.bodyText,
                  ),
                  const SizedBox(height: 16),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: LinearProgressIndicator(
                      value: (_matchedPassengers.length + 1) /
                          widget.maxPassengers,
                      minHeight: 6,
                      backgroundColor: const Color(0xFFE2E8F0),
                      valueColor:
                          const AlwaysStoppedAnimation(WassalnyTheme.accent),
                    ),
                  ),
                ] else ...[
                  Container(
                    width: 56,
                    height: 56,
                    decoration: BoxDecoration(
                      color: WassalnyTheme.success.withOpacity(0.12),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.check_rounded,
                        color: WassalnyTheme.success, size: 30),
                  ),
                  const SizedBox(height: 14),
                  const Text('Match Found!',
                      style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                          color: WassalnyTheme.primary)),
                  const SizedBox(height: 8),
                  Text('${_matchedPassengers.length} passengers matched',
                      style: WassalnyTheme.bodyText),
                  const SizedBox(height: 12),
                  _PriceBadge(
                    label: 'Per passenger',
                    value:
                        '${_calculatePricePerPassenger(_matchedPassengers.first).toStringAsFixed(0)} DA',
                  ),
                  const SizedBox(height: 12),
                  _InfoRow(
                    icon: Icons.route,
                    label: 'Total distance',
                    value: '${_totalDistance.toStringAsFixed(1)} km',
                  ),
                  const SizedBox(height: 8),
                  _InfoRow(
                    icon: Icons.timer,
                    label: 'Total time',
                    value: '${_totalTimeMinutes.toStringAsFixed(0)} min',
                  ),
                  const SizedBox(height: 8),
                  _InfoRow(
                    icon: Icons.timer_outlined,
                    label: 'Extra wait time',
                    value: '${(_extraWaitSeconds / 60).toStringAsFixed(0)} min',
                  ),
                ],
              ],
            ),
          ),
          if (_matchedPassengers.isNotEmpty) ...[
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: WassalnyTheme.cardDecoration,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Matched Passengers',
                      style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w800,
                          color: WassalnyTheme.primary)),
                  const SizedBox(height: 12),
                  for (final p in _matchedPassengers)
                    Container(
                      margin: const EdgeInsets.only(bottom: 8),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: WassalnyTheme.accentBlue.withOpacity(0.06),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Column(
                        children: [
                          Row(children: [
                            const Icon(Icons.person_rounded,
                                color: WassalnyTheme.accentBlue, size: 20),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(p.name,
                                      style: const TextStyle(
                                          fontWeight: FontWeight.w700,
                                          fontSize: 14,
                                          color: WassalnyTheme.primary)),
                                  Text(p.phone,
                                      style: WassalnyTheme.cardSubtitle),
                                ],
                              ),
                            ),
                          ]),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              const Icon(Icons.location_on,
                                  color: WassalnyTheme.textSecondary, size: 16),
                              const SizedBox(width: 6),
                              Text(
                                'Pickup: ${_distanceBetween(widget.pickupLocation, p.pickupLocation).toStringAsFixed(0)}m away',
                                style: WassalnyTheme.cardSubtitle,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ],
          const SizedBox(height: 20),
          if (_isSearching)
            SizedBox(
              width: double.infinity,
              height: 54,
              child: ElevatedButton(
                onPressed: () {
                  _timer?.cancel();
                  Navigator.pop(context);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: WassalnyTheme.danger,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                ),
                child: const Text('Cancel Search',
                    style:
                        TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              ),
            )
          else
            SizedBox(
              width: double.infinity,
              height: 54,
              child: ElevatedButton(
                onPressed: _confirmRide,
                style: ElevatedButton.styleFrom(
                  backgroundColor: WassalnyTheme.accentBlue,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                ),
                child: const Text('Confirm Shared Ride',
                    style:
                        TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              ),
            ),
        ],
      ),
    );
  }
}

class _PriceBadge extends StatelessWidget {
  final String label;
  final String value;
  const _PriceBadge({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      decoration: BoxDecoration(
        color: WassalnyTheme.accent.withOpacity(0.10),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Text(label,
            style: const TextStyle(
                fontSize: 13,
                color: WassalnyTheme.textSecondary,
                fontWeight: FontWeight.w500)),
        const SizedBox(width: 8),
        Text(value,
            style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w900,
                color: WassalnyTheme.primary)),
      ]),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _InfoRow({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, color: WassalnyTheme.textSecondary, size: 18),
        const SizedBox(width: 8),
        Text(label,
            style: const TextStyle(
                fontSize: 13, color: WassalnyTheme.textSecondary)),
        const Spacer(),
        Text(value,
            style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w700,
                color: WassalnyTheme.primary)),
      ],
    );
  }
}
