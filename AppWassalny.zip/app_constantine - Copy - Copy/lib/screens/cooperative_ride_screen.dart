import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'cooperative_ride_match_screen.dart';

class CooperativeRideScreen extends StatefulWidget {
  final String userId;

  const CooperativeRideScreen({super.key, required this.userId});

  @override
  State<CooperativeRideScreen> createState() => _CooperativeRideScreenState();
}

class _CooperativeRideScreenState extends State<CooperativeRideScreen> {
  bool _isDarkMode = false;
  GoogleMapController? _mapController;
  LatLng? _currentPosition;

  LatLng _pickupLocation = const LatLng(36.3650, 6.6147);
  LatLng _destinationLocation = const LatLng(36.3680, 6.6200);

  String _pickupAddress = 'Point de départ';
  String _destinationAddress = 'Destination';

  DateTime _selectedTime = DateTime.now();

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  int _maxPassengers = 4;
  double _maxDeviation = 2.0;
  bool _womenOnly = false;

  @override
  void initState() {
    super.initState();
    _getCurrentLocation();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _mapController?.dispose();
    super.dispose();
  }

  Future<void> _getCurrentLocation() async {
    try {
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          _showSnackBar('Permission de localisation refusée');
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        _showSnackBar('Les permissions sont désactivées dans les paramètres');
        return;
      }

      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      setState(() {
        _currentPosition = LatLng(position.latitude, position.longitude);
        _pickupLocation = _currentPosition!;
        _pickupAddress = 'Localisation actuelle';
      });

      if (_mapController != null) {
        _mapController!.animateCamera(
          CameraUpdate.newCameraPosition(
            CameraPosition(target: _currentPosition!, zoom: 14.0),
          ),
        );
      }
    } catch (e) {
      debugPrint('Erreur localisation: $e');
    }
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Future<void> _selectPickupLocation() async {
    final result = await Navigator.push<LatLng>(
      context,
      MaterialPageRoute(
        builder: (context) => MapPickerScreen(
          initialPosition: _pickupLocation,
          title: 'Choisir le point de départ',
        ),
      ),
    );
    if (result != null) {
      List<Placemark> places = await placemarkFromCoordinates(
        result.latitude,
        result.longitude,
      );
      String address = places.first.name ?? '';
      if (places.first.locality != null) {
        address += ', ${places.first.locality}';
      }

      setState(() {
        _pickupLocation = result;
        _pickupAddress = address;
      });
      _updateMapCamera(_pickupLocation);
    }
  }

  Future<void> _selectDestination() async {
    final result = await Navigator.push<LatLng>(
      context,
      MaterialPageRoute(
        builder: (context) => MapPickerScreen(
          initialPosition: _destinationLocation,
          title: 'Choisir la destination',
        ),
      ),
    );
    if (result != null) {
      List<Placemark> places = await placemarkFromCoordinates(
        result.latitude,
        result.longitude,
      );
      String address = places.first.name ?? '';
      if (places.first.locality != null) {
        address += ', ${places.first.locality}';
      }

      setState(() {
        _destinationLocation = result;
        _destinationAddress = address;
      });
      _updateMapCamera(_destinationLocation);
    }
  }

  void _updateMapCamera(LatLng target) {
    if (_mapController != null) {
      _mapController!.animateCamera(CameraUpdate.newLatLng(target));
    }
  }

  Future<void> _selectDateTime() async {
    final date = await showDatePicker(
      context: context,
      initialDate: _selectedTime,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 30)),
    );
    if (date != null) {
      final time = await showTimePicker(
        context: context,
        initialTime: TimeOfDay.fromDateTime(_selectedTime),
      );
      if (time != null) {
        setState(() {
          _selectedTime =
              DateTime(date.year, date.month, date.day, time.hour, time.minute);
        });
      }
    }
  }

  void _requestCooperativeRide() {
    if (!_formKey.currentState!.validate()) {
      _showSnackBar('Veuillez remplir correctement les champs');
      return;
    }

    final double distance =
        _calculateDistance(_pickupLocation, _destinationLocation);
    const double basePrice = 50;
    const double pricePerKm = 10;
    final double totalPrice = basePrice + (distance * pricePerKm);
    final double pricePerPassenger = totalPrice / _maxPassengers;

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CooperativeRideMatchScreen(
          userId: widget.userId,
          pickupLocation: _pickupLocation,
          destinationLocation: _destinationLocation,
          requestedTime: _selectedTime,
          maxPassengers: _maxPassengers,
          maxDeviation: _maxDeviation,
          womenOnly: _womenOnly,
          totalPrice: totalPrice,
          pricePerPassenger: pricePerPassenger,
          pickupAddress: _pickupAddress,
          destinationAddress: _destinationAddress,
        ),
      ),
    );
  }

  double _calculateDistance(LatLng start, LatLng end) {
    const double R = 6371;
    final double dLat = _toRadians(end.latitude - start.latitude);
    final double dLon = _toRadians(end.longitude - start.longitude);
    final double lat1 = _toRadians(start.latitude);
    final double lat2 = _toRadians(end.latitude);

    final double a = math.sin(dLat / 2) * math.sin(dLat / 2) +
        math.sin(dLon / 2) *
            math.sin(dLon / 2) *
            math.cos(lat1) *
            math.cos(lat2);
    final double c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));

    return R * c;
  }

  double _toRadians(double degree) => degree * (math.pi / 180);

  @override
  Widget build(BuildContext context) {
    final themeColor = _isDarkMode ? Colors.white : const Color(0xFF0C1D2A);
    final String formattedMinutes =
        _selectedTime.minute.toString().padLeft(2, '0');

    return Scaffold(
      backgroundColor:
          _isDarkMode ? const Color(0xFF0C1D2A) : const Color(0xFFF4F7FA),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text('Covoiturage',
            style: TextStyle(
                fontSize: 24, fontWeight: FontWeight.w900, color: themeColor)),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(_isDarkMode ? Icons.brightness_2 : Icons.brightness_5,
                color: _isDarkMode ? Colors.white : Colors.blue),
            onPressed: () => setState(() => _isDarkMode = !_isDarkMode),
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            SizedBox(
              height: 200,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: GoogleMap(
                  initialCameraPosition:
                      CameraPosition(target: _pickupLocation, zoom: 13),
                  onMapCreated: (controller) => _mapController = controller,
                  myLocationEnabled: true,
                  markers: {
                    Marker(
                        markerId: const MarkerId('pickup'),
                        position: _pickupLocation,
                        icon: BitmapDescriptor.defaultMarkerWithHue(
                            BitmapDescriptor.hueBlue)),
                    Marker(
                        markerId: const MarkerId('destination'),
                        position: _destinationLocation,
                        icon: BitmapDescriptor.defaultMarkerWithHue(
                            BitmapDescriptor.hueRed)),
                  },
                ),
              ),
            ),
            const SizedBox(height: 24),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                  color: _isDarkMode ? const Color(0xFF152A3C) : Colors.white,
                  borderRadius: BorderRadius.circular(20)),
              child: Column(
                children: [
                  Text('🚗 Covoiturage - تنقل تشاركي',
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                          color: themeColor)),
                  const SizedBox(height: 8),
                  Text('Partage ton trajet et réduis le prix !',
                      style: TextStyle(
                          fontSize: 13, color: themeColor.withOpacity(0.6))),
                ],
              ),
            ),
            const SizedBox(height: 24),
            TextFormField(
              controller: _nameController,
              style: TextStyle(color: themeColor),
              decoration: InputDecoration(
                  labelText: 'Nom du passager',
                  labelStyle: TextStyle(color: themeColor.withOpacity(0.6)),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16)),
                  icon: const Icon(Icons.person, color: Colors.blue)),
              validator: (value) =>
                  (value == null || value.trim().isEmpty) ? 'Nom requis' : null,
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _phoneController,
              keyboardType: TextInputType.phone,
              style: TextStyle(color: themeColor),
              decoration: InputDecoration(
                  labelText: 'Téléphone',
                  labelStyle: TextStyle(color: themeColor.withOpacity(0.6)),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16)),
                  icon: const Icon(Icons.phone, color: Colors.blue)),
              validator: (value) => (value == null || value.trim().isEmpty)
                  ? 'Téléphone requis'
                  : null,
            ),
            const SizedBox(height: 24),
            InkWell(
                onTap: _selectPickupLocation,
                borderRadius: BorderRadius.circular(16),
                child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                        color: _isDarkMode
                            ? const Color(0xFF152A3C)
                            : Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: Colors.blue)),
                    child: Row(children: [
                      const Icon(Icons.location_on, color: Colors.blue),
                      const SizedBox(width: 12),
                      Expanded(
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                            Text('Point de départ',
                                style: TextStyle(
                                    fontSize: 13,
                                    color: themeColor.withOpacity(0.6))),
                            Text(_pickupAddress,
                                style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: themeColor))
                          ]))
                    ]))),
            const SizedBox(height: 16),
            InkWell(
                onTap: _selectDestination,
                borderRadius: BorderRadius.circular(16),
                child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                        color: _isDarkMode
                            ? const Color(0xFF152A3C)
                            : Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: Colors.red)),
                    child: Row(children: [
                      const Icon(Icons.location_on, color: Colors.red),
                      const SizedBox(width: 12),
                      Expanded(
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                            Text('Destination',
                                style: TextStyle(
                                    fontSize: 13,
                                    color: themeColor.withOpacity(0.6))),
                            Text(_destinationAddress,
                                style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: themeColor))
                          ]))
                    ]))),
            const SizedBox(height: 24),
            InkWell(
                onTap: _selectDateTime,
                borderRadius: BorderRadius.circular(16),
                child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                        color: _isDarkMode
                            ? const Color(0xFF152A3C)
                            : Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: Colors.blue)),
                    child: Row(children: [
                      const Icon(Icons.calendar_today, color: Colors.blue),
                      const SizedBox(width: 12),
                      Expanded(
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                            Text('Date et heure',
                                style: TextStyle(
                                    fontSize: 13,
                                    color: themeColor.withOpacity(0.6))),
                            Text(
                                '${_selectedTime.day}/${_selectedTime.month}/${_selectedTime.year} ${_selectedTime.hour}:$formattedMinutes',
                                style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: themeColor))
                          ]))
                    ]))),
            const SizedBox(height: 24),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                  color: _isDarkMode ? const Color(0xFF152A3C) : Colors.white,
                  borderRadius: BorderRadius.circular(20)),
              child: Column(
                children: [
                  Row(
                    children: [
                      Text('Passagers max:',
                          style: TextStyle(
                              fontSize: 14,
                              color: themeColor.withOpacity(0.6))),
                      const Spacer(),
                      Text(_maxPassengers.toString(),
                          style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.blue))
                    ],
                  ),
                  const SizedBox(height: 12),
                  Slider(
                      value: _maxPassengers.toDouble(),
                      min: 2,
                      max: 6,
                      divisions: 4,
                      activeColor: Colors.blue,
                      onChanged: (value) =>
                          setState(() => _maxPassengers = value.toInt())),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                  color: _isDarkMode ? const Color(0xFF152A3C) : Colors.white,
                  borderRadius: BorderRadius.circular(20)),
              child: Column(
                children: [
                  Row(
                    children: [
                      Text('Max déviation (km):',
                          style: TextStyle(
                              fontSize: 14,
                              color: themeColor.withOpacity(0.6))),
                      const Spacer(),
                      Text(_maxDeviation.toStringAsFixed(1),
                          style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.blue))
                    ],
                  ),
                  const SizedBox(height: 12),
                  Slider(
                      value: _maxDeviation,
                      min: 0.5,
                      max: 5,
                      divisions: 9,
                      activeColor: Colors.blue,
                      onChanged: (value) =>
                          setState(() => _maxDeviation = value)),
                ],
              ),
            ),
            const SizedBox(height: 16),
            SwitchListTile(
                title: Text('Femmes uniquement',
                    style: TextStyle(color: themeColor)),
                value: _womenOnly,
                onChanged: (value) => setState(() => _womenOnly = value),
                activeColor: Colors.blue),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: _requestCooperativeRide,
              style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                  minimumSize: const Size(double.infinity, 56),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(22))),
              child: const Text('Rechercher covoiturage',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            ),
          ],
        ),
      ),
    );
  }
}

class MapPickerScreen extends StatefulWidget {
  final LatLng initialPosition;
  final String title;

  const MapPickerScreen(
      {super.key, required this.initialPosition, required this.title});

  @override
  State<MapPickerScreen> createState() => _MapPickerScreenState();
}

class _MapPickerScreenState extends State<MapPickerScreen> {
  late LatLng _selectedPosition;

  @override
  void initState() {
    super.initState();
    _selectedPosition = widget.initialPosition;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: Stack(
        children: [
          GoogleMap(
            initialCameraPosition:
                CameraPosition(target: widget.initialPosition, zoom: 14),
            onTap: (LatLng pos) => setState(() => _selectedPosition = pos),
            markers: {
              Marker(
                  markerId: const MarkerId('selected'),
                  position: _selectedPosition)
            },
          ),
          Positioned(
              bottom: 20,
              left: 20,
              right: 20,
              child: ElevatedButton(
                onPressed: () => Navigator.pop(context, _selectedPosition),
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(22))),
                child: const Text('Valider',
                    style:
                        TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              )),
        ],
      ),
    );
  }
}
