import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:app_constantine/theme_wassalny.dart';
import 'package:app_constantine/cooperative_passenger.dart';
import 'package:app_constantine/screens/cooperative_ride_match_screen.dart';

class CooperativeRideSuggestion extends StatefulWidget {
  final LatLng pickupLocation;
  final LatLng destinationLocation;
  final double totalPrice;
  final double pricePerPassenger;
  final String pickupAddress;
  final String destinationAddress;

  const CooperativeRideSuggestion({
    super.key,
    required this.pickupLocation,
    required this.destinationLocation,
    required this.totalPrice,
    required this.pricePerPassenger,
    required this.pickupAddress,
    required this.destinationAddress,
  });

  @override
  State<CooperativeRideSuggestion> createState() =>
      _CooperativeRideSuggestionState();
}

class _CooperativeRideSuggestionState extends State<CooperativeRideSuggestion> {
  List<CooperativePassenger> _suggestedPassengers = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadSuggestedPassengers();
  }

  void _loadSuggestedPassengers() {
    Future.delayed(const Duration(seconds: 1), () {
      setState(() {
        _suggestedPassengers = [
          CooperativePassenger(
            name: 'Sarah',
            phone: '+213 6XX 123 456',
            pickupLocation: LatLng(
              widget.pickupLocation.latitude + 0.005,
              widget.pickupLocation.longitude + 0.002,
            ),
            destinationLocation: widget.destinationLocation,
            requestedTime: DateTime.now(),
            maxDeviation: 1.0,
            womenOnly: false,
          ),
          CooperativePassenger(
            name: 'Mohamed',
            phone: '+213 7XX 234 567',
            pickupLocation: LatLng(
              widget.pickupLocation.latitude + 0.003,
              widget.pickupLocation.longitude - 0.001,
            ),
            destinationLocation: widget.destinationLocation,
            requestedTime: DateTime.now(),
            maxDeviation: 1.5,
            womenOnly: false,
          ),
        ];
        _isLoading = false;
      });
    });
  }

  void _acceptSuggestion() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => CooperativeRideMatchScreen(
          userId: 'user123',
          pickupLocation: widget.pickupLocation,
          destinationLocation: widget.destinationLocation,
          requestedTime: DateTime.now(),
          maxPassengers: 4,
          maxDeviation: 1.0,
          womenOnly: false,
          totalPrice: widget.totalPrice,
          pricePerPassenger: widget.pricePerPassenger,
          pickupAddress: widget.pickupAddress,
          destinationAddress: widget.destinationAddress,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WassalnyTheme.bgLight,
      appBar: WassalnyTheme.buildAppBar('Ride Suggestion'),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: WassalnyTheme.accent))
          : ListView(
              padding: const EdgeInsets.all(20),
              children: [
                Container(
                  padding: const EdgeInsets.all(24),
                  decoration: WassalnyTheme.cardDecoration,
                  child: Column(
                    children: [
                      Icon(Icons.people_alt,
                          color: WassalnyTheme.success, size: 48),
                      const SizedBox(height: 16),
                      const Text('Shared Ride Available!',
                          style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.w900,
                              color: WassalnyTheme.primary)),
                      const SizedBox(height: 8),
                      Text('Save ${(20).toString()}% by sharing your ride',
                          style: WassalnyTheme.bodyText),
                      const SizedBox(height: 16),
                      _PriceBadge(
                        label: 'Regular price',
                        value: '${widget.totalPrice.toStringAsFixed(0)} DA',
                      ),
                      const SizedBox(height: 8),
                      _PriceBadge(
                        label: 'Shared price',
                        value:
                            '${widget.pricePerPassenger.toStringAsFixed(0)} DA',
                        isDiscounted: true,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                if (_suggestedPassengers.isNotEmpty) ...[
                  const Text('Suggested Passengers',
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                          color: WassalnyTheme.primary)),
                  const SizedBox(height: 12),
                  for (final p in _suggestedPassengers)
                    Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      padding: const EdgeInsets.all(16),
                      decoration: WassalnyTheme.cardDecoration,
                      child: Row(
                        children: [
                          Container(
                            width: 48,
                            height: 48,
                            decoration: BoxDecoration(
                              color: WassalnyTheme.accent.withOpacity(0.12),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.person,
                                color: WassalnyTheme.accent, size: 24),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(p.name,
                                    style: const TextStyle(
                                        fontWeight: FontWeight.w700,
                                        fontSize: 15,
                                        color: WassalnyTheme.primary)),
                                Text(p.phone,
                                    style: WassalnyTheme.cardSubtitle),
                              ],
                            ),
                          ),
                          Icon(Icons.chevron_right_rounded,
                              color: WassalnyTheme.textSecondary),
                        ],
                      ),
                    ),
                ],
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  height: 54,
                  child: ElevatedButton(
                    onPressed: _acceptSuggestion,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: WassalnyTheme.success,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16)),
                    ),
                    child: const Text('Accept Shared Ride',
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w700)),
                  ),
                ),
              ],
            ),
    );
  }
}

class _PriceBadge extends StatelessWidget {
  final String label;
  final String value;
  final bool isDiscounted;

  const _PriceBadge({
    required this.label,
    required this.value,
    this.isDiscounted = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      decoration: BoxDecoration(
        color: isDiscounted
            ? WassalnyTheme.success.withOpacity(0.12)
            : const Color(0xFFF1F5F9),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Text(label,
            style: TextStyle(
                fontSize: 13,
                color: isDiscounted
                    ? WassalnyTheme.success
                    : WassalnyTheme.textSecondary,
                fontWeight: FontWeight.w500)),
        const SizedBox(width: 8),
        Text(value,
            style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w900,
                color: isDiscounted
                    ? WassalnyTheme.success
                    : WassalnyTheme.primary)),
      ]),
    );
  }
}
