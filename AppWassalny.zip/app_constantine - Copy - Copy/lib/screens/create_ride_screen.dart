import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geolocator/geolocator.dart';
import 'package:app_constantine/screens/cooperative_ride_suggestion_screen.dart';

class CreateRideScreen extends StatefulWidget {
  const CreateRideScreen({Key? key}) : super(key: key);

  @override
  State<CreateRideScreen> createState() => _CreateRideScreenState();
}

class _CreateRideScreenState extends State<CreateRideScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();

  LatLng? _pickupLocation;
  LatLng? _destinationLocation;

  String _pickupPlaceName = 'Départ: Cliquez sur la carte';
  String _destinationPlaceName = 'Arrivée: Cliquez sur la carte';

  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;

  GoogleMapController? _mapController;
  LatLng? _currentPosition;
  Set<Marker> _markers = {};

  double _totalPrice = 0;
  bool _isSubmitting = false;

  @override
  void initState() {
    super.initState();
    _getCurrentLocation();
  }

  Future<void> _getCurrentLocation() async {
    try {
      LocationPermission permission = await Geolocator.requestPermission();

      if (permission == LocationPermission.denied) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Permission de localisation refusée')),
        );
        return;
      }

      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      setState(() {
        _currentPosition = LatLng(position.latitude, position.longitude);
        _pickupLocation = _currentPosition;
        _pickupPlaceName = 'Position actuelle';
      });

      if (_mapController != null) {
        _mapController!.animateCamera(
          CameraUpdate.newCameraPosition(
            CameraPosition(target: _currentPosition!, zoom: 15),
          ),
        );
      }

      _markers.add(
        Marker(
          markerId: MarkerId('pickup'),
          position: _currentPosition!,
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
          infoWindow: InfoWindow(title: _pickupPlaceName),
        ),
      );
    } catch (e) {
      print('Erreur: $e');
    }
  }

  Future<void> _selectDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(Duration(days: 365)),
    );
    if (picked != null) {
      setState(() => _selectedDate = picked);
    }
  }

  Future<void> _selectTime() async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (picked != null) {
      setState(() => _selectedTime = picked);
    }
  }

  String _getPlaceName(LatLng location) {
    if (location.latitude > 36.36 && location.latitude < 36.37) {
      return 'Centre-ville Constantine';
    } else if (location.latitude > 36.35 && location.latitude < 36.36) {
      return 'Chabouna';
    } else if (location.latitude > 36.37 && location.latitude < 36.38) {
      return 'Narrow Bridge';
    } else if (location.latitude > 36.34 && location.latitude < 36.35) {
      return 'Zighoud Youcef';
    } else if (location.latitude > 36.38 && location.latitude < 36.39) {
      return 'Ben Hammad';
    } else {
      return 'Lieu ${location.latitude.toStringAsFixed(2)}, ${location.longitude.toStringAsFixed(2)}';
    }
  }

  void _onMapTapped(LatLng position) {
    if (_pickupLocation == null) {
      setState(() {
        _pickupLocation = position;
        _pickupPlaceName = _getPlaceName(position);
      });

      _markers.clear();
      _markers.add(
        Marker(
          markerId: MarkerId('pickup'),
          position: position,
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
          infoWindow: InfoWindow(title: _pickupPlaceName),
        ),
      );
    } else if (_destinationLocation == null) {
      setState(() {
        _destinationLocation = position;
        _destinationPlaceName = _getPlaceName(position);
      });

      _markers.clear();
      _markers.add(
        Marker(
          markerId: MarkerId('pickup'),
          position: _pickupLocation!,
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
          infoWindow: InfoWindow(title: _pickupPlaceName),
        ),
      );
      _markers.add(
        Marker(
          markerId: MarkerId('destination'),
          position: position,
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
          infoWindow: InfoWindow(title: _destinationPlaceName),
        ),
      );

      _calculatePrice();
    } else {
      setState(() {
        _pickupLocation = position;
        _pickupPlaceName = _getPlaceName(position);
        _destinationLocation = null;
        _destinationPlaceName = 'Arrivée: Cliquez sur la carte';
      });

      _markers.clear();
      _markers.add(
        Marker(
          markerId: MarkerId('pickup'),
          position: position,
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
          infoWindow: InfoWindow(title: _pickupPlaceName),
        ),
      );

      _calculatePrice();
    }
  }

  void _calculatePrice() {
    if (_pickupLocation != null && _destinationLocation != null) {
      double latDiff =
          (_destinationLocation!.latitude - _pickupLocation!.latitude).abs();
      double lonDiff =
          (_destinationLocation!.longitude - _pickupLocation!.longitude).abs();
      double distance = (latDiff * 111 + lonDiff * 111);

      if (distance < 1) distance = 1;

      _totalPrice = distance * 100;
    }
  }

  Future<List<Map<String, dynamic>>> _findSimilarRides() async {
    try {
      final query = await FirebaseFirestore.instance
          .collection('ride_requests')
          .where('status', isEqualTo: 'pending')
          .where('type', isEqualTo: 'taxi')
          .where('pickupLatitude',
              isGreaterThanOrEqualTo: _pickupLocation!.latitude - 0.05)
          .where('pickupLatitude',
              isLessThanOrEqualTo: _pickupLocation!.latitude + 0.05)
          .where('pickupLongitude',
              isGreaterThanOrEqualTo: _pickupLocation!.longitude - 0.05)
          .where('pickupLongitude',
              isLessThanOrEqualTo: _pickupLocation!.longitude + 0.05)
          .where('destinationLatitude',
              isGreaterThanOrEqualTo: _destinationLocation!.latitude - 0.05)
          .where('destinationLatitude',
              isLessThanOrEqualTo: _destinationLocation!.latitude + 0.05)
          .where('destinationLongitude',
              isGreaterThanOrEqualTo: _destinationLocation!.longitude - 0.05)
          .where('destinationLongitude',
              isLessThanOrEqualTo: _destinationLocation!.longitude + 0.05)
          .get();

      List<Map<String, dynamic>> similarRides = [];

      for (var doc in query.docs) {
        final String timeStr = doc['time'] as String;
        final List<String> timeParts = timeStr.split(':');
        final int otherHour = int.parse(timeParts[0]);
        final int otherMinute = int.parse(timeParts[1]);

        final DateTime otherTime =
            DateTime.parse(doc['date'] as String).copyWith(
          hour: otherHour,
          minute: otherMinute,
        );

        final Duration timeDiff = otherTime.difference(DateTime.now()).abs();

        if (timeDiff.inMinutes <= 30) {
          similarRides.add({
            'id': doc.id,
            'name': doc['name'],
            'phone': doc['phone'],
            'pickupPlace': doc['pickupPlace'],
            'destinationPlace': doc['destinationPlace'],
            'time': doc['time'],
          });
        }
      }

      return similarRides;
    } catch (e) {
      print('Erreur recherche similar: $e');
      return [];
    }
  }

  Future<void> _submitRequest() async {
    if (_nameController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Veuillez entrer votre nom')),
      );
      return;
    }
    if (_phoneController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Veuillez entrer votre téléphone')),
      );
      return;
    }
    if (_pickupLocation == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Veuillez sélectionner le départ sur la carte')),
      );
      return;
    }
    if (_destinationLocation == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text('Veuillez sélectionner l\'arrivée sur la carte')),
      );
      return;
    }
    if (_selectedDate == null || _selectedTime == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Veuillez sélectionner date et heure')),
      );
      return;
    }

    setState(() => _isSubmitting = true);

    try {
      final similarRides = await _findSimilarRides();

      if (!mounted) return;

      setState(() => _isSubmitting = false);

      if (similarRides.isNotEmpty) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => CooperativeRideSuggestion(
              pickupLocation: _pickupLocation!,
              destinationLocation: _destinationLocation!,
              totalPrice: _totalPrice,
              pricePerPassenger: _totalPrice / (similarRides.length + 1),
              pickupAddress: _pickupPlaceName,
              destinationAddress: _destinationPlaceName,
            ),
          ),
        );
      } else {
        final rideRequest = {
          'userId': FirebaseAuth.instance.currentUser?.uid,
          'name': _nameController.text,
          'phone': _phoneController.text,
          'pickupPlace': _pickupPlaceName,
          'destinationPlace': _destinationPlaceName,
          'pickupLatitude': _pickupLocation!.latitude,
          'pickupLongitude': _pickupLocation!.longitude,
          'destinationLatitude': _destinationLocation!.latitude,
          'destinationLongitude': _destinationLocation!.longitude,
          'date': _selectedDate!.toIso8601String(),
          'time': '${_selectedTime!.hour}:${_selectedTime!.minute}',
          'totalPrice': _totalPrice,
          'type': 'taxi',
          'status': 'pending',
          'createdAt': FieldValue.serverTimestamp(),
        };

        await FirebaseFirestore.instance
            .collection('ride_requests')
            .add(rideRequest);

        if (!mounted) return;

        Navigator.pop(context);

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Taxi demandé ! Chauffeur en recherche...')),
        );
      }
    } catch (e) {
      setState(() => _isSubmitting = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erreur: $e')),
      );
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _mapController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final themeColor = const Color(0xFF0C1D2A);

    return Scaffold(
      backgroundColor: const Color(0xFFF4F7FA),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF4F7FA),
        elevation: 0,
        title: Text(
          'Appeler un taxi',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w900,
            color: themeColor,
          ),
        ),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.04),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    Icon(Icons.person, color: Colors.blue, size: 20),
                    const SizedBox(width: 12),
                    Text('Votre nom:',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: themeColor,
                        )),
                  ],
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _nameController,
                  decoration: InputDecoration(
                    hintText: 'Entrez votre nom',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.04),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    Icon(Icons.phone, color: Colors.green, size: 20),
                    const SizedBox(width: 12),
                    Text('Téléphone:',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: themeColor,
                        )),
                  ],
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _phoneController,
                  decoration: InputDecoration(
                    hintText: '+213...',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  keyboardType: TextInputType.phone,
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'Cliquez sur la carte pour sélectionner:',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: themeColor,
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 250,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: GoogleMap(
                initialCameraPosition: CameraPosition(
                  target: _currentPosition ?? LatLng(36.3650, 6.6147),
                  zoom: 13,
                ),
                onMapCreated: (controller) => _mapController = controller,
                myLocationEnabled: true,
                myLocationButtonEnabled: true,
                markers: _markers,
                onTap: _onMapTapped,
              ),
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.04),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Row(
              children: [
                Icon(Icons.location_on, color: Colors.blue),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Départ:',
                        style: TextStyle(
                          fontSize: 12,
                          color: themeColor.withOpacity(0.6),
                        ),
                      ),
                      Text(
                        _pickupPlaceName,
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: _pickupLocation != null
                              ? themeColor
                              : themeColor.withOpacity(0.5),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.04),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Row(
              children: [
                Icon(Icons.location_on, color: Colors.red),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Arrivée:',
                        style: TextStyle(
                          fontSize: 12,
                          color: themeColor.withOpacity(0.6),
                        ),
                      ),
                      Text(
                        _destinationPlaceName,
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: _destinationLocation != null
                              ? themeColor
                              : themeColor.withOpacity(0.5),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.04),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    Icon(Icons.calendar_today, color: Colors.blue, size: 20),
                    const SizedBox(width: 12),
                    Text('Date:',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: themeColor,
                        )),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  _selectedDate != null
                      ? '${_selectedDate!.day}/${_selectedDate!.month}/${_selectedDate!.year}'
                      : 'Sélectionner date',
                  style: TextStyle(
                    fontSize: 16,
                    color: _selectedDate != null
                        ? themeColor
                        : themeColor.withOpacity(0.5),
                  ),
                ),
                const SizedBox(height: 12),
                ElevatedButton(
                  onPressed: _selectDate,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child:
                      Text('Sélectionner date', style: TextStyle(fontSize: 14)),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.04),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    Icon(Icons.access_time, color: Colors.green, size: 20),
                    const SizedBox(width: 12),
                    Text('Heure:',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: themeColor,
                        )),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  _selectedTime != null
                      ? '${_selectedTime!.hour}:${_selectedTime!.minute.toString().padLeft(2, '0')}'
                      : 'Sélectionner heure',
                  style: TextStyle(
                    fontSize: 16,
                    color: _selectedTime != null
                        ? themeColor
                        : themeColor.withOpacity(0.5),
                  ),
                ),
                const SizedBox(height: 12),
                ElevatedButton(
                  onPressed: _selectTime,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: Text('Sélectionner heure',
                      style: TextStyle(fontSize: 14)),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.04),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    Icon(Icons.attach_money,
                        color: const Color(0xFFF9B813), size: 20),
                    const SizedBox(width: 12),
                    Text(
                      'Prix estimé:',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: themeColor,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  '${_totalPrice.toStringAsFixed(0)} DA',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                    color: const Color(0xFFF9B813),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 30),
          Container(
            width: double.infinity,
            height: 56,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              boxShadow: [
                BoxShadow(
                  color: Colors.blue.withOpacity(0.25),
                  blurRadius: 15,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: ElevatedButton(
              onPressed: _isSubmitting ? null : _submitRequest,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(22),
                ),
              ),
              child: _isSubmitting
                  ? CircularProgressIndicator(
                      color: Colors.white,
                      strokeWidth: 2,
                    )
                  : Text(
                      'Appeler taxi',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }
}
