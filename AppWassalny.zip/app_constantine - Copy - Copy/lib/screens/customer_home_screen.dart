import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geolocator/geolocator.dart';
import 'package:app_constantine/screens/cooperative_ride_suggestion_screen.dart';

class CustomerRideRequestScreen extends StatefulWidget {
  const CustomerRideRequestScreen({Key? key}) : super(key: key);

  @override
  State<CustomerRideRequestScreen> createState() =>
      _CustomerRideRequestScreenState();
}

class _CustomerRideRequestScreenState extends State<CustomerRideRequestScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();

  LatLng? _pickupLocation;
  LatLng? _destinationLocation;

  String _pickupPlaceName = 'Sélectionner sur la carte';
  String _destinationPlaceName = 'Sélectionner sur la carte';

  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;

  int _maxPassengers = 4;
  double _maxDeviation = 0.5;
  bool _womenOnly = false;

  GoogleMapController? _mapController;
  LatLng? _currentPosition;
  Set<Marker> _markers = {};

  double _totalPrice = 0;
  double _pricePerPassenger = 0;

  bool _isSubmitting = false;

  @override
  void initState() {
    super.initState();
    _getCurrentLocation();
  }

  Future<void> _getCurrentLocation() async {
    try {
      LocationPermission permission = await Geolocator.requestPermission();

      if (permission == LocationPermission.denied) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Permission de localisation refusée')),
        );
        return;
      }

      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      setState(() {
        _currentPosition = LatLng(position.latitude, position.longitude);
        _pickupLocation = _currentPosition;
        _pickupPlaceName = 'Position actuelle';
      });

      if (_mapController != null) {
        _mapController!.animateCamera(
          CameraUpdate.newCameraPosition(
            CameraPosition(target: _currentPosition!, zoom: 15),
          ),
        );
      }

      _markers.add(
        Marker(
          markerId: MarkerId('pickup'),
          position: _currentPosition!,
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
          infoWindow: InfoWindow(title: _pickupPlaceName),
        ),
      );
    } catch (e) {
      print('Erreur: $e');
    }
  }

  Future<void> _selectDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(Duration(days: 365)),
    );
    if (picked != null) {
      setState(() => _selectedDate = picked);
    }
  }

  Future<void> _selectTime() async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (picked != null) {
      setState(() => _selectedTime = picked);
    }
  }

  String _getPlaceName(LatLng location) {
    if (location.latitude > 36.36 && location.latitude < 36.37) {
      return 'Centre-ville Constantine';
    } else if (location.latitude > 36.35 && location.latitude < 36.36) {
      return 'Chabouna';
    } else if (location.latitude > 36.37 && location.latitude < 36.38) {
      return 'Narrow Bridge';
    } else if (location.latitude > 36.34 && location.latitude < 36.35) {
      return 'Zighoud Youcef';
    } else if (location.latitude > 36.38 && location.latitude < 36.39) {
      return 'Ben Hammad';
    } else {
      return 'Lieu ${location.latitude.toStringAsFixed(2)}, ${location.longitude.toStringAsFixed(2)}';
    }
  }

  void _onMapTapped(LatLng position) {
    if (_pickupLocation == null) {
      setState(() {
        _pickupLocation = position;
        _pickupPlaceName = _getPlaceName(position);
      });

      _markers.clear();
      _markers.add(
        Marker(
          markerId: MarkerId('pickup'),
          position: position,
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
          infoWindow: InfoWindow(title: _pickupPlaceName),
        ),
      );
    } else if (_destinationLocation == null) {
      setState(() {
        _destinationLocation = position;
        _destinationPlaceName = _getPlaceName(position);
      });

      _markers.clear();
      _markers.add(
        Marker(
          markerId: MarkerId('pickup'),
          position: _pickupLocation!,
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
          infoWindow: InfoWindow(title: _pickupPlaceName),
        ),
      );
      _markers.add(
        Marker(
          markerId: MarkerId('destination'),
          position: position,
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
          infoWindow: InfoWindow(title: _destinationPlaceName),
        ),
      );

      _calculatePrice();
    } else {
      setState(() {
        _pickupLocation = position;
        _pickupPlaceName = _getPlaceName(position);
        _destinationLocation = null;
        _destinationPlaceName = 'Sélectionner sur la carte';
      });

      _markers.clear();
      _markers.add(
        Marker(
          markerId: MarkerId('pickup'),
          position: position,
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
          infoWindow: InfoWindow(title: _pickupPlaceName),
        ),
      );

      _calculatePrice();
    }
  }

  void _calculatePrice() {
    if (_pickupLocation != null && _destinationLocation != null) {
      double latDiff =
          (_destinationLocation!.latitude - _pickupLocation!.latitude).abs();
      double lonDiff =
          (_destinationLocation!.longitude - _pickupLocation!.longitude).abs();
      double distance = (latDiff * 111 + lonDiff * 111);

      if (distance < 1) distance = 1;

      _totalPrice = distance * 100;
      _pricePerPassenger = _totalPrice / _maxPassengers;
    }
  }

  Future<void> _submitRequest() async {
    if (_nameController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Veuillez entrer votre nom')),
      );
      return;
    }
    if (_phoneController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Veuillez entrer votre téléphone')),
      );
      return;
    }
    if (_pickupLocation == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Veuillez sélectionner le départ sur la carte')),
      );
      return;
    }
    if (_destinationLocation == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text('Veuillez sélectionner l\'arrivée sur la carte')),
      );
      return;
    }
    if (_selectedDate == null || _selectedTime == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Veuillez sélectionner date et heure')),
      );
      return;
    }

    setState(() => _isSubmitting = true);

    try {
      final rideRequest = {
        'userId': FirebaseAuth.instance.currentUser?.uid,
        'name': _nameController.text,
        'phone': _phoneController.text,
        'pickupPlace': _pickupPlaceName,
        'destinationPlace': _destinationPlaceName,
        'pickupLatitude': _pickupLocation!.latitude,
        'pickupLongitude': _pickupLocation!.longitude,
        'destinationLatitude': _destinationLocation!.latitude,
        'destinationLongitude': _destinationLocation!.longitude,
        'date': _selectedDate!.toIso8601String(),
        'time': '${_selectedTime!.hour}:${_selectedTime!.minute}',
        'maxPassengers': _maxPassengers,
        'maxDeviation': _maxDeviation,
        'womenOnly': _womenOnly,
        'totalPrice': _totalPrice,
        'pricePerPassenger': _pricePerPassenger,
        'status': 'pending',
        'createdAt': FieldValue.serverTimestamp(),
      };

      await FirebaseFirestore.instance
          .collection('ride_requests')
          .add(rideRequest);

      if (!mounted) return;

      setState(() => _isSubmitting = false);

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => CooperativeRideSuggestion(
            pickupLocation: _pickupLocation!,
            destinationLocation: _destinationLocation!,
            totalPrice: _totalPrice,
            pricePerPassenger: _pricePerPassenger,
            pickupAddress: _pickupPlaceName,
            destinationAddress: _destinationPlaceName,
          ),
        ),
      );
    } catch (e) {
      setState(() => _isSubmitting = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erreur: $e')),
      );
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _mapController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final themeColor = const Color(0xFF0C1D2A);

    return Scaffold(
      backgroundColor: const Color(0xFFF4F7FA),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF4F7FA),
        elevation: 0,
        title: Text(
          'Demander une course',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w900,
            color: themeColor,
          ),
        ),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.04),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Table(
              border: null,
              children: [
                TableRow(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Row(
                        children: [
                          Icon(Icons.person, color: Colors.blue, size: 20),
                          const SizedBox(width: 12),
                          Text('Nom:',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                color: themeColor,
                              )),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: TextFormField(
                        controller: _nameController,
                        decoration: InputDecoration(
                          hintText: 'Entrez votre nom',
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const TableRow(
                  children: [
                    SizedBox(height: 8, child: Divider()),
                    SizedBox(height: 8, child: Divider()),
                  ],
                ),
                TableRow(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Row(
                        children: [
                          Icon(Icons.phone, color: Colors.green, size: 20),
                          const SizedBox(width: 12),
                          Text('Téléphone:',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                color: themeColor,
                              )),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: TextFormField(
                        controller: _phoneController,
                        decoration: InputDecoration(
                          hintText: '+213...',
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        keyboardType: TextInputType.phone,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 250,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: GoogleMap(
                initialCameraPosition: CameraPosition(
                  target: _currentPosition ?? LatLng(36.3650, 6.6147),
                  zoom: 13,
                ),
                onMapCreated: (controller) => _mapController = controller,
                myLocationEnabled: true,
                myLocationButtonEnabled: true,
                markers: _markers,
                onTap: _onMapTapped,
              ),
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.04),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Table(
              border: null,
              children: [
                TableRow(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Row(
                        children: [
                          Icon(Icons.location_on, color: Colors.blue),
                          const SizedBox(width: 12),
                          Text('Départ:',
                              style: TextStyle(
                                fontSize: 12,
                                color: themeColor.withOpacity(0.6),
                              )),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Text(
                        _pickupPlaceName,
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: _pickupLocation != null
                              ? themeColor
                              : themeColor.withOpacity(0.5),
                        ),
                      ),
                    ),
                  ],
                ),
                const TableRow(
                  children: [
                    SizedBox(height: 8, child: Divider()),
                    SizedBox(height: 8, child: Divider()),
                  ],
                ),
                TableRow(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Row(
                        children: [
                          Icon(Icons.location_on, color: Colors.red),
                          const SizedBox(width: 12),
                          Text('Arrivée:',
                              style: TextStyle(
                                fontSize: 12,
                                color: themeColor.withOpacity(0.6),
                              )),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Text(
                        _destinationPlaceName,
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: _destinationLocation != null
                              ? themeColor
                              : themeColor.withOpacity(0.5),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.04),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Table(
              border: null,
              children: [
                TableRow(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Row(
                        children: [
                          Icon(Icons.calendar_today,
                              color: Colors.blue, size: 20),
                          const SizedBox(width: 12),
                          Text('Date:',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                color: themeColor,
                              )),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: ElevatedButton(
                        onPressed: _selectDate,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: Text(
                          _selectedDate != null
                              ? '${_selectedDate!.day}/${_selectedDate!.month}/${_selectedDate!.year}'
                              : 'Sélectionner',
                          style: TextStyle(fontSize: 14),
                        ),
                      ),
                    ),
                  ],
                ),
                const TableRow(
                  children: [
                    SizedBox(height: 8, child: Divider()),
                    SizedBox(height: 8, child: Divider()),
                  ],
                ),
                TableRow(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Row(
                        children: [
                          Icon(Icons.access_time,
                              color: Colors.green, size: 20),
                          const SizedBox(width: 12),
                          Text('Heure:',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                color: themeColor,
                              )),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: ElevatedButton(
                        onPressed: _selectTime,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: Text(
                          _selectedTime != null
                              ? '${_selectedTime!.hour}:${_selectedTime!.minute.toString().padLeft(2, '0')}'
                              : 'Sélectionner',
                          style: TextStyle(fontSize: 14),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.04),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Table(
              border: null,
              children: [
                TableRow(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Row(
                        children: [
                          Icon(Icons.people, color: Colors.blue, size: 20),
                          const SizedBox(width: 12),
                          Text('Max passagers:',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                color: themeColor,
                              )),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          IconButton(
                            onPressed: () {
                              if (_maxPassengers > 1) {
                                setState(() => _maxPassengers--);
                                _calculatePrice();
                              }
                            },
                            icon: Icon(Icons.remove, color: Colors.blue),
                          ),
                          Text(
                            '$_maxPassengers',
                            style: TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.w900,
                              color: themeColor,
                            ),
                          ),
                          IconButton(
                            onPressed: () {
                              if (_maxPassengers < 8) {
                                setState(() => _maxPassengers++);
                                _calculatePrice();
                              }
                            },
                            icon: Icon(Icons.add, color: Colors.blue),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const TableRow(
                  children: [
                    SizedBox(height: 8, child: Divider()),
                    SizedBox(height: 8, child: Divider()),
                  ],
                ),
                TableRow(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Row(
                        children: [
                          Icon(Icons.attach_money,
                              color: const Color(0xFFF9B813), size: 20),
                          const SizedBox(width: 12),
                          Text('Prix total:',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                color: themeColor,
                              )),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            '${_totalPrice.toStringAsFixed(0)} DA',
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w900,
                              color: const Color(0xFFF9B813),
                            ),
                          ),
                          Text(
                            '${_pricePerPassenger.toStringAsFixed(0)} DA/passager',
                            style: TextStyle(
                              fontSize: 12,
                              color: themeColor.withOpacity(0.6),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 30),
          Container(
            width: double.infinity,
            height: 56,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              boxShadow: [
                BoxShadow(
                  color: Colors.green.withOpacity(0.25),
                  blurRadius: 15,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: ElevatedButton(
              onPressed: _isSubmitting ? null : _submitRequest,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(22),
                ),
              ),
              child: _isSubmitting
                  ? CircularProgressIndicator(
                      color: Colors.white,
                      strokeWidth: 2,
                    )
                  : Text(
                      'Envoyer demande',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }
}
