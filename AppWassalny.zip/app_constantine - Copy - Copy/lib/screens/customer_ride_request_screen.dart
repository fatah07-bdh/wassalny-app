import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:app_constantine/theme_wassalny.dart';
import 'package:app_constantine/screens/cooperative_ride_match_screen.dart';
import 'package:app_constantine/screens/ride_confirmation_screen.dart';

class CustomerRideRequestScreen extends StatefulWidget {
  const CustomerRideRequestScreen({super.key});

  @override
  State<CustomerRideRequestScreen> createState() =>
      _CustomerRideRequestScreenState();
}

class _CustomerRideRequestScreenState extends State<CustomerRideRequestScreen> {
  GoogleMapController? _mapController;
  LatLng? _pickupLocation;
  LatLng? _destinationLocation;
  LatLng _currentPosition = const LatLng(36.3650, 6.6147);
  Marker? _pickupMarker;
  Marker? _destinationMarker;
  Marker? _currentMarker;
  Set<Marker> _markers = {};

  String _pickupAddress = 'Pickup location';
  String _destinationAddress = 'Destination';

  DateTime _selectedDate = DateTime.now();
  TimeOfDay _selectedTime = TimeOfDay.now();

  double _estimatedPrice = 0;
  double _distanceKm = 0;

  bool _isShared = true;
  int _maxPassengers = 4;
  bool _isLoading = true;

  final _pickupCtrl = TextEditingController();
  final _destinationCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    _pickupCtrl.dispose();
    _destinationCtrl.dispose();
    super.dispose();
  }

  void _simulateCurrentLocation() {
    setState(() {
      _currentMarker = Marker(
        markerId: MarkerId('current'),
        position: _currentPosition,
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
      );
      _markers.add(_currentMarker!);
      _isLoading = false;
    });
  }

  void _onMapTap(LatLng position) {
    if (_pickupLocation == null) {
      setState(() {
        _pickupLocation = position;
        _pickupMarker = Marker(
          markerId: MarkerId('pickup'),
          position: position,
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
        );
        _markers.add(_pickupMarker!);
      });
      _pickupCtrl.text =
          'Pickup: ${position.latitude.toStringAsFixed(4)}, ${position.longitude.toStringAsFixed(4)}';
      _pickupAddress =
          'Pickup: ${position.latitude.toStringAsFixed(2)}, ${position.longitude.toStringAsFixed(2)}';
    } else if (_destinationLocation == null) {
      setState(() {
        _destinationLocation = position;
        _destinationMarker = Marker(
          markerId: MarkerId('destination'),
          position: position,
          icon:
              BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueAzure),
        );
        _markers.add(_destinationMarker!);
      });
      _destinationCtrl.text =
          'Destination: ${position.latitude.toStringAsFixed(4)}, ${position.longitude.toStringAsFixed(4)}';
      _destinationAddress =
          'Destination: ${position.latitude.toStringAsFixed(2)}, ${position.longitude.toStringAsFixed(2)}';
      _calculatePriceAndDistance();
    }
  }

  void _calculatePriceAndDistance() {
    if (_pickupLocation != null && _destinationLocation != null) {
      double distance =
          _calculateDistance(_pickupLocation!, _destinationLocation!);
      setState(() {
        _distanceKm = distance;
        _estimatedPrice = distance * 150;
      });
    }
  }

  double _calculateDistance(LatLng start, LatLng end) {
    double latDiff = (end.latitude - start.latitude).abs();
    double lngDiff = (end.longitude - start.longitude).abs();
    return (latDiff * 111 + lngDiff * 85);
  }

  Future<void> _selectDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 30)),
    );
    if (picked != null) setState(() => _selectedDate = picked);
  }

  Future<void> _selectTime() async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: _selectedTime,
    );
    if (picked != null) setState(() => _selectedTime = picked);
  }

  void _confirmRide() {
    if (_pickupLocation == null || _destinationLocation == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Please select pickup and destination on map')),
      );
      return;
    }

    if (_isShared) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => CooperativeRideMatchScreen(
            userId: 'test-user-id',
            pickupLocation: _pickupLocation!,
            destinationLocation: _destinationLocation!,
            requestedTime: DateTime(_selectedDate.year, _selectedDate.month,
                _selectedDate.day, _selectedTime.hour, _selectedTime.minute),
            maxPassengers: _maxPassengers,
            maxDeviation: 1.0,
            womenOnly: false,
            totalPrice: _estimatedPrice,
            pricePerPassenger: _estimatedPrice / _maxPassengers,
            pickupAddress: _pickupAddress,
            destinationAddress: _destinationAddress,
          ),
        ),
      );
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => RideConfirmationScreen(
            clientName: 'Karim',
            clientPhone: '+213 7XX XXX XXX',
            driverName: 'Ali',
            driverPlate: '58-123-T',
            driverTaxiNumber: 'TAXI-12345',
            pickupAddress: _pickupAddress,
            destinationAddress: _destinationAddress,
            distanceKm: _distanceKm,
            price: _estimatedPrice,
            isShared: false,
            discountPercentage: 0,
            numberOfPassengers: 1,
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    _simulateCurrentLocation();

    return Scaffold(
      backgroundColor: WassalnyTheme.bgLight,
      appBar: WassalnyTheme.buildAppBar('Book a Ride'),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: SizedBox(
                height: 300,
                child: Stack(
                  children: [
                    GoogleMap(
                      initialCameraPosition: CameraPosition(
                        target: _currentPosition,
                        zoom: 13,
                      ),
                      onMapCreated: (c) => _mapController = c,
                      myLocationEnabled: false,
                      myLocationButtonEnabled: false,
                      zoomControlsEnabled: false,
                      onTap: _onMapTap,
                      markers: _markers,
                    ),
                    Positioned(
                      top: 12,
                      left: 12,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 8),
                        decoration: BoxDecoration(
                          color: WassalnyTheme.primary,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: const Text('Tap: Pickup → Destination',
                            style: TextStyle(
                                color: Color.fromARGB(255, 0, 0, 0),
                                fontSize: 11)),
                      ),
                    ),
                    Positioned(
                      bottom: 12,
                      right: 12,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: WassalnyTheme.accentBlue,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(children: [
                          Icon(Icons.location_on,
                              color: Colors.white, size: 14),
                          const SizedBox(width: 4),
                          const Text('My Location',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600)),
                        ]),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: WassalnyTheme.cardDecoration,
              child: Column(
                children: [
                  Row(children: [
                    Container(
                      width: 32,
                      height: 32,
                      decoration: BoxDecoration(
                        color: WassalnyTheme.accentBlue.withOpacity(0.12),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.location_on,
                          color: WassalnyTheme.accentBlue, size: 18),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: TextField(
                        style: TextStyle(color: Colors.black, fontSize: 14),
                        controller: _pickupCtrl,
                        enabled: false,
                        decoration: InputDecoration(
                          hintText: 'Pickup location',
                          border: InputBorder.none,
                          hintStyle: TextStyle(
                              color: WassalnyTheme.textSecondary, fontSize: 14),
                          contentPadding: EdgeInsets.zero,
                        ),
                      ),
                    ),
                  ]),
                  const SizedBox(height: 12),
                  Row(children: [
                    Container(
                      width: 32,
                      height: 32,
                      decoration: BoxDecoration(
                        color: WassalnyTheme.danger.withOpacity(0.12),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.location_on,
                          color: WassalnyTheme.danger, size: 18),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: TextField(
                        style: TextStyle(color: Colors.black, fontSize: 14),
                        controller: _destinationCtrl,
                        enabled: false,
                        decoration: InputDecoration(
                          hintText: 'Destination',
                          border: InputBorder.none,
                          hintStyle: TextStyle(
                              color: WassalnyTheme.textSecondary, fontSize: 14),
                          contentPadding: EdgeInsets.zero,
                        ),
                      ),
                    ),
                  ]),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Row(children: [
              Expanded(
                child: GestureDetector(
                  onTap: _selectDate,
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: WassalnyTheme.cardDecoration,
                    child: Column(
                      children: [
                        Icon(Icons.calendar_today,
                            color: WassalnyTheme.accent, size: 24),
                        const SizedBox(height: 8),
                        Text(
                            '${_selectedDate.day}/${_selectedDate.month}/${_selectedDate.year}',
                            style: WassalnyTheme.cardTitle),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: GestureDetector(
                  onTap: _selectTime,
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: WassalnyTheme.cardDecoration,
                    child: Column(
                      children: [
                        Icon(Icons.access_time,
                            color: WassalnyTheme.accent, size: 24),
                        const SizedBox(height: 8),
                        Text(
                            '${_selectedTime.hour}:${_selectedTime.minute.toString().padLeft(2, '0')}',
                            style: WassalnyTheme.cardTitle),
                      ],
                    ),
                  ),
                ),
              ),
            ]),
            const SizedBox(height: 20),
            if (_pickupLocation != null && _destinationLocation != null) ...[
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: WassalnyTheme.accent.withOpacity(0.10),
                  borderRadius: BorderRadius.circular(16),
                  border:
                      Border.all(color: WassalnyTheme.accent.withOpacity(0.3)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Distance',
                            style: TextStyle(
                                fontSize: 12,
                                color: WassalnyTheme.textSecondary,
                                fontWeight: FontWeight.w600)),
                        const SizedBox(height: 4),
                        Text('${_distanceKm.toStringAsFixed(1)} km',
                            style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w900,
                                color: WassalnyTheme.primary)),
                      ],
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        const Text('Price',
                            style: TextStyle(
                                fontSize: 12,
                                color: WassalnyTheme.textSecondary,
                                fontWeight: FontWeight.w600)),
                        const SizedBox(height: 4),
                        Text('${_estimatedPrice.toStringAsFixed(0)} DA',
                            style: const TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.w900,
                                color: WassalnyTheme.primary)),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
            ],
            Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: const Color(0xFFF1F5F9),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Row(children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => _isShared = false),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        color: !_isShared
                            ? WassalnyTheme.surfaceLight
                            : Colors.transparent,
                        borderRadius: BorderRadius.circular(11),
                        boxShadow: !_isShared ? WassalnyTheme.cardShadow : null,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.person_rounded,
                              size: 16, color: WassalnyTheme.primary),
                          const SizedBox(width: 6),
                          const Text('Private',
                              style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w700,
                                  color: WassalnyTheme.primary)),
                        ],
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => _isShared = true),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        color: _isShared
                            ? WassalnyTheme.surfaceLight
                            : Colors.transparent,
                        borderRadius: BorderRadius.circular(11),
                        boxShadow: _isShared ? WassalnyTheme.cardShadow : null,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.people_alt_rounded,
                              size: 16,
                              color: _isShared
                                  ? WassalnyTheme.accent
                                  : WassalnyTheme.textSecondary),
                          const SizedBox(width: 6),
                          Text('Shared',
                              style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w700,
                                  color: _isShared
                                      ? WassalnyTheme.primary
                                      : WassalnyTheme.textSecondary)),
                        ],
                      ),
                    ),
                  ),
                ),
              ]),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              height: 54,
              child: ElevatedButton(
                onPressed: _confirmRide,
                style: ElevatedButton.styleFrom(
                  backgroundColor: _isShared
                      ? WassalnyTheme.accent
                      : WassalnyTheme.accentBlue,
                  foregroundColor:
                      _isShared ? WassalnyTheme.primary : Colors.white,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                ),
                child: Text(
                    _isShared ? 'Confirm Shared Ride' : 'Confirm Private Ride',
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w700)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
