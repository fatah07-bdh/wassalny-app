import 'package:flutter/material.dart';
import 'package:app_constantine/theme_wassalny.dart';
import 'package:app_constantine/screens/driver_scanner_screen.dart';

class DriverDocumentsScreen extends StatefulWidget {
  const DriverDocumentsScreen({super.key});

  @override
  State<DriverDocumentsScreen> createState() => _DriverDocumentsScreenState();
}

class _DriverDocumentsScreenState extends State<DriverDocumentsScreen> {
  final _plateCtrl = TextEditingController();
  final _taxiCtrl = TextEditingController();
  final _licenseCtrl = TextEditingController();
  DateTime? _startDate;
  DateTime? _endDate;

  Future<void> _pickDate(bool isStart) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: isStart ? DateTime.now() : (_startDate ?? DateTime.now()),
      firstDate: isStart ? DateTime(2000) : (_startDate ?? DateTime(2000)),
      lastDate: DateTime(2050),
      builder: (context, child) => Theme(
        data: Theme.of(context).copyWith(
          colorScheme: const ColorScheme.light(primary: WassalnyTheme.accent),
        ),
        child: child!,
      ),
    );
    if (picked != null) {
      setState(() => isStart ? _startDate = picked : _endDate = picked);
    }
  }

  String _formatDate(DateTime? d) =>
      d == null ? 'Select date' : '${d.day}/${d.month}/${d.year}';

  @override
  void dispose() {
    _plateCtrl.dispose();
    _taxiCtrl.dispose();
    _licenseCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WassalnyTheme.bgLight,
      appBar: WassalnyTheme.buildAppBar('Vehicle & License Info'),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _SectionLabel('Vehicle Information'),
            const SizedBox(height: 14),
            TextField(
              style: TextStyle(color: Colors.black, fontSize: 14),
              controller: _plateCtrl,
              decoration: WassalnyTheme.textFieldDecoration(
                  'License plate number',
                  icon: Icons.credit_card_outlined),
            ),
            const SizedBox(height: 12),
            TextField(
              style: TextStyle(color: Colors.black, fontSize: 14),
              controller: _taxiCtrl,
              decoration: WassalnyTheme.textFieldDecoration('Taxi number',
                  icon: Icons.local_taxi_outlined),
            ),
            const SizedBox(height: 28),
            _SectionLabel('License Information'),
            const SizedBox(height: 14),
            TextField(
              style: TextStyle(color: Colors.black, fontSize: 14),
              controller: _licenseCtrl,
              decoration: WassalnyTheme.textFieldDecoration('License number',
                  icon: Icons.badge_outlined),
            ),
            const SizedBox(height: 16),
            Row(children: [
              Expanded(
                child: _DatePickerCard(
                  label: 'Valid From',
                  value: _formatDate(_startDate),
                  icon: Icons.calendar_today_outlined,
                  onTap: () => _pickDate(true),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _DatePickerCard(
                  label: 'Valid Until',
                  value: _formatDate(_endDate),
                  icon: Icons.event_outlined,
                  onTap: () => _pickDate(false),
                ),
              ),
            ]),
            const SizedBox(height: 36),
            SizedBox(
              width: double.infinity,
              height: 54,
              child: ElevatedButton(
                onPressed: () {
                  if (_plateCtrl.text.isEmpty ||
                      _taxiCtrl.text.isEmpty ||
                      _licenseCtrl.text.isEmpty ||
                      _startDate == null ||
                      _endDate == null) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                          content: Text(
                              'Please fill in all fields and select dates')),
                    );
                    return;
                  }
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const DriverScannerScreen()),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: WassalnyTheme.accent,
                  foregroundColor: WassalnyTheme.primary,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                ),
                child: const Text('Continue',
                    style:
                        TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              ),
            ),
            const SizedBox(height: 12),
            Center(
              child: TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Go Back',
                    style: TextStyle(
                        color: WassalnyTheme.textSecondary,
                        fontWeight: FontWeight.w600)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DatePickerCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final VoidCallback onTap;

  const _DatePickerCard(
      {required this.label,
      required this.value,
      required this.icon,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: const Color(0xFFF1F5F9),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label,
                style: const TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: WassalnyTheme.textSecondary)),
            const SizedBox(height: 6),
            Row(children: [
              Icon(icon, size: 14, color: WassalnyTheme.accent),
              const SizedBox(width: 6),
              Flexible(
                child: Text(value,
                    style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: WassalnyTheme.primary)),
              ),
            ]),
          ],
        ),
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String text;
  const _SectionLabel(this.text);

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Container(
          width: 3,
          height: 16,
          decoration: BoxDecoration(
              color: WassalnyTheme.accent,
              borderRadius: BorderRadius.circular(2))),
      const SizedBox(width: 8),
      Text(text,
          style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w800,
              color: WassalnyTheme.primary)),
    ]);
  }
}
