import 'package:flutter/material.dart';
import 'package:app_constantine/theme_wassalny.dart';

class DriverEarningsScreen extends StatelessWidget {
  const DriverEarningsScreen({super.key});

  static const _earnings = [
    {'date': 'Jan 15, 2024', 'amount': 1500, 'rides': 12},
    {'date': 'Jan 14, 2024', 'amount': 1800, 'rides': 15},
    {'date': 'Jan 13, 2024', 'amount': 1200, 'rides': 10},
    {'date': 'Jan 12, 2024', 'amount': 2000, 'rides': 16},
    {'date': 'Jan 11, 2024', 'amount': 1600, 'rides': 13},
  ];

  @override
  Widget build(BuildContext context) {
    final totalRides = _earnings.fold(0, (s, e) => s + (e['rides'] as int));
    final totalAmount = _earnings.fold(0, (s, e) => s + (e['amount'] as int));

    return Scaffold(
      backgroundColor: WassalnyTheme.bgLight,
      appBar: WassalnyTheme.buildAppBar('Earnings'),
      body: Column(
        children: [
          Container(
            margin: const EdgeInsets.fromLTRB(20, 16, 20, 0),
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [WassalnyTheme.primary, Color(0xFF1A3A6B)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(22),
            ),
            child: Column(
              children: [
                const Text('This Week',
                    style: TextStyle(
                        color: Colors.white60,
                        fontSize: 13,
                        fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                Text('$totalAmount DA',
                    style: const TextStyle(
                        color: WassalnyTheme.accent,
                        fontSize: 36,
                        fontWeight: FontWeight.w900,
                        letterSpacing: -1)),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _SummaryStat(
                        label: 'Rides',
                        value: '$totalRides',
                        icon: Icons.route_outlined),
                    const SizedBox(width: 32),
                    _SummaryStat(
                        label: 'Avg / day',
                        value: '${(totalAmount / _earnings.length).round()} DA',
                        icon: Icons.trending_up_rounded),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(children: [
              const Text('Daily Breakdown',
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                      color: WassalnyTheme.primary)),
            ]),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              itemCount: _earnings.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (_, i) {
                final e = _earnings[i];
                return Container(
                  padding: const EdgeInsets.all(16),
                  decoration: WassalnyTheme.cardDecoration,
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: WassalnyTheme.accent.withOpacity(0.10),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Icon(Icons.calendar_today_outlined,
                            color: WassalnyTheme.accent, size: 18),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(e['date'] as String,
                                style: WassalnyTheme.cardTitle),
                            const SizedBox(height: 2),
                            Text('${e['rides']} rides',
                                style: WassalnyTheme.cardSubtitle),
                          ],
                        ),
                      ),
                      Text('${e['amount']} DA',
                          style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w800,
                              color: WassalnyTheme.success)),
                    ],
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}

class _SummaryStat extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  const _SummaryStat(
      {required this.label, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Icon(icon, color: Colors.white54, size: 16),
      const SizedBox(height: 4),
      Text(value,
          style: const TextStyle(
              color: Colors.white, fontSize: 15, fontWeight: FontWeight.w800)),
      Text(label, style: const TextStyle(color: Colors.white54, fontSize: 11)),
    ]);
  }
}
