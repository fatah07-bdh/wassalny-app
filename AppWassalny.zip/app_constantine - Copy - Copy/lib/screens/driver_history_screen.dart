import 'package:flutter/material.dart';
import 'package:app_constantine/theme_wassalny.dart';

class DriverHistoryScreen extends StatelessWidget {
  const DriverHistoryScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WassalnyTheme.backgroundLight,
      appBar: WassalnyTheme.buildAppBar('Historique des courses'),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: const [
            HistoryItem(
              date: '2025-04-23 14:25',
              client: 'Ali',
              departure: 'Place de la gare',
              destination: 'Université de Constantine',
              price: '400 DA',
              status: 'Complète',
            ),
            HistoryItem(
              date: '2025-04-23 16:40',
              client: 'Ahmed',
              departure: 'Centre ville',
              destination: 'Aéroport',
              price: '600 DA',
              status: 'Complète',
            ),
          ],
        ),
      ),
    );
  }
}

class HistoryItem extends StatelessWidget {
  final String date;
  final String client;
  final String departure;
  final String destination;
  final String price;
  final String status;

  const HistoryItem({
    Key? key,
    required this.date,
    required this.client,
    required this.departure,
    required this.destination,
    required this.price,
    required this.status,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      margin: const EdgeInsets.only(bottom: 12),
      decoration: WassalnyTheme.cardDecoration,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.calendar_today,
                  color: WassalnyTheme.blueAccent, size: 20),
              const SizedBox(width: 8),
              Text(date, style: WassalnyTheme.cardSubtitle),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Icon(Icons.person, color: WassalnyTheme.blueAccent, size: 20),
              const SizedBox(width: 8),
              Text(client, style: WassalnyTheme.cardTitle),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Icon(Icons.location_on, color: Colors.red, size: 20),
              const SizedBox(width: 8),
              Text(departure, style: WassalnyTheme.cardTitle),
            ],
          ),
          Row(
            children: [
              Icon(Icons.location_on,
                  color: WassalnyTheme.blueAccent, size: 20),
              const SizedBox(width: 8),
              Text(destination, style: WassalnyTheme.cardTitle),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Icon(Icons.attach_money, color: Colors.green, size: 20),
              const SizedBox(width: 8),
              Text(price, style: WassalnyTheme.cardTitle),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Icon(Icons.check_circle, color: Colors.green, size: 20),
              const SizedBox(width: 8),
              Text(status, style: WassalnyTheme.cardTitle),
            ],
          ),
        ],
      ),
    );
  }
}
