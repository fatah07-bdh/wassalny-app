import 'package:flutter/material.dart';
import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:app_constantine/theme_wassalny.dart';
import 'package:app_constantine/screens/driver_login_screen.dart';
import 'package:app_constantine/screens/home_screen.dart';
import 'package:app_constantine/screens/driver_profile_screen.dart';
import 'package:app_constantine/screens/driver_history_screen.dart';
import 'package:app_constantine/screens/driver_earnings_screen.dart';
import 'package:app_constantine/screens/driver_documents_screen.dart';
import 'package:app_constantine/screens/driver_scanner_screen.dart';
import 'package:app_constantine/screens/cooperative_ride_driver_screen.dart';
import 'package:app_constantine/screens/normal_ride_driver_screen.dart';
import 'package:app_constantine/cooperative_passenger.dart';

class DriverHomeScreen extends StatefulWidget {
  const DriverHomeScreen({super.key});

  @override
  State<DriverHomeScreen> createState() => _DriverHomeScreenState();
}

class _DriverHomeScreenState extends State<DriverHomeScreen> {
  GoogleMapController? _mapController;
  LatLng? _currentPosition;
  Position? _currentLocation;
  Set<Marker> _markers = {};
  StreamSubscription<Position>? _positionStream;
  bool _isOnline = false;

  Future<void> _getCurrentLocation() async {
    try {
      LocationPermission permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) return;
      Position position = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high);
      setState(() {
        _currentLocation = position;
        _currentPosition = LatLng(position.latitude, position.longitude);
        _markers.add(Marker(
          markerId: const MarkerId('driver'),
          position: _currentPosition!,
          icon:
              BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueAzure),
        ));
      });
      _mapController?.animateCamera(CameraUpdate.newCameraPosition(
          CameraPosition(target: _currentPosition!, zoom: 14)));
    } catch (_) {}
  }

  void _startLocationTracking() {
    _positionStream = Geolocator.getPositionStream(
      locationSettings: AndroidSettings(
          accuracy: LocationAccuracy.high, forceLocationManager: true),
    ).listen((Position? p) {
      if (p != null) {
        setState(() {
          _currentLocation = p;
          _currentPosition = LatLng(p.latitude, p.longitude);
          _markers = {
            Marker(
              markerId: const MarkerId('driver'),
              position: _currentPosition!,
              icon: BitmapDescriptor.defaultMarkerWithHue(
                  BitmapDescriptor.hueAzure),
            )
          };
        });
      }
    });
  }

  Future<void> _logout() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Sign Out',
            style: TextStyle(
                fontWeight: FontWeight.w800, color: WassalnyTheme.primary)),
        content: const Text('Are you sure you want to sign out?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
                backgroundColor: WassalnyTheme.danger,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10))),
            child: const Text('Sign Out'),
          ),
        ],
      ),
    );
    if (confirm != true) return;
    await FirebaseAuth.instance.signOut();
    if (!mounted) return;

    Navigator.of(context, rootNavigator: true).pushAndRemoveUntil(
      MaterialPageRoute(
        builder: (_) => const HomeScreen(),
      ),
      (r) => false,
    );
  }

  @override
  void initState() {
    super.initState();
    _getCurrentLocation();
    _startLocationTracking();
  }

  @override
  void dispose() {
    _positionStream?.cancel();
    _mapController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WassalnyTheme.bgLight,
      appBar: AppBar(
        backgroundColor: WassalnyTheme.bgLight,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        leading: Builder(
          builder: (ctx) => IconButton(
            icon: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: WassalnyTheme.surfaceLight,
                borderRadius: BorderRadius.circular(10),
                boxShadow: WassalnyTheme.cardShadow,
              ),
              child: const Icon(Icons.menu_rounded,
                  color: WassalnyTheme.primary, size: 20),
            ),
            onPressed: () => Scaffold.of(ctx).openDrawer(),
          ),
        ),
        title: const Text('Driver',
            style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w800,
                color: WassalnyTheme.primary)),
        centerTitle: true,
        actions: [
          GestureDetector(
            onTap: () => setState(() => _isOnline = !_isOnline),
            child: Container(
              margin: const EdgeInsets.only(right: 16),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: _isOnline
                    ? WassalnyTheme.success.withOpacity(0.12)
                    : Colors.grey.withOpacity(0.12),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(children: [
                Container(
                  width: 7,
                  height: 7,
                  decoration: BoxDecoration(
                    color: _isOnline ? WassalnyTheme.success : Colors.grey,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 5),
                Text(_isOnline ? 'Online' : 'Offline',
                    style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color:
                            _isOnline ? WassalnyTheme.success : Colors.grey)),
              ]),
            ),
          ),
        ],
      ),
      drawer: _buildDrawer(context),
      body: Column(
        children: [
          SizedBox(
            height: 240,
            width: double.infinity,
            child: _currentPosition == null
                ? const Center(
                    child:
                        CircularProgressIndicator(color: WassalnyTheme.accent))
                : GoogleMap(
                    initialCameraPosition:
                        CameraPosition(target: _currentPosition!, zoom: 14),
                    onMapCreated: (c) => _mapController = c,
                    myLocationEnabled: true,
                    myLocationButtonEnabled: false,
                    zoomControlsEnabled: false,
                    markers: _markers,
                  ),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Row(children: [
                    Expanded(
                      child: _StatCard(
                        icon: Icons.star_rounded,
                        iconColor: WassalnyTheme.accent,
                        value: '5.0',
                        label: 'Rating',
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _StatCard(
                        icon: Icons.payments_outlined,
                        iconColor: WassalnyTheme.success,
                        value: '15,000',
                        label: 'DA / month',
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _StatCard(
                        icon: Icons.route_outlined,
                        iconColor: WassalnyTheme.accentBlue,
                        value: '48',
                        label: 'Rides',
                      ),
                    ),
                  ]),
                  const SizedBox(height: 24),
                  _ActionButton(
                    label: 'Normal Ride',
                    subtitle: 'Accept regular ride requests',
                    icon: Icons.hail_rounded,
                    color: WassalnyTheme.accentBlue,
                    textColor: Colors.white,
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const NormalRideDriverScreen(),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  _ActionButton(
                    label: 'Shared Ride',
                    subtitle: 'Accept cooperative carpool trips',
                    icon: Icons.people_alt_rounded,
                    color: WassalnyTheme.success,
                    textColor: Colors.white,
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => CooperativeRideDriverScreen(
                          passengers: [
                            CooperativePassenger(
                              name: 'Passenger 1',
                              phone: '+213 7XX XXX 001',
                              pickupLocation: const LatLng(36.7330, 3.0910),
                              destinationLocation: const LatLng(36.285, 3.0910),
                              requestedTime: DateTime.now(),
                              maxDeviation: 1.0,
                              womenOnly: false,
                            ),
                            CooperativePassenger(
                              name: 'Passenger 2',
                              phone: '+213 7XX XXX 002',
                              pickupLocation: const LatLng(36.7340, 3.0920),
                              destinationLocation: const LatLng(36.285, 3.0910),
                              requestedTime: DateTime.now(),
                              maxDeviation: 1.0,
                              womenOnly: false,
                            ),
                          ],
                          clientPickupLocation: const LatLng(36.7320, 3.0900),
                          clientDestinationLocation:
                              const LatLng(36.7520, 3.1100),
                          totalPrice: 1500,
                          pricePerPassenger: 500,
                          pickupAddress: 'Pickup Location',
                          destinationAddress: 'Destination',
                          optimizedRoute: null,
                          totalDistanceKm: null,
                          totalTimeMinutes: null,
                          extraWaitSeconds: null,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  _ActionButton(
                    label: 'Ride History',
                    subtitle: 'View your completed trips',
                    icon: Icons.history_rounded,
                    color: WassalnyTheme.accent,
                    textColor: WassalnyTheme.primary,
                    onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => const DriverHistoryScreen())),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawer(BuildContext context) {
    return Drawer(
      backgroundColor: WassalnyTheme.surfaceLight,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.horizontal(right: Radius.circular(24))),
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(24, 56, 24, 28),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  WassalnyTheme.accent,
                  WassalnyTheme.accent.withOpacity(0.75)
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius:
                  const BorderRadius.vertical(bottom: Radius.circular(24)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 64,
                  height: 64,
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.local_taxi_rounded,
                      size: 32, color: WassalnyTheme.accent),
                ),
                const SizedBox(height: 12),
                const Text('Driver',
                    style: TextStyle(
                        color: WassalnyTheme.primary,
                        fontSize: 18,
                        fontWeight: FontWeight.w800)),
                const SizedBox(height: 2),
                Text('driver@wassalny.dz',
                    style: TextStyle(
                        color: WassalnyTheme.primary.withOpacity(0.65),
                        fontSize: 13)),
              ],
            ),
          ),
          const SizedBox(height: 8),
          _DrawerItem(
              icon: Icons.person_outline,
              label: 'My Profile',
              onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) => const DriverProfileScreen()))),
          _DrawerItem(
              icon: Icons.history_rounded,
              label: 'Ride History',
              onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) => const DriverHistoryScreen()))),
          _DrawerItem(
              icon: Icons.payments_outlined,
              label: 'Earnings',
              onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) => const DriverEarningsScreen()))),
          const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16), child: Divider()),
          _DrawerItem(
              icon: Icons.folder_outlined,
              label: 'My Documents',
              onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) => const DriverDocumentsScreen()))),
          _DrawerItem(
              icon: Icons.qr_code_scanner,
              label: 'Scanner',
              onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) => const DriverScannerScreen()))),
          _DrawerItem(
              icon: Icons.logout_rounded,
              label: 'Sign Out',
              color: WassalnyTheme.danger,
              onTap: _logout),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String value;
  final String label;

  const _StatCard(
      {required this.icon,
      required this.iconColor,
      required this.value,
      required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 10),
      decoration: WassalnyTheme.cardDecoration,
      child: Column(
        children: [
          Icon(icon, color: iconColor, size: 22),
          const SizedBox(height: 6),
          Text(value,
              style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w900,
                  color: WassalnyTheme.primary)),
          const SizedBox(height: 2),
          Text(label,
              style: WassalnyTheme.cardSubtitle, textAlign: TextAlign.center),
        ],
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  final String label;
  final String subtitle;
  final IconData icon;
  final Color color;
  final Color textColor;
  final VoidCallback onTap;

  const _ActionButton(
      {required this.label,
      required this.subtitle,
      required this.icon,
      required this.color,
      required this.textColor,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
                color: color.withOpacity(0.25),
                blurRadius: 16,
                offset: const Offset(0, 6)),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.20),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: textColor, size: 22),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label,
                      style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w800,
                          color: textColor)),
                  const SizedBox(height: 2),
                  Text(subtitle,
                      style: TextStyle(
                          fontSize: 12, color: textColor.withOpacity(0.75))),
                ],
              ),
            ),
            Icon(Icons.chevron_right_rounded,
                color: textColor.withOpacity(0.6)),
          ],
        ),
      ),
    );
  }
}

class _DrawerItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final Color? color;

  const _DrawerItem(
      {required this.icon,
      required this.label,
      required this.onTap,
      this.color});

  @override
  Widget build(BuildContext context) {
    final c = color ?? WassalnyTheme.primary;
    return ListTile(
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: c.withOpacity(0.08),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, color: c, size: 18),
      ),
      title: Text(label,
          style:
              TextStyle(color: c, fontWeight: FontWeight.w600, fontSize: 15)),
      trailing: Icon(Icons.chevron_right_rounded,
          color: c.withOpacity(0.4), size: 18),
      onTap: onTap,
    );
  }
}
