import 'package:flutter/material.dart';
import 'package:app_constantine/theme_wassalny.dart';
import 'package:app_constantine/screens/driver_register_screen.dart';

class DriverProfileScreen extends StatelessWidget {
  const DriverProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WassalnyTheme.bgLight,
      appBar: WassalnyTheme.buildAppBar('My Profile'),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
        child: Column(
          children: [
            Center(
              child: Stack(
                children: [
                  Container(
                    width: 96,
                    height: 96,
                    decoration: BoxDecoration(
                      color: WassalnyTheme.accent.withOpacity(0.12),
                      shape: BoxShape.circle,
                      border: Border.all(
                          color: WassalnyTheme.accent.withOpacity(0.3),
                          width: 2),
                    ),
                    child: const Icon(Icons.local_taxi_rounded,
                        size: 46, color: WassalnyTheme.accent),
                  ),
                  Positioned(
                    right: 0,
                    bottom: 0,
                    child: Container(
                      width: 28,
                      height: 28,
                      decoration: const BoxDecoration(
                          color: WassalnyTheme.accent, shape: BoxShape.circle),
                      child: const Icon(Icons.edit,
                          color: WassalnyTheme.primary, size: 14),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            const Text('Driver Name',
                style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: WassalnyTheme.primary)),
            const SizedBox(height: 2),
            Text('Driver account', style: WassalnyTheme.cardSubtitle),
            const SizedBox(height: 28),
            Container(
              padding: const EdgeInsets.all(8),
              decoration: WassalnyTheme.cardDecoration,
              child: Column(
                children: [
                  _InfoTile(Icons.person_outline, 'Full Name', 'Driver Name'),
                  const Divider(height: 1, indent: 16, endIndent: 16),
                  _InfoTile(Icons.phone_outlined, 'Phone', '+213 XXX XXX XXX'),
                  const Divider(height: 1, indent: 16, endIndent: 16),
                  _InfoTile(Icons.email_outlined, 'Email', 'driver@email.com'),
                  const Divider(height: 1, indent: 16, endIndent: 16),
                  _InfoTile(
                      Icons.credit_card_outlined, 'Taxi Plate', '58-123-T'),
                  const Divider(height: 1, indent: 16, endIndent: 16),
                  _InfoTile(Icons.numbers, 'Taxi Number', 'TAXI-12345'),
                  const Divider(height: 1, indent: 16, endIndent: 16),
                  _InfoTile(Icons.wc_outlined, 'Gender', 'Male'),
                ],
              ),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              height: 54,
              child: ElevatedButton.icon(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) => const DriverRegisterScreen()),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: WassalnyTheme.accent,
                  foregroundColor: WassalnyTheme.primary,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                ),
                icon: const Icon(Icons.edit_outlined, size: 18),
                label: const Text('Edit Profile',
                    style:
                        TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _InfoTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _InfoTile(this.icon, this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: WassalnyTheme.accent.withOpacity(0.08),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, color: WassalnyTheme.accent, size: 18),
      ),
      title: Text(label,
          style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: WassalnyTheme.textSecondary,
              letterSpacing: 0.3)),
      subtitle: Text(value,
          style: const TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w600,
              color: WassalnyTheme.primary)),
    );
  }
}
