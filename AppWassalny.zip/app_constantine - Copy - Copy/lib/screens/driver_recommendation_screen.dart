import 'package:flutter/material.dart';
import 'package:app_constantine/theme_wassalny.dart';

class DriverRecommendationScreen extends StatelessWidget {
  const DriverRecommendationScreen({super.key});

  static const _drivers = [
    {'name': 'Ali', 'plate': '58-123-T', 'rating': '5.0', 'rides': '150'},
    {'name': 'Ahmed', 'plate': '58-456-T', 'rating': '4.9', 'rides': '120'},
    {'name': 'Karim', 'plate': '58-789-T', 'rating': '4.8', 'rides': '100'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WassalnyTheme.bgLight,
      appBar: WassalnyTheme.buildAppBar('Top Drivers'),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 4),
            child: Row(children: [
              const Icon(Icons.verified,
                  color: WassalnyTheme.success, size: 16),
              const SizedBox(width: 6),
              Text('Highest rated drivers near you',
                  style: WassalnyTheme.bodyText),
            ]),
          ),
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.all(20),
              itemCount: _drivers.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (_, i) {
                final d = _drivers[i];
                return Container(
                  padding: const EdgeInsets.all(16),
                  decoration: WassalnyTheme.cardDecoration,
                  child: Row(
                    children: [
                      Container(
                        width: 52,
                        height: 52,
                        decoration: BoxDecoration(
                          color: WassalnyTheme.accent.withOpacity(0.10),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.person_rounded,
                            color: WassalnyTheme.accent, size: 26),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(d['name']!, style: WassalnyTheme.cardTitle),
                            const SizedBox(height: 3),
                            Text(d['plate']!,
                                style: WassalnyTheme.cardSubtitle),
                          ],
                        ),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Row(children: [
                            const Icon(Icons.star_rounded,
                                color: WassalnyTheme.accent, size: 14),
                            const SizedBox(width: 3),
                            Text(d['rating']!,
                                style: const TextStyle(
                                    fontWeight: FontWeight.w800,
                                    fontSize: 14,
                                    color: WassalnyTheme.primary)),
                          ]),
                          const SizedBox(height: 4),
                          Text('${d['rides']} rides',
                              style: WassalnyTheme.cardSubtitle),
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
