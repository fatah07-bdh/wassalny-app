import 'package:flutter/material.dart';
import 'package:app_constantine/theme_wassalny.dart';
import 'package:app_constantine/screens/driver_home_screen.dart';

class DriverRegisterScreen extends StatefulWidget {
  const DriverRegisterScreen({super.key});

  @override
  State<DriverRegisterScreen> createState() => _DriverRegisterScreenState();
}

class _DriverRegisterScreenState extends State<DriverRegisterScreen> {
  final _nameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _plateCtrl = TextEditingController();
  final _taxiCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  String _gender = 'Male';
  bool _obscure = true;
  bool _loading = false;

  @override
  void dispose() {
    for (final c in [
      _nameCtrl,
      _phoneCtrl,
      _plateCtrl,
      _taxiCtrl,
      _emailCtrl,
      _passCtrl
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _register() async {
    if ([_nameCtrl, _phoneCtrl, _plateCtrl, _taxiCtrl, _emailCtrl, _passCtrl]
        .any((c) => c.text.trim().isEmpty)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill in all fields')),
      );
      return;
    }
    setState(() => _loading = true);
    await Future.delayed(const Duration(milliseconds: 700));
    if (!mounted) return;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const DriverHomeScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WassalnyTheme.bgLight,
      appBar: WassalnyTheme.buildAppBar('Driver Register'),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Driver Registration',
                style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w900,
                    color: WassalnyTheme.primary)),
            const SizedBox(height: 6),
            Text('Create your driver account to start earning.',
                style: WassalnyTheme.bodyText),
            const SizedBox(height: 28),
            TextField(
                style: TextStyle(color: Colors.black, fontSize: 14),
                controller: _nameCtrl,
                decoration: WassalnyTheme.textFieldDecoration('Full name',
                    icon: Icons.person_outline)),
            const SizedBox(height: 12),
            TextField(
                style: TextStyle(color: Colors.black, fontSize: 14),
                controller: _phoneCtrl,
                keyboardType: TextInputType.phone,
                decoration: WassalnyTheme.textFieldDecoration('Phone number',
                    icon: Icons.phone_outlined)),
            const SizedBox(height: 12),
            TextField(
                style: TextStyle(color: Colors.black, fontSize: 14),
                controller: _plateCtrl,
                decoration: WassalnyTheme.textFieldDecoration(
                    'Taxi plate (e.g. 58-123-T)',
                    icon: Icons.credit_card_outlined)),
            const SizedBox(height: 12),
            TextField(
                style: TextStyle(color: Colors.black, fontSize: 14),
                controller: _taxiCtrl,
                decoration: WassalnyTheme.textFieldDecoration(
                    'Taxi number (e.g. TAXI-12345)',
                    icon: Icons.numbers)),
            const SizedBox(height: 12),
            TextField(
                style: TextStyle(color: Colors.black, fontSize: 14),
                controller: _emailCtrl,
                keyboardType: TextInputType.emailAddress,
                decoration: WassalnyTheme.textFieldDecoration('Email address',
                    icon: Icons.email_outlined)),
            const SizedBox(height: 12),
            TextField(
              style: TextStyle(color: Colors.black, fontSize: 14),
              controller: _passCtrl,
              obscureText: _obscure,
              decoration: WassalnyTheme.textFieldDecoration('Password',
                      icon: Icons.lock_outline)
                  .copyWith(
                suffixIcon: IconButton(
                  icon: Icon(
                      _obscure
                          ? Icons.visibility_outlined
                          : Icons.visibility_off_outlined,
                      color: WassalnyTheme.textSecondary,
                      size: 20),
                  onPressed: () => setState(() => _obscure = !_obscure),
                ),
              ),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: _gender,
              decoration: WassalnyTheme.textFieldDecoration('Gender',
                  icon: Icons.wc_outlined),
              items: const [
                DropdownMenuItem(value: 'Male', child: Text('Male')),
                DropdownMenuItem(value: 'Female', child: Text('Female')),
              ],
              onChanged: (v) => setState(() => _gender = v ?? 'Male'),
            ),
            const SizedBox(height: 32),
            SizedBox(
              width: double.infinity,
              height: 54,
              child: ElevatedButton(
                onPressed: _loading ? null : _register,
                style: ElevatedButton.styleFrom(
                  backgroundColor: WassalnyTheme.accent,
                  foregroundColor: WassalnyTheme.primary,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                ),
                child: _loading
                    ? const SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(
                            color: WassalnyTheme.primary, strokeWidth: 2.5))
                    : const Text('Register',
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w700)),
              ),
            ),
            const SizedBox(height: 12),
            Center(
              child: TextButton(
                onPressed: () => Navigator.pushNamed(context, '/driver_login'),
                child: const Text('Already have an account? Sign In',
                    style: TextStyle(
                        color: WassalnyTheme.accent,
                        fontWeight: FontWeight.w600)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
