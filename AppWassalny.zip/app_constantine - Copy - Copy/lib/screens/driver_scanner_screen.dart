import 'package:flutter/material.dart';
import 'package:app_constantine/theme_wassalny.dart';

class DriverScannerScreen extends StatefulWidget {
  const DriverScannerScreen({super.key});

  @override
  State<DriverScannerScreen> createState() => _DriverScannerScreenState();
}

class _DriverScannerScreenState extends State<DriverScannerScreen> {
  final _documents = [
    {
      'label': 'Vehicle Registration Card',
      'icon': Icons.article_outlined,
      'scanned': false
    },
    {
      'label': 'Insurance Certificate',
      'icon': Icons.shield_outlined,
      'scanned': false
    },
    {
      'label': 'Operating Permit',
      'icon': Icons.approval_outlined,
      'scanned': false
    },
    {'label': 'Driver License', 'icon': Icons.badge_outlined, 'scanned': false},
  ];

  void _scanDocument(int index) {
    setState(() => _documents[index]['scanned'] = true);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${_documents[index]['label']} scanned successfully'),
        backgroundColor: WassalnyTheme.success,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  int get _scannedCount => _documents.where((d) => d['scanned'] == true).length;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WassalnyTheme.bgLight,
      appBar: WassalnyTheme.buildAppBar('Document Scanner'),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: WassalnyTheme.cardDecoration,
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Scan Progress',
                          style: TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 14,
                              color: WassalnyTheme.primary)),
                      Text('$_scannedCount / ${_documents.length}',
                          style: const TextStyle(
                              fontWeight: FontWeight.w800,
                              fontSize: 14,
                              color: WassalnyTheme.accent)),
                    ],
                  ),
                  const SizedBox(height: 10),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: LinearProgressIndicator(
                      value: _scannedCount / _documents.length,
                      minHeight: 8,
                      backgroundColor: const Color(0xFFE2E8F0),
                      valueColor:
                          const AlwaysStoppedAnimation(WassalnyTheme.accent),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    _scannedCount == _documents.length
                        ? 'All documents scanned!'
                        : 'Scan each document using your camera',
                    style: WassalnyTheme.cardSubtitle,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: ListView.separated(
                itemCount: _documents.length,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (_, i) {
                  final doc = _documents[i];
                  final scanned = doc['scanned'] as bool;
                  return Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: scanned
                          ? WassalnyTheme.success.withOpacity(0.06)
                          : WassalnyTheme.surfaceLight,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: scanned
                            ? WassalnyTheme.success.withOpacity(0.3)
                            : Colors.transparent,
                      ),
                      boxShadow: WassalnyTheme.cardShadow,
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: scanned
                                ? WassalnyTheme.success.withOpacity(0.12)
                                : const Color(0xFFF1F5F9),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(
                            doc['icon'] as IconData,
                            color: scanned
                                ? WassalnyTheme.success
                                : WassalnyTheme.textSecondary,
                            size: 22,
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Text(doc['label'] as String,
                              style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 14,
                                  color: scanned
                                      ? WassalnyTheme.success
                                      : WassalnyTheme.primary)),
                        ),
                        scanned
                            ? const Icon(Icons.check_circle_rounded,
                                color: WassalnyTheme.success, size: 22)
                            : GestureDetector(
                                onTap: () => _scanDocument(i),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 14, vertical: 8),
                                  decoration: BoxDecoration(
                                    color: WassalnyTheme.accent,
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: const Row(children: [
                                    Icon(Icons.camera_alt_outlined,
                                        color: WassalnyTheme.primary, size: 14),
                                    SizedBox(width: 4),
                                    Text('Scan',
                                        style: TextStyle(
                                            color: WassalnyTheme.primary,
                                            fontWeight: FontWeight.w700,
                                            fontSize: 12)),
                                  ]),
                                ),
                              ),
                      ],
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              height: 54,
              child: ElevatedButton(
                onPressed: _scannedCount == _documents.length
                    ? () => Navigator.pop(context)
                    : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: WassalnyTheme.accent,
                  foregroundColor: WassalnyTheme.primary,
                  disabledBackgroundColor: const Color(0xFFE2E8F0),
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                ),
                child: Text(
                  _scannedCount == _documents.length
                      ? 'Complete Registration'
                      : 'Scan all documents to continue',
                  style: const TextStyle(
                      fontSize: 15, fontWeight: FontWeight.w700),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
