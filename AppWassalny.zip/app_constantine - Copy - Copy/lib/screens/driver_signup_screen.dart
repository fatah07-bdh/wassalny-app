import 'package:flutter/material.dart';
import 'package:app_constantine/theme_wassalny.dart';
import 'package:app_constantine/screens/driver_profile_screen.dart';
import 'package:app_constantine/screens/driver_home_screen.dart';

class DriverSignupScreen extends StatefulWidget {
  const DriverSignupScreen({super.key});

  @override
  State<DriverSignupScreen> createState() => _DriverSignupScreenState();
}

class _DriverSignupScreenState extends State<DriverSignupScreen> {
  final _nameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  final _plateCtrl = TextEditingController();
  final _taxiCtrl = TextEditingController();
  String _gender = 'Male';
  bool _obscure = true;

  @override
  void dispose() {
    for (final c in [
      _nameCtrl,
      _phoneCtrl,
      _emailCtrl,
      _passCtrl,
      _plateCtrl,
      _taxiCtrl
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WassalnyTheme.bgLight,
      appBar: WassalnyTheme.buildAppBar('Driver Registration'),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Create Driver Account',
                style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w900,
                    color: WassalnyTheme.primary)),
            const SizedBox(height: 6),
            Text('Fill in your details to register as a driver.',
                style: WassalnyTheme.bodyText),
            const SizedBox(height: 28),
            _SectionLabel('Personal Information'),
            const SizedBox(height: 12),
            TextField(
                style: TextStyle(color: Colors.black, fontSize: 14),
                controller: _nameCtrl,
                decoration: WassalnyTheme.textFieldDecoration('Full name',
                    icon: Icons.person_outline)),
            const SizedBox(height: 12),
            TextField(
                style: TextStyle(color: Colors.black, fontSize: 14),
                controller: _phoneCtrl,
                keyboardType: TextInputType.phone,
                decoration: WassalnyTheme.textFieldDecoration('Phone number',
                    icon: Icons.phone_outlined)),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: _gender,
              decoration: WassalnyTheme.textFieldDecoration('Gender',
                  icon: Icons.wc_outlined),
              items: const [
                DropdownMenuItem(value: 'Male', child: Text('Male')),
                DropdownMenuItem(value: 'Female', child: Text('Female')),
              ],
              onChanged: (v) => setState(() => _gender = v ?? 'Male'),
            ),
            const SizedBox(height: 12),
            TextField(
                style: TextStyle(color: Colors.black, fontSize: 14),
                controller: _emailCtrl,
                keyboardType: TextInputType.emailAddress,
                decoration: WassalnyTheme.textFieldDecoration('Email address',
                    icon: Icons.email_outlined)),
            const SizedBox(height: 12),
            TextField(
              style: TextStyle(color: Colors.black, fontSize: 14),
              controller: _passCtrl,
              obscureText: _obscure,
              decoration: WassalnyTheme.textFieldDecoration('Password',
                      icon: Icons.lock_outline)
                  .copyWith(
                suffixIcon: IconButton(
                  icon: Icon(
                      _obscure
                          ? Icons.visibility_outlined
                          : Icons.visibility_off_outlined,
                      color: WassalnyTheme.textSecondary,
                      size: 20),
                  onPressed: () => setState(() => _obscure = !_obscure),
                ),
              ),
            ),
            const SizedBox(height: 24),
            _SectionLabel('Vehicle Information'),
            const SizedBox(height: 12),
            TextField(
                style: TextStyle(color: Colors.black, fontSize: 14),
                controller: _plateCtrl,
                decoration: WassalnyTheme.textFieldDecoration(
                    'License plate (e.g. 58-123-T)',
                    icon: Icons.credit_card_outlined)),
            const SizedBox(height: 12),
            TextField(
                style: TextStyle(color: Colors.black, fontSize: 14),
                controller: _taxiCtrl,
                decoration: WassalnyTheme.textFieldDecoration(
                    'Taxi number (e.g. TAXI-12345)',
                    icon: Icons.numbers)),
            const SizedBox(height: 32),
            SizedBox(
              width: double.infinity,
              height: 54,
              child: ElevatedButton(
                onPressed: () => Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const DriverProfileScreen())),
                style: ElevatedButton.styleFrom(
                  backgroundColor: WassalnyTheme.accent,
                  foregroundColor: WassalnyTheme.primary,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                ),
                child: const Text('Continue',
                    style:
                        TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              ),
            ),
            const SizedBox(height: 12),
            Center(
              child: TextButton(
                onPressed: () => Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const DriverHomeScreen())),
                child: const Text('Already have an account? Sign In',
                    style: TextStyle(
                        color: WassalnyTheme.accent,
                        fontWeight: FontWeight.w600)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String text;
  const _SectionLabel(this.text);

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Container(
          width: 3,
          height: 16,
          decoration: BoxDecoration(
              color: WassalnyTheme.accent,
              borderRadius: BorderRadius.circular(2))),
      const SizedBox(width: 8),
      Text(text,
          style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w800,
              color: WassalnyTheme.primary,
              letterSpacing: 0.2)),
    ]);
  }
}
