import 'package:flutter/material.dart';
import 'package:app_constantine/theme_wassalny.dart';
import 'package:app_constantine/screens/client_login_screen.dart';
import 'package:app_constantine/screens/driver_login_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WassalnyTheme.bgLight,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 16),
              Row(
                children: [
                  Container(
                    width: 120,
                    height: 120,
                    decoration: BoxDecoration(
                      color: WassalnyTheme.surfaceLight,
                      shape: BoxShape.rectangle,
                      border: Border.all(color: WassalnyTheme.accent, width: 2),
                      boxShadow: WassalnyTheme.cardShadow,
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Image.asset('assets/images/Wassalny.png',
                          fit: BoxFit.contain),
                    ),
                  ),
                  const SizedBox(width: 12),
                  const Text('Wassalny',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                        color: WassalnyTheme.primary,
                        letterSpacing: -0.5,
                      )),
                  const Spacer(),
                ],
              ),
              const Spacer(flex: 2),
              const Text('Choose your\nprofile',
                  style: TextStyle(
                    fontSize: 38,
                    fontWeight: FontWeight.w900,
                    color: WassalnyTheme.primary,
                    letterSpacing: -1,
                    height: 1.1,
                  )),
              const SizedBox(height: 12),
              const Text('Select how you want to use Wassalny today.',
                  style: WassalnyTheme.bodyText),
              const Spacer(flex: 1),
              _RoleCard(
                title: 'Passenger',
                subtitle: 'Book rides & share trips with others',
                icon: Icons.person_pin_circle_rounded,
                iconBg: WassalnyTheme.accentBlue.withOpacity(0.10),
                iconColor: WassalnyTheme.accentBlue,
                badge: 'CLIENT',
                badgeColor: WassalnyTheme.accentBlue,
                onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const ClientLoginScreen())),
              ),
              const SizedBox(height: 16),
              _RoleCard(
                title: 'Driver',
                subtitle: 'Manage rides & earn with Wassalny',
                icon: Icons.local_taxi_rounded,
                iconBg: WassalnyTheme.accent.withOpacity(0.12),
                iconColor: WassalnyTheme.accent,
                badge: 'DRIVER',
                badgeColor: WassalnyTheme.accent,
                onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const DriverLoginScreen())),
              ),
              const Spacer(flex: 2),
              Center(
                child: Text('Wassalny',
                    style: TextStyle(
                        fontSize: 13,
                        color: WassalnyTheme.textSecondary,
                        fontWeight: FontWeight.w500)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _RoleCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color iconBg;
  final Color iconColor;
  final String badge;
  final Color badgeColor;
  final VoidCallback onTap;

  const _RoleCard({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.iconBg,
    required this.iconColor,
    required this.badge,
    required this.badgeColor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: WassalnyTheme.surfaceLight,
            borderRadius: BorderRadius.circular(20),
            boxShadow: WassalnyTheme.cardShadow,
          ),
          child: Row(
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: iconBg,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Icon(icon, color: iconColor, size: 28),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(title,
                            style: const TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.w800,
                              color: WassalnyTheme.primary,
                            )),
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: badgeColor.withOpacity(0.12),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(badge,
                              style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.w800,
                                  color: badgeColor,
                                  letterSpacing: 0.5)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(subtitle, style: WassalnyTheme.cardSubtitle),
                  ],
                ),
              ),
              Icon(Icons.chevron_right_rounded,
                  color: WassalnyTheme.textSecondary),
            ],
          ),
        ),
      ),
    );
  }
}
