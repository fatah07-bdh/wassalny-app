import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:app_constantine/widgets/settings_buttons.dart';
import 'package:app_constantine/theme_wassalny.dart';
import 'driver_home_screen.dart';

class DriverLoginScreen extends StatefulWidget {
  const DriverLoginScreen({super.key});

  @override
  State<DriverLoginScreen> createState() => _DriverLoginScreenState();
}

class _DriverLoginScreenState extends State<DriverLoginScreen> {
  String _currentLanguage = 'en';
  bool _isDarkMode = false;
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  void _changeLanguage(String lang) {
    setState(() {
      _currentLanguage = lang;
    });
  }

  void _changeDarkMode(bool isDark) {
    setState(() {
      _isDarkMode = isDark;
    });
  }

  Future<void> _login() async {
    final email = _emailController.text.trim();
    final password = _passwordController.text.trim();

    if (email.isEmpty || password.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill all fields')),
      );
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => DriverHomeScreen()),
    );

    _emailController.clear();
    _passwordController.clear();
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _isDarkMode
          ? WassalnyTheme.backgroundDark
          : WassalnyTheme.backgroundLight,
      appBar: WassalnyTheme.buildAppBar('Driver Login'),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            SizedBox(height: 20),
            Icon(Icons.drive_eta, size: 80, color: WassalnyTheme.primaryYellow),
            SizedBox(height: 20),
            Text('Driver Login', style: WassalnyTheme.titleMedium),
            SizedBox(height: 30),
            TextField(
              style: TextStyle(color: Colors.black, fontSize: 14),
              controller: _emailController,
              decoration: WassalnyTheme.textFieldDecoration('Email'),
            ),
            SizedBox(height: 16),
            TextField(
              style: TextStyle(color: Colors.black, fontSize: 14),
              controller: _passwordController,
              decoration: WassalnyTheme.textFieldDecoration('Password'),
              obscureText: true,
            ),
            SizedBox(height: 30),
            SizedBox(
              width: double.infinity,
              height: 56,
              child: ElevatedButton.icon(
                onPressed: _login,
                style: WassalnyTheme.elevatedButtonStyle,
                icon: Icon(Icons.login, size: 24),
                label: Text('Sign In',
                    style:
                        TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ),
            ),
            SizedBox(height: 20),
            TextButton(
              onPressed: () {
                Navigator.pushNamed(context, '/driver_register');
              },
              child: Text('Do' 't have an account? Register'),
            ),
            SizedBox(height: 30),
            SettingsButtons(
              currentLanguage: _currentLanguage,
              isDarkMode: _isDarkMode,
              onLanguageChanged: _changeLanguage,
              onDarkModeChanged: _changeDarkMode,
            ),
          ],
        ),
      ),
    );
  }
}
