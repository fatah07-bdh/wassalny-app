import 'package:flutter/material.dart';
import 'package:app_constantine/theme_wassalny.dart';
import 'package:app_constantine/screens/ride_confirmation_screen.dart';

class NormalRideDriverScreen extends StatefulWidget {
  const NormalRideDriverScreen({super.key});

  @override
  State<NormalRideDriverScreen> createState() => _NormalRideDriverScreenState();
}

class _NormalRideDriverScreenState extends State<NormalRideDriverScreen> {
  final String clientName = 'Karim';
  final String clientPhone = '+213 7XX XXX XXX';
  final String pickupAddress = 'Train Station Square';
  final String destinationAddress = 'University of Constantine';
  final double distanceKm = 4.5;
  final double price = 675;
  final DateTime rideDate = DateTime(2025, 4, 23);
  final TimeOfDay rideTime = TimeOfDay(hour: 14, minute: 25);

  void _acceptRide() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => RideConfirmationScreen(
          clientName: clientName,
          clientPhone: clientPhone,
          driverName: 'Ali',
          driverPlate: '58-123-T',
          driverTaxiNumber: 'TAXI-12345',
          pickupAddress: pickupAddress,
          destinationAddress: destinationAddress,
          distanceKm: distanceKm,
          price: price,
          isShared: false,
          discountPercentage: 0,
          numberOfPassengers: 1,
          isDriver: true,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WassalnyTheme.bgLight,
      appBar: WassalnyTheme.buildAppBar('Normal Ride'),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: WassalnyTheme.accentBlue.withOpacity(0.10),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                    color: WassalnyTheme.accentBlue.withOpacity(0.3)),
              ),
              child: Row(
                children: [
                  Icon(Icons.hail_rounded,
                      color: WassalnyTheme.accentBlue, size: 24),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Normal Ride Request',
                            style: TextStyle(
                                fontWeight: FontWeight.w800,
                                fontSize: 15,
                                color: WassalnyTheme.primary)),
                        const SizedBox(height: 4),
                        Text('Regular ride - No sharing',
                            style: TextStyle(
                                fontSize: 12,
                                color: WassalnyTheme.textSecondary)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            const Text('Passenger',
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    color: WassalnyTheme.primary)),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: WassalnyTheme.cardDecoration,
              child: Column(
                children: [
                  Row(
                    children: [
                      Container(
                        width: 46,
                        height: 46,
                        decoration: BoxDecoration(
                          color: WassalnyTheme.accentBlue.withOpacity(0.12),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.person,
                            color: WassalnyTheme.accentBlue, size: 24),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(clientName,
                                style: const TextStyle(
                                    fontWeight: FontWeight.w700,
                                    fontSize: 16,
                                    color: WassalnyTheme.primary)),
                            const SizedBox(height: 4),
                            Row(
                              children: [
                                Icon(Icons.phone,
                                    size: 14,
                                    color: WassalnyTheme.textSecondary),
                                const SizedBox(width: 4),
                                Text(clientPhone,
                                    style: const TextStyle(
                                        fontSize: 13,
                                        color: WassalnyTheme.textSecondary)),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            const Text('Trip Details',
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    color: WassalnyTheme.primary)),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: WassalnyTheme.cardDecoration,
              child: Column(
                children: [
                  Row(
                    children: [
                      Container(
                        width: 32,
                        height: 32,
                        decoration: BoxDecoration(
                          color: WassalnyTheme.accentBlue.withOpacity(0.12),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.location_on,
                            color: WassalnyTheme.accentBlue, size: 18),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Pickup',
                                style: TextStyle(
                                    fontSize: 11,
                                    color: WassalnyTheme.textSecondary,
                                    fontWeight: FontWeight.w600)),
                            const SizedBox(height: 2),
                            Text(pickupAddress,
                                style: const TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600,
                                    color: WassalnyTheme.primary)),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Container(
                    width: 2,
                    height: 32,
                    color: WassalnyTheme.textSecondary.withOpacity(0.2),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Container(
                        width: 32,
                        height: 32,
                        decoration: BoxDecoration(
                          color: WassalnyTheme.danger.withOpacity(0.12),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.location_on,
                            color: WassalnyTheme.danger, size: 18),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Destination',
                                style: TextStyle(
                                    fontSize: 11,
                                    color: WassalnyTheme.textSecondary,
                                    fontWeight: FontWeight.w600)),
                            const SizedBox(height: 2),
                            Text(destinationAddress,
                                style: const TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600,
                                    color: WassalnyTheme.primary)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Row(children: [
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: WassalnyTheme.cardDecoration,
                  child: Column(
                    children: [
                      Icon(Icons.calendar_today,
                          color: WassalnyTheme.accent, size: 24),
                      const SizedBox(height: 8),
                      Text('${rideDate.day}/${rideDate.month}/${rideDate.year}',
                          style: WassalnyTheme.cardTitle),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: WassalnyTheme.cardDecoration,
                  child: Column(
                    children: [
                      Icon(Icons.access_time,
                          color: WassalnyTheme.accent, size: 24),
                      const SizedBox(height: 8),
                      Text(
                          '${rideTime.hour}:${rideTime.minute.toString().padLeft(2, '0')}',
                          style: WassalnyTheme.cardTitle),
                    ],
                  ),
                ),
              ),
            ]),
            const SizedBox(height: 20),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: WassalnyTheme.success.withOpacity(0.10),
                borderRadius: BorderRadius.circular(16),
                border:
                    Border.all(color: WassalnyTheme.success.withOpacity(0.3)),
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Distance',
                          style: TextStyle(
                              fontSize: 12,
                              color: WassalnyTheme.textSecondary,
                              fontWeight: FontWeight.w600)),
                      Text('${distanceKm.toStringAsFixed(1)} km',
                          style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w900,
                              color: WassalnyTheme.primary)),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Rate',
                          style: TextStyle(
                              fontSize: 12,
                              color: WassalnyTheme.textSecondary,
                              fontWeight: FontWeight.w600)),
                      const Text('150 DA / km',
                          style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w700,
                              color: WassalnyTheme.primary)),
                    ],
                  ),
                  const Divider(),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('TOTAL',
                          style: TextStyle(
                              fontSize: 14,
                              color: WassalnyTheme.primary,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 0.5)),
                      Text('${price.toStringAsFixed(0)} DA',
                          style: const TextStyle(
                              fontSize: 28,
                              fontWeight: FontWeight.w900,
                              color: WassalnyTheme.primary)),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              height: 54,
              child: ElevatedButton(
                onPressed: _acceptRide,
                style: ElevatedButton.styleFrom(
                  backgroundColor: WassalnyTheme.accentBlue,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                ),
                child: const Text('Accept Ride',
                    style:
                        TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
