import 'package:flutter/material.dart';
import 'package:app_constantine/theme_wassalny.dart';
import 'package:app_constantine/screens/client_home_screen.dart';
import 'package:app_constantine/screens/driver_home_screen.dart';

class RideConfirmationScreen extends StatelessWidget {
  final String clientName;
  final String clientPhone;
  final String driverName;
  final String driverPlate;
  final String driverTaxiNumber;
  final String pickupAddress;
  final String destinationAddress;
  final double distanceKm;
  final double price;
  final bool isShared;
  final double discountPercentage;
  final int numberOfPassengers;
  final bool isDriver;

  const RideConfirmationScreen({
    super.key,
    required this.clientName,
    required this.clientPhone,
    required this.driverName,
    required this.driverPlate,
    required this.driverTaxiNumber,
    required this.pickupAddress,
    required this.destinationAddress,
    required this.distanceKm,
    required this.price,
    required this.isShared,
    required this.discountPercentage,
    required this.numberOfPassengers,
    this.isDriver = false,
  });

  @override
  Widget build(BuildContext context) {
    double priceAfterDiscount =
        isShared ? price * (1 - discountPercentage / 100) : price;

    return Scaffold(
      backgroundColor: WassalnyTheme.bgLight,
      appBar: WassalnyTheme.buildAppBar('Ride Confirmed'),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: WassalnyTheme.success.withOpacity(0.08),
                borderRadius: BorderRadius.circular(20),
                border:
                    Border.all(color: WassalnyTheme.success.withOpacity(0.3)),
              ),
              child: Column(
                children: [
                  Container(
                    width: 64,
                    height: 64,
                    decoration: BoxDecoration(
                      color: WassalnyTheme.success.withOpacity(0.12),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.check_rounded,
                        color: WassalnyTheme.success, size: 36),
                  ),
                  const SizedBox(height: 14),
                  const Text('Ride Confirmed!',
                      style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                          color: WassalnyTheme.primary)),
                  const SizedBox(height: 4),
                  Text(
                      isShared
                          ? 'Shared ride with other passengers.'
                          : 'Your driver is on the way.',
                      style: WassalnyTheme.bodyText),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: WassalnyTheme.surfaceLight,
                borderRadius: BorderRadius.circular(20),
                boxShadow: WassalnyTheme.cardShadow,
                border:
                    Border.all(color: WassalnyTheme.accent.withOpacity(0.3)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    const Icon(Icons.receipt_long_outlined,
                        color: WassalnyTheme.accent, size: 20),
                    const SizedBox(width: 8),
                    const Text('RIDE RECEIPT',
                        style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w900,
                            color: WassalnyTheme.primary,
                            letterSpacing: 1)),
                  ]),
                  const SizedBox(height: 16),
                  const Divider(),
                  const SizedBox(height: 12),
                  _ReceiptSection('PASSENGER'),
                  _ReceiptRow('Name', clientName),
                  _ReceiptRow('Phone', clientPhone),
                  const SizedBox(height: 16),
                  _ReceiptSection('DRIVER'),
                  _ReceiptRow('Name', driverName),
                  _ReceiptRow('Plate', driverPlate),
                  _ReceiptRow('Taxi No.', driverTaxiNumber),
                  const SizedBox(height: 16),
                  _ReceiptSection('TRIP'),
                  _ReceiptRow('From', pickupAddress),
                  _ReceiptRow('To', destinationAddress),
                  _ReceiptRow(
                      'Distance', '${distanceKm.toStringAsFixed(1)} km'),
                  if (isShared) ...[
                    const SizedBox(height: 16),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: WassalnyTheme.success.withOpacity(0.10),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('Shared Ride',
                                  style: TextStyle(
                                      fontWeight: FontWeight.w700,
                                      fontSize: 13,
                                      color: WassalnyTheme.primary)),
                              Row(
                                children: [
                                  Icon(Icons.tag,
                                      size: 14, color: WassalnyTheme.success),
                                  const SizedBox(width: 4),
                                  Text(
                                      '${discountPercentage.toStringAsFixed(0)}% OFF',
                                      style: TextStyle(
                                          fontWeight: FontWeight.w800,
                                          fontSize: 12,
                                          color: WassalnyTheme.success)),
                                ],
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('Passengers',
                                  style: TextStyle(
                                      fontSize: 12,
                                      color: WassalnyTheme.textSecondary)),
                              Text('$numberOfPassengers people',
                                  style: const TextStyle(
                                      fontWeight: FontWeight.w700,
                                      fontSize: 13,
                                      color: WassalnyTheme.primary)),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('Estimated time',
                                  style: TextStyle(
                                      fontSize: 12,
                                      color: WassalnyTheme.textSecondary)),
                              Text('${(distanceKm * 2).toStringAsFixed(0)} min',
                                  style: const TextStyle(
                                      fontWeight: FontWeight.w700,
                                      fontSize: 13,
                                      color: WassalnyTheme.primary)),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                  const SizedBox(height: 16),
                  const Divider(),
                  const SizedBox(height: 12),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: WassalnyTheme.accent.withOpacity(0.10),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('TOTAL',
                                style: TextStyle(
                                    fontWeight: FontWeight.w900,
                                    fontSize: 14,
                                    color: WassalnyTheme.primary,
                                    letterSpacing: 0.5)),
                            Text('${priceAfterDiscount.toStringAsFixed(0)} DA',
                                style: const TextStyle(
                                    fontWeight: FontWeight.w900,
                                    fontSize: 22,
                                    color: WassalnyTheme.primary)),
                          ],
                        ),
                        if (isShared) ...[
                          const SizedBox(height: 4),
                          Text(
                              '(${discountPercentage.toStringAsFixed(0)}% discount applied)',
                              style: TextStyle(
                                  fontSize: 11, color: WassalnyTheme.success)),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  Center(
                    child: Text('Calculated automatically by Wassalny',
                        style: WassalnyTheme.cardSubtitle),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            if (!isDriver) ...[
              SizedBox(
                width: double.infinity,
                height: 54,
                child: ElevatedButton.icon(
                  onPressed: () => Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => const ClientHomeScreen()),
                    (r) => false,
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: WassalnyTheme.accentBlue,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16)),
                  ),
                  icon: const Icon(Icons.home_rounded, size: 20),
                  label: const Text('Back to Home',
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                ),
              ),
            ],
            if (isDriver) ...[
              SizedBox(
                width: double.infinity,
                height: 54,
                child: ElevatedButton.icon(
                  onPressed: () => Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(
                      builder: (_) => DriverHomeScreen(),
                    ),
                    (r) => false,
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: WassalnyTheme.accentBlue,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16)),
                  ),
                  icon: const Icon(Icons.delivery_dining_rounded, size: 20),
                  label: const Text('Back to Driver Home',
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _ReceiptSection extends StatelessWidget {
  final String title;
  const _ReceiptSection(this.title);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(title,
          style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w800,
              color: WassalnyTheme.accent,
              letterSpacing: 1)),
    );
  }
}

class _ReceiptRow extends StatelessWidget {
  final String label;
  final String value;
  const _ReceiptRow(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        children: [
          SizedBox(
              width: 90,
              child: Text(label,
                  style: const TextStyle(
                      fontSize: 13,
                      color: WassalnyTheme.textSecondary,
                      fontWeight: FontWeight.w500))),
          Expanded(
              child: Text(value,
                  style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: WassalnyTheme.primary))),
        ],
      ),
    );
  }
}
