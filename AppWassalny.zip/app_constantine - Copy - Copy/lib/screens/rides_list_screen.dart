// ════════════════════════════════════════════════════════════════════════════
// rides_list_screen.dart
// ════════════════════════════════════════════════════════════════════════════
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:app_constantine/theme_wassalny.dart';

class RidesListScreen extends StatefulWidget {
  const RidesListScreen({super.key});

  @override
  State<RidesListScreen> createState() => _RidesListScreenState();
}

class _RidesListScreenState extends State<RidesListScreen> {
  List<dynamic> _rides = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadRides();
  }

  Future<void> _loadRides() async {
    try {
      final res = await http
          .get(Uri.parse('http://10.0.2.2:8000/api/cooperative-rides/'));
      if (res.statusCode == 200) {
        setState(() {
          _rides = json.decode(res.body);
          _isLoading = false;
        });
      } else {
        setState(() => _isLoading = false);
      }
    } catch (_) {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WassalnyTheme.bgLight,
      appBar: WassalnyTheme.buildAppBar('Available Shared Rides'),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: WassalnyTheme.accent))
          : _rides.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(24),
                        decoration: BoxDecoration(
                          color: WassalnyTheme.textSecondary.withOpacity(0.08),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.directions_car_outlined,
                            size: 48, color: WassalnyTheme.textSecondary),
                      ),
                      const SizedBox(height: 16),
                      const Text('No rides available',
                          style: TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.w700,
                              color: WassalnyTheme.primary)),
                      const SizedBox(height: 4),
                      Text('Check back soon for shared rides.',
                          style: WassalnyTheme.bodyText),
                    ],
                  ),
                )
              : RefreshIndicator(
                  color: WassalnyTheme.accent,
                  onRefresh: _loadRides,
                  child: ListView.separated(
                    padding: const EdgeInsets.all(20),
                    itemCount: _rides.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 12),
                    itemBuilder: (_, i) {
                      final r = _rides[i];
                      return Container(
                        padding: const EdgeInsets.all(16),
                        decoration: WassalnyTheme.cardDecoration,
                        child: Row(children: [
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: WassalnyTheme.primary.withOpacity(0.08),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Icon(Icons.directions_car_rounded,
                                color: WassalnyTheme.primary, size: 22),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(r['passenger_name'] ?? 'Passenger',
                                    style: WassalnyTheme.cardTitle),
                                const SizedBox(height: 4),
                                Row(children: [
                                  const Icon(Icons.location_on,
                                      size: 12,
                                      color: WassalnyTheme.accentBlue),
                                  const SizedBox(width: 3),
                                  Text(
                                    '${r['pickup_lat']?.toStringAsFixed(4)}, ${r['pickup_lng']?.toStringAsFixed(4)}',
                                    style: WassalnyTheme.cardSubtitle,
                                  ),
                                ]),
                              ],
                            ),
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                '${r['price_per_passenger']} DA',
                                style: const TextStyle(
                                    fontWeight: FontWeight.w800,
                                    fontSize: 15,
                                    color: WassalnyTheme.primary),
                              ),
                              const Text('per seat',
                                  style: TextStyle(
                                      fontSize: 11,
                                      color: WassalnyTheme.textSecondary)),
                            ],
                          ),
                        ]),
                      );
                    },
                  ),
                ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
// customer_home_screen.dart
// ════════════════════════════════════════════════════════════════════════════
class CustomerHomeScreen extends StatelessWidget {
  const CustomerHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Alias — redirects to the main client home
    return const _CustomerHomeRedirect();
  }
}

class _CustomerHomeRedirect extends StatelessWidget {
  const _CustomerHomeRedirect();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WassalnyTheme.bgLight,
      appBar: WassalnyTheme.buildAppBar('Home'),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.home_rounded,
                size: 64, color: WassalnyTheme.textSecondary),
            const SizedBox(height: 16),
            const Text('Customer Home',
                style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: WassalnyTheme.primary)),
            const SizedBox(height: 8),
            Text('Use ClientHomeScreen for the full experience.',
                style: WassalnyTheme.bodyText, textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}
