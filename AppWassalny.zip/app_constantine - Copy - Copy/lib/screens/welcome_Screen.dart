import 'package:flutter/material.dart';
import 'package:app_constantine/theme_wassalny.dart';
import 'driver_login_screen.dart';
import 'client_login_screen.dart';

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key});

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WassalnyTheme.backgroundLight,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.drive_eta,
                size: 120, color: WassalnyTheme.primaryYellow),
            SizedBox(height: 20),
            Text(
              'Wassalny Taxi',
              style: WassalnyTheme.titleLarge,
            ),
            SizedBox(height: 10),
            Text(
              'Tour de Constantine',
              style: WassalnyTheme.cardSubtitle,
            ),
            SizedBox(height: 50),
            SizedBox(
              width: 250,
              height: 56,
              child: ElevatedButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => DriverLoginScreen()),
                  );
                },
                style: WassalnyTheme.elevatedButtonStyle,
                icon: Icon(Icons.login, size: 24),
                label: Text(
                  'Chauffeur - Sign In',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
            ),
            SizedBox(height: 20),
            SizedBox(
              width: 250,
              height: 56,
              child: ElevatedButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => ClientLoginScreen()),
                  );
                },
                style: WassalnyTheme.elevatedButtonStyle,
                icon: Icon(Icons.person, size: 24),
                label: Text(
                  'Client - Sign In',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
