import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../cooperative_passenger.dart';

class CooperativeRideService {
  List<CooperativePassenger> findMatchingPassengers({
    required LatLng pickupLocation,
    required LatLng destinationLocation,
    required List<CooperativePassenger> allPassengers,
    required double maxDeviation,
    required bool womenOnly,
  }) {
    return allPassengers.where((passenger) {
      double pickupDeviation = _calculateDeviation(
        pickupLocation,
        passenger.pickupLocation,
        destinationLocation,
      );

      double destDeviation = _calculateDeviation(
        pickupLocation,
        passenger.destinationLocation,
        destinationLocation,
      );

      return pickupDeviation <= maxDeviation &&
          destDeviation <= maxDeviation &&
          (!womenOnly || passenger.womenOnly);
    }).toList();
  }

  double _calculateDeviation(
    LatLng start,
    LatLng point,
    LatLng end,
  ) {
    double directDistance = _distanceBetween(start, end);
    double withPointDistance =
        _distanceBetween(start, point) + _distanceBetween(point, end);

    if (directDistance == 0) return 0;

    return (withPointDistance - directDistance) / directDistance;
  }

  double _distanceBetween(LatLng a, LatLng b) {
    double latDiff = (a.latitude - b.latitude).abs();
    double lngDiff = (a.longitude - b.longitude).abs();
    return (latDiff * 111 + lngDiff * 85);
  }

  List<LatLng> optimizeRoute({
    required LatLng pickupLocation,
    required LatLng destinationLocation,
    required List<CooperativePassenger> passengers,
  }) {
    if (passengers.isEmpty) {
      return [pickupLocation, destinationLocation];
    }

    List<LatLng> pickupPoints = [pickupLocation];
    for (var p in passengers) {
      if (p.pickupLocation != pickupLocation) {
        pickupPoints.add(p.pickupLocation);
      }
    }

    pickupPoints.sort((a, b) {
      double distA = _distanceBetween(pickupLocation, a);
      double distB = _distanceBetween(pickupLocation, b);
      return distA.compareTo(distB);
    });

    List<LatLng> destPoints = [];
    for (var p in passengers) {
      if (p.destinationLocation != destinationLocation) {
        destPoints.add(p.destinationLocation);
      }
    }
    destPoints.add(destinationLocation);

    destPoints.sort((a, b) {
      double distA = _distanceBetween(pickupPoints.last, a);
      double distB = _distanceBetween(pickupPoints.last, b);
      return distA.compareTo(distB);
    });

    return [...pickupPoints, ...destPoints];
  }

  double calculateTotalPrice({
    required double basePrice,
    required double distanceKm,
    required int passengers,
    double discountPercentage = 20,
  }) {
    double total = basePrice + (distanceKm * 10);
    double discounted = total * (1 - discountPercentage / 100);
    return discounted;
  }
}
