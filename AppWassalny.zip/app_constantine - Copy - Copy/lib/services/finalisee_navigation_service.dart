import 'package:flutter/material.dart';

class FinaliseeNavigationService {
  static final FinaliseeNavigationService _instance =
      FinaliseeNavigationService._internal();

  factory FinaliseeNavigationService() => _instance;

  FinaliseeNavigationService._internal();

  Locale _locale = Locale('en');
  final List<ValueChanged<Locale>> _listeners = [];

  Locale get locale => _locale;

  void setLanguage(String language) {
    _locale = language == 'ar' ? Locale('ar') : Locale('en');
    _notifyListeners();
  }

  void addListener(ValueChanged<Locale> listener) {
    _listeners.add(listener);
  }

  void removeListener(ValueChanged<Locale> listener) {
    _listeners.remove(listener);
  }

  void _notifyListeners() {
    for (final listener in _listeners) {
      listener(_locale);
    }
  }
}
