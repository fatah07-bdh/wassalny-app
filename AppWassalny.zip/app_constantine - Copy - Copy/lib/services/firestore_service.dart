import 'package:cloud_firestore/cloud_firestore.dart';

class FirestoreService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> addTest() async {
    await _firestore.collection('tests').add({
      'message': 'Hello Firebase',
      'createdAt': FieldValue.serverTimestamp(),
    });
  }
}
