import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/api_config.dart';

class RideService {
  static Future<List<dynamic>> getCooperativeRides() async {
    try {
      final response = await http.get(
        Uri.parse(ApiConfig.cooperativeRides),
      );

      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        throw Exception('Failed to load rides: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error: $e');
    }
  }

  static Future<List<dynamic>> getSearchingRides() async {
    try {
      final response = await http.get(
        Uri.parse(ApiConfig.searching),
      );

      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        throw Exception('Failed to load searching rides');
      }
    } catch (e) {
      throw Exception('Error: $e');
    }
  }

  static Future<dynamic> createCooperativeRide(
      Map<String, dynamic> rideData) async {
    try {
      final response = await http.post(
        Uri.parse(ApiConfig.cooperativeRides),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(rideData),
      );

      if (response.statusCode == 201) {
        return json.decode(response.body);
      } else {
        throw Exception('Failed to create ride: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error: $e');
    }
  }
}
