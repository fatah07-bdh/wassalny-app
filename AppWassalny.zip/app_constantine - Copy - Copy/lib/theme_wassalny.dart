import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class WassalnyTheme {
  static const Color primary = Color(0xFF0B1D35);
  static const Color accent = Color(0xFFF5C518);
  static const Color accentBlue = Color(0xFF2196F3);
  static const Color success = Color(0xFF22C55E);
  static const Color danger = Color(0xFFEF4444);

  static const Color bgLight = Color(0xFFF8FAFC);
  static const Color bgDark = Color(0xFF0D1117);
  static const Color surfaceLight = Color(0xFFFFFFFF);
  static const Color surfaceDark = Color(0xFF161B22);

  static const Color textPrimary = Color(0xFF0B1D35);
  static const Color textSecondary = Color(0xFF64748B);
  static const Color textDark = Color(0xFFF1F5F9);

  static const Color primaryDark = primary;
  static const Color primaryYellow = accent;
  static const Color blueAccent = accentBlue;
  static const Color backgroundLight = bgLight;
  static const Color backgroundDark = bgDark;
  static const Color cardLight = surfaceLight;
  static const Color cardDark = surfaceDark;
  static const Color textLight = Color(0xFF334155);

  static Gradient get backgroundGradient => const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [primary, Color(0xFF132D50), Color(0xFF1A3A6B)],
      );

  static Gradient get accentGradient => const LinearGradient(
        colors: [Color(0xFFF5C518), Color(0xFFFFD954)],
      );

  static List<BoxShadow> get cardShadow => [
        BoxShadow(
          color: Colors.black.withOpacity(0.06),
          blurRadius: 16,
          offset: const Offset(0, 4),
        ),
      ];

  static List<BoxShadow> get accentShadow => [
        BoxShadow(
          color: accent.withOpacity(0.30),
          blurRadius: 20,
          offset: const Offset(0, 8),
        ),
      ];

  static List<BoxShadow> get blueShadow => [
        BoxShadow(
          color: accentBlue.withOpacity(0.28),
          blurRadius: 20,
          offset: const Offset(0, 8),
        ),
      ];

  static BoxDecoration get cardDecoration => BoxDecoration(
        color: surfaceLight,
        borderRadius: BorderRadius.circular(18),
        boxShadow: cardShadow,
      );

  static BoxDecoration get cardDecorationDark => BoxDecoration(
        color: surfaceDark,
        borderRadius: BorderRadius.circular(18),
        boxShadow: cardShadow,
      );

  static InputDecoration textFieldDecoration(String label, {IconData? icon}) {
    return InputDecoration(
      labelText: label,
      prefixIcon:
          icon != null ? Icon(icon, color: textSecondary, size: 20) : null,
      filled: true,
      fillColor: const Color(0xFFF1F5F9),
      labelStyle: const TextStyle(color: textSecondary, fontSize: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide.none,
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide.none,
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: accent, width: 2),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
    );
  }

  static const TextStyle displayLarge = TextStyle(
    fontSize: 36,
    fontWeight: FontWeight.w900,
    color: accent,
    letterSpacing: -0.5,
  );

  static const TextStyle titleLarge = TextStyle(
    fontSize: 32,
    fontWeight: FontWeight.w900,
    color: accent,
    letterSpacing: 0.5,
  );

  static const TextStyle titleBold = TextStyle(
    fontSize: 26,
    fontWeight: FontWeight.w800,
    color: primary,
  );

  static const TextStyle titleMedium = TextStyle(
    fontSize: 22,
    fontWeight: FontWeight.w700,
    color: primary,
  );

  static TextStyle get titleMediumDark => const TextStyle(
        fontSize: 22,
        fontWeight: FontWeight.w700,
        color: textDark,
      );

  static const TextStyle subtitle = TextStyle(
    fontSize: 17,
    fontWeight: FontWeight.w600,
    color: primary,
  );

  static TextStyle get subtitleDark => const TextStyle(
        fontSize: 17,
        fontWeight: FontWeight.w600,
        color: textDark,
      );

  static const TextStyle bodyText = TextStyle(
    fontSize: 15,
    color: textSecondary,
    height: 1.5,
  );

  static TextStyle get bodyTextDark => TextStyle(
        fontSize: 15,
        color: textDark.withOpacity(0.75),
        height: 1.5,
      );

  static const TextStyle cardTitle = TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.w700,
    color: primary,
  );

  static TextStyle get cardTitleDark => const TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w700,
        color: textDark,
      );

  static const TextStyle cardSubtitle = TextStyle(
    fontSize: 13,
    color: textSecondary,
  );

  static TextStyle get cardSubtitleDark => TextStyle(
        fontSize: 13,
        color: textDark.withOpacity(0.6),
      );

  static ButtonStyle get primaryButtonStyle => ElevatedButton.styleFrom(
        backgroundColor: accent,
        foregroundColor: primary,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 16),
        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
      );

  static ButtonStyle get elevatedButtonStyle => primaryButtonStyle;

  static ButtonStyle get outlineButtonStyle => OutlinedButton.styleFrom(
        foregroundColor: primary,
        side: const BorderSide(color: primary, width: 1.5),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 16),
      );

  static AppBar buildAppBar(String title, {List<Widget>? actions}) {
    return AppBar(
      backgroundColor: bgLight,
      foregroundColor: primary,
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      centerTitle: true,
      title: Text(
        title,
        style: const TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.w800,
          color: primary,
          letterSpacing: -0.2,
        ),
      ),
      actions: actions,
      systemOverlayStyle: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.dark,
      ),
    );
  }

  static ThemeData get lightTheme => ThemeData(
        useMaterial3: true,
        brightness: Brightness.light,
        primaryColor: primary,
        scaffoldBackgroundColor: bgLight,
        colorScheme: const ColorScheme.light(
          primary: primary,
          secondary: accent,
          surface: surfaceLight,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: bgLight,
          foregroundColor: primary,
          elevation: 0,
          centerTitle: true,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(style: primaryButtonStyle),
      );

  static ThemeData get darkTheme => ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        primaryColor: primary,
        scaffoldBackgroundColor: bgDark,
        colorScheme: const ColorScheme.dark(
          primary: accent,
          secondary: accentBlue,
          surface: surfaceDark,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(style: primaryButtonStyle),
      );
}
