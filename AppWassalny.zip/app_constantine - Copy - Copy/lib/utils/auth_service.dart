class AuthService {
  bool _isLoggedIn = false;
  String? _driverPhone;

  bool get isLoggedIn => _isLoggedIn;
  String? get driverPhone => _driverPhone;

  void login(String phone) {
    _isLoggedIn = true;
    _driverPhone = phone;
  }

  void logout() {
    _isLoggedIn = false;
    _driverPhone = null;
  }
}

final AuthService authService = AuthService();
