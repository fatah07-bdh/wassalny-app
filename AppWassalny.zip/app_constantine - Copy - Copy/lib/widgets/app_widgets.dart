import 'package:flutter/material.dart';
import 'package:app_constantine/theme_wassalny.dart';

class WButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final Color? color;
  final Color? textColor;
  final bool isLoading;
  final double height;

  const WButton({
    Key? key,
    required this.label,
    this.onPressed,
    this.icon,
    this.color,
    this.textColor,
    this.isLoading = false,
    this.height = 54,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final bg = color ?? WassalnyTheme.accent;
    final fg = textColor ?? WassalnyTheme.primary;

    return SizedBox(
      width: double.infinity,
      height: height,
      child: ElevatedButton(
        onPressed: isLoading ? null : onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: bg,
          foregroundColor: fg,
          elevation: 0,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
        child: isLoading
            ? SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(color: fg, strokeWidth: 2.5),
              )
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (icon != null) ...[
                    Icon(icon, size: 20),
                    const SizedBox(width: 8),
                  ],
                  Text(label,
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: fg)),
                ],
              ),
      ),
    );
  }
}

class SectionHeader extends StatelessWidget {
  final String title;
  final String? subtitle;
  final Widget? trailing;

  const SectionHeader(
      {Key? key, required this.title, this.subtitle, this.trailing})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    color: WassalnyTheme.primary,
                  )),
              if (subtitle != null) ...[
                const SizedBox(height: 2),
                Text(subtitle!, style: WassalnyTheme.cardSubtitle),
              ],
            ],
          ),
        ),
        if (trailing != null) trailing!,
      ],
    );
  }
}

class StatCard extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String value;
  final String label;

  const StatCard({
    Key? key,
    required this.icon,
    required this.iconColor,
    required this.value,
    required this.label,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: WassalnyTheme.cardDecoration,
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: iconColor.withOpacity(0.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: iconColor, size: 24),
          ),
          const SizedBox(height: 10),
          Text(value,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w900,
                color: WassalnyTheme.primary,
              )),
          const SizedBox(height: 2),
          Text(label, style: WassalnyTheme.cardSubtitle),
        ],
      ),
    );
  }
}

class InfoRow extends StatelessWidget {
  final IconData icon;
  final Color? iconColor;
  final String label;
  final String value;

  const InfoRow({
    Key? key,
    required this.icon,
    this.iconColor,
    required this.label,
    required this.value,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: (iconColor ?? WassalnyTheme.accentBlue).withOpacity(0.10),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon,
                color: iconColor ?? WassalnyTheme.accentBlue, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: WassalnyTheme.textSecondary,
                        letterSpacing: 0.4)),
                const SizedBox(height: 2),
                Text(value,
                    style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: WassalnyTheme.primary)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class RideHistoryCard extends StatelessWidget {
  final String date;
  final String departure;
  final String destination;
  final String price;
  final String status;
  final String? client;

  const RideHistoryCard({
    Key? key,
    required this.date,
    required this.departure,
    required this.destination,
    required this.price,
    required this.status,
    this.client,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: WassalnyTheme.cardDecoration,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(children: [
                const Icon(Icons.access_time,
                    size: 14, color: WassalnyTheme.textSecondary),
                const SizedBox(width: 6),
                Text(date, style: WassalnyTheme.cardSubtitle),
              ]),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: WassalnyTheme.success.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(status,
                    style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: WassalnyTheme.success)),
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (client != null) ...[
            Row(children: [
              const Icon(Icons.person_outline,
                  size: 16, color: WassalnyTheme.accentBlue),
              const SizedBox(width: 6),
              Text(client!, style: WassalnyTheme.cardTitle),
            ]),
            const SizedBox(height: 6),
          ],
          Row(children: [
            Container(
                width: 8,
                height: 8,
                decoration: const BoxDecoration(
                    color: WassalnyTheme.accentBlue, shape: BoxShape.circle)),
            const SizedBox(width: 8),
            Expanded(child: Text(departure, style: WassalnyTheme.bodyText)),
          ]),
          Padding(
            padding: const EdgeInsets.only(left: 3),
            child: Container(
                width: 2,
                height: 14,
                color: WassalnyTheme.textSecondary.withOpacity(0.3)),
          ),
          Row(children: [
            Container(
                width: 8,
                height: 8,
                decoration: const BoxDecoration(
                    color: WassalnyTheme.danger, shape: BoxShape.circle)),
            const SizedBox(width: 8),
            Expanded(child: Text(destination, style: WassalnyTheme.bodyText)),
          ]),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const SizedBox(),
              Text(price,
                  style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                      color: WassalnyTheme.primary)),
            ],
          ),
        ],
      ),
    );
  }
}
