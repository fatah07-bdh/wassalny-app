import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class SettingsButtons extends StatelessWidget {
  final String currentLanguage;
  final bool isDarkMode;
  final Function(String) onLanguageChanged;
  final Function(bool) onDarkModeChanged;

  const SettingsButtons({
    super.key,
    required this.currentLanguage,
    required this.isDarkMode,
    required this.onLanguageChanged,
    required this.onDarkModeChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDarkMode ? Color(0xFF1E1E1E) : Color(0xFFFFFFFF),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(Icons.language,
                      color: isDarkMode ? Color(0xFFF4D03F) : Color(0xFF1A1A2E),
                      size: 24),
                  SizedBox(width: 12),
                  Text(
                    'Language',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: isDarkMode ? Color(0xFFE0E0E0) : Color(0xFF333333),
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  _languageButton('en', 'English'),
                  SizedBox(width: 8),
                  _languageButton('fr', 'Français'),
                  SizedBox(width: 8),
                  _languageButton('ar', 'عربي'),
                ],
              ),
            ],
          ),
          SizedBox(height: 16),
          Divider(color: isDarkMode ? Color(0xFF333333) : Color(0xFFDDDDDD)),
          SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(
                    isDarkMode ? Icons.dark_mode : Icons.light_mode,
                    color: isDarkMode ? Color(0xFFF4D03F) : Color(0xFF1A1A2E),
                    size: 24,
                  ),
                  SizedBox(width: 12),
                  Text(
                    isDarkMode ? 'Dark Mode' : 'Light Mode',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: isDarkMode ? Color(0xFFE0E0E0) : Color(0xFF333333),
                    ),
                  ),
                ],
              ),
              InkWell(
                onTap: () => onDarkModeChanged(!isDarkMode),
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    color: isDarkMode ? Color(0xFFF4D03F) : Color(0xFF1A1A2E),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    isDarkMode ? 'ON' : 'OFF',
                    style: TextStyle(
                      color: isDarkMode ? Color(0xFF1A1A2E) : Color(0xFFF4D03F),
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _languageButton(String lang, String label) {
    return InkWell(
      onTap: () => onLanguageChanged(lang),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: currentLanguage == lang
              ? (isDarkMode ? Color(0xFFF4D03F) : Color(0xFF1A1A2E))
              : (isDarkMode ? Color(0xFF333333) : Color(0xFFEEEEEE)),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: currentLanguage == lang
                ? (isDarkMode ? Color(0xFFF4D03F) : Color(0xFF1A1A2E))
                : Colors.grey.shade300,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: currentLanguage == lang
                ? (isDarkMode ? Color(0xFF1A1A2E) : Color(0xFFF4D03F))
                : (isDarkMode ? Color(0xFFE0E0E0) : Color(0xFF333333)),
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}
