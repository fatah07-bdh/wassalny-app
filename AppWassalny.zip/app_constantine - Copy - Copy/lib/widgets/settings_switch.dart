import 'package:flutter/material.dart';
import 'package:app_constantine/theme_wassalny.dart';

class SettingsSwitch extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final bool value;
  final ValueChanged<bool>? onChanged;
  final VoidCallback? onTap;

  const SettingsSwitch({
    super.key,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.value,
    this.onChanged,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: WassalnyTheme.cardDecoration,
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: value
                    ? WassalnyTheme.primaryYellow.withOpacity(0.2)
                    : Colors.grey.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                icon,
                color: value ? WassalnyTheme.primaryYellow : Colors.grey,
                size: 24,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: WassalnyTheme.cardTitle),
                  const SizedBox(height: 4),
                  Text(subtitle, style: WassalnyTheme.cardSubtitle),
                ],
              ),
            ),
            if (onChanged != null)
              Switch(
                value: value,
                onChanged: onChanged,
                activeColor: WassalnyTheme.primaryYellow,
                activeTrackColor: WassalnyTheme.primaryYellow.withOpacity(0.5),
              )
            else
              Icon(Icons.arrow_forward_ios, size: 18, color: Colors.grey),
          ],
        ),
      ),
    );
  }
}
