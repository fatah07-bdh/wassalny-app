// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// web/firebase_config.js

// Votre configuration Firebase
const firebaseConfig = {
  apiKey: "AIzaSyB2mpj1wP8l8DuXBj1cPHqABGKwoTKNfAM",
  authDomain: "app-constantine-4743d.firebaseapp.com",
  projectId: "app-constantine-4743d",
  storageBucket: "app-constantine-4743d.firebasestorage.app",
  messagingSenderId: "185335937153",
  appId: "1:185335937153:web:8ee1ea54265430ea70b580",
  measurementId: "G-TT9VKR144D"
};

// Initialisation de l'application Firebase (modèle v10 compat)
firebase.initializeApp(firebaseConfig);